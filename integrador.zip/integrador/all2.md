# Arquitetura Geral v2 — Firmware XY G-Code (ESP32 + FreeRTOS)

## 1. Visão Sistêmica

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                     FIRMWARE XY G-CODE ESP32 — v2                           │
│                                                                             │
│  ┌────────────────────────────────────────────────────────────────────┐    │
│  │                     CAMADA DE APLICAÇÃO (Core 0)                   │    │
│  │                                                                    │    │
│  │  ┌──────────────┐  ┌───────────────┐  ┌──────────────┐            │    │
│  │  │  UARTTask    │  │ GCodeParser   │  │MotionPlanner │            │    │
│  │  │  Prio 2      │  │ Task  Prio 3  │  │Task  Prio 3  │            │    │
│  │  │              │  │               │  │              │            │    │
│  │  │ ┌──────────┐ │  │               │  │              │            │    │
│  │  │ │'?' detect│ │  │               │  │              │            │    │
│  │  │ │imediato  │ │  │               │  │              │            │    │
│  │  │ └──────────┘ │  │               │  │              │            │    │
│  │  └──────┬───────┘  └───────┬───────┘  └──────┬───────┘           │    │
│  │         │                  │                  │                   │    │
│  │  ┌──────┴───────────────────────────────────┐ │                   │    │
│  │  │          MonitorTask  Prio 1             │ │                   │    │
│  │  │    (watchdog + overflow — background)    │ │                   │    │
│  │  └──────────────────────────────────────────┘ │                   │    │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                    │                    │                                   │
│           CAMADA DE IPC (FreeRTOS)      │                                   │
│  ┌─────────────────────────────────────┼─────────────────────────────┐    │
│  │                                     │                             │    │
│  │  cmd_queue (10×96B)                 │                             │    │
│  │  motion_queue (8 items)             │                             │    │
│  │  planner_queue (16 items)  ◄────────┘                             │    │
│  │  state_mutex                                                      │    │
│  │  uart_tx_mutex                                                    │    │
│  │  motion_event_group (3 bits)                                      │    │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                        │                                   │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │              CAMADA DE EXECUÇÃO (Core 1 — tempo real)               │   │
│  │                                                                     │   │
│  │  ┌────────────────────────────────────────────────────────────────┐ │   │
│  │  │  MotionExecutorTask  Prio 4  (Core 1 fixo)                     │ │   │
│  │  │  • Consome planner_queue                                       │ │   │
│  │  │  • Aplica extruder_action (hal_extruder) antes de cada bloco   │ │   │
│  │  │  • Configura g_isr_ctx (seção crítica)                         │ │   │
│  │  │  • Arma GPTimer → bloqueia em xTaskNotifyWait                  │ │   │
│  │  │  • Atualiza g_state após conclusão                             │ │   │
│  │  └────────────────────────────────────────────────────────────────┘ │   │
│  │                                                                     │   │
│  │  ┌────────────────────────────────────────────────────────────────┐ │   │
│  │  │  GPTimer ISR  (IRAM_ATTR — Core 1)                             │ │   │
│  │  │  • Bresenham + trapezoidal por ciclo                           │ │   │
│  │  │  • GPIO STEP pulso (set → delay_ns → clear)                   │ │   │
│  │  │  • Re-arma timer com novo period                               │ │   │
│  │  │  • Fim de bloco: xTaskNotifyFromISR → Executor                 │ │   │
│  │  └────────────────────────────────────────────────────────────────┘ │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                        │                                   │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │                           CAMADA HAL                                │   │
│  │                                                                     │   │
│  │   hal_stepper  (A4988/DRV8825 por #ifdef)                          │   │
│  │   hal_endstop  (GPIO input + debounce)                             │   │
│  │   hal_extruder (GPIO output ON/OFF) ← chamado pelo Executor        │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                        │                                   │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │                         HARDWARE ESP32                              │   │
│  │  GPTimer  •  GPIO(STEP/DIR/EN)  •  GPIO(Endstop)  •  UART0(USB)   │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────────────────────┘
```

## 2. Comparativo v1 → v2

| Aspecto | v1 | v2 | Motivo |
|---------|----|----|--------|
| Tarefas | 6 (inclui ExtruderTask) | 5 | Extrusor absorvido na pipeline de movimento |
| '?' handler | GCodeParser + MonitorTask | UARTTask direto | Comando de tempo real |
| UART TX sync | Não sincronizado ❌ | uart_tx_mutex ✓ | Evita corrupção de protocolo |
| planner buffer | 3 blocos (block_queue) | 16 blocos (planner_queue) | Anti-starvation |
| ok/error timing | Incorreto (timeout 100ms) | Correto (portMAX_DELAY) | Protocolo GRBL |
| M114 | Não suportado | GCodeParser responde | Sem nova tarefa |
| Sequência extrusor | Pode dessincronizar ❌ | Embedded no bloco ✓ | Correto para deposição |

## 3. Fluxo de Dados v2

```
Serial IN
    │
    ▼
UARTTask
    │── '?' detectado? → Resposta imediata (uart_tx_mutex) ──► Serial OUT
    │
    └── Linha completa → cmd_queue
                              │
                              ▼
                       GCodeParserTask
                              │── M114   → lê state → uart_tx_mutex → Serial OUT
                              │── G90/91 → atualiza state_mutex
                              │── M3/M5  → cria motion_cmd com extruder_action
                              │── G0/G1  → cria motion_cmd
                              │── G28    → cria motion_cmd HOMING
                              │
                              └── motion_queue
                                        │
                                        ▼
                               MotionPlannerTask
                                        │── Converte mm → passos
                                        │── Calcula Bresenham
                                        │── Calcula trapezoidal
                                        │
                                        └── planner_queue (16 slots)
                                                    │
                                                    ▼
                                         MotionExecutorTask (Core 1)
                                                    │── Aplica extruder_action
                                                    │── Configura g_isr_ctx
                                                    │── Arma GPTimer
                                                    │── Aguarda xTaskNotify
                                                    │── Atualiza g_state
                                                    │
                                               GPTimer ISR (Core 1, IRAM)
                                                    │── Bresenham
                                                    │── Trapezoidal
                                                    └── GPIO STEP pulses
```

# Diagrama de Tarefas FreeRTOS — v2

## 1. Mapa de Tarefas

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                     TAREFAS FREERTOS — v2 (5 tarefas)                       │
│                                                                             │
│  ─── CORE 0 (tskNO_AFFINITY — SMP scheduler decide) ────────────────────   │
│                                                                             │
│  Prioridade 1 (background)                                                  │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │  MonitorTask                                                        │   │
│  │  Stack: 2048  |  Período: ~1000ms                                   │   │
│  │  • Verifica uxQueueSpacesAvailable(planner_queue) — alerta overflow │   │
│  │  • Detecta starvation: Executor parado > timeout com fila não vazia │   │
│  │  • Sinaliza EVENT_ALARM se detectar anomalia                        │   │
│  │  • NÃO responde ao '?' (removido da v1)                             │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                             │
│  Prioridade 2                                                               │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │  UARTTask                                                           │   │
│  │  Stack: 2048                                                        │   │
│  │  • Lê UART byte a byte (bloqueante)                                 │   │
│  │  • Para cada byte: verifica se é '?' ANTES de acumular no buffer   │   │
│  │    → '?' : adquire state_mutex (5ms), formata status, envia via     │   │
│  │             uart_tx_mutex. NÃO enfileira. Continua lendo.          │   │
│  │  • Acumula bytes até '\n' → envia string para cmd_queue            │   │
│  │  • xQueueSend com timeout 0: se cmd_queue cheia, descarta linha    │   │
│  │    (comportamento correto: host não deveria enviar sem 'ok')        │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                             │
│  Prioridade 3                                                               │
│  ┌──────────────────────────┐   ┌──────────────────────────────────────┐   │
│  │  GCodeParserTask         │   │  MotionPlannerTask                   │   │
│  │  Stack: 4096             │   │  Stack: 4096                         │   │
│  │                          │   │                                      │   │
│  │  Consome: cmd_queue      │   │  Consome: motion_queue               │   │
│  │  Produz:                 │   │  Produz:  planner_queue              │   │
│  │  • motion_queue          │   │                                      │   │
│  │    (G0/G1/G28/M3/M5)     │   │  • Converte mm → passos             │   │
│  │  • UART TX direto        │   │  • Calcula Bresenham                 │   │
│  │    (ok/error/M114)       │   │  • Calcula trapezoidal               │   │
│  │                          │   │  • Preenche extruder_action          │   │
│  │  Bloqueia:               │   │  • Envia via portMAX_DELAY           │   │
│  │  cmd_queue portMAX_DELAY │   │                                      │   │
│  │                          │   │  Bloqueia:                           │   │
│  │  M3/M5: cria motion_cmd  │   │  motion_queue portMAX_DELAY          │   │
│  │  com extruder_action     │   │  planner_queue portMAX_DELAY         │   │
│  │  type=CMD_EXTRUDER_ONLY  │   │                                      │   │
│  └──────────────────────────┘   └──────────────────────────────────────┘   │
│                                                                             │
│  ─── CORE 1 (xTaskCreatePinnedToCore, core=1) ──────────────────────────   │
│                                                                             │
│  Prioridade 4 (máxima userspace — tempo real)                               │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │  MotionExecutorTask  (Core 1 fixo)                                  │   │
│  │  Stack: 4096                                                        │   │
│  │                                                                     │   │
│  │  Consome: planner_queue                                             │   │
│  │                                                                     │   │
│  │  Para cada bloco:                                                   │   │
│  │  1. Aplica extruder_action → hal_extruder_on/off() + state         │   │
│  │  2. Configura GPIO DIR X e Y                                        │   │
│  │  3. Habilita driver (EN_PIN)                                        │   │
│  │  4. gptimer_stop() → seção crítica: escreve g_isr_ctx               │   │
│  │  5. gptimer_start() com initial_period_us                           │   │
│  │  6. xTaskNotifyWait(BLOCK_DONE | ALARM, portMAX_DELAY)  ← BLOQUEIA │   │
│  │  7. Atualiza g_state.mpos via state_mutex                           │   │
│  │  8. Se planner_queue vazia: g_state.status = IDLE                  │   │
│  │  9. Loop                                                            │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                             │
│  ISR (IRAM_ATTR — associada ao Core 1 via GPTimer)                          │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │  gptimer_isr_callback                                               │   │
│  │  • Lê g_isr_ctx (sem lock — Executor garante exclusão via stop/start)│  │
│  │  • Bresenham: avança eixo dominante, condicionalmente subordinado   │   │
│  │  • GPIO: set STEP → esp_rom_delay_us(2) → clear STEP               │   │
│  │  • Trapezoidal: atualiza current_period_us por fase                 │   │
│  │  • step_count++                                                     │   │
│  │  • Se step_count == total_steps:                                    │   │
│  │    → gptimer_stop() (dentro da própria ISR — suportado no ESP-IDF) │   │
│  │    → xTaskNotifyFromISR(executor_handle, BLOCK_DONE, ...)           │   │
│  │  • Senão: gptimer_alarm_config_t com new_period → re-arma           │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────────────────────┘
```

## 2. Ciclo de Vida v2

```
app_main() [Core 0]
    │
    ├── hal_stepper_init()
    ├── hal_endstop_init()
    ├── hal_extruder_init()
    ├── uart_driver_install(...)
    │
    ├── Cria primitivas FreeRTOS:
    │   ├── cmd_queue      = xQueueCreate(10, 96)
    │   ├── motion_queue   = xQueueCreate(8,  sizeof(motion_cmd_t))
    │   ├── planner_queue  = xQueueCreate(16, sizeof(motion_block_t))
    │   ├── state_mutex    = xSemaphoreCreateMutex()
    │   ├── uart_tx_mutex  = xSemaphoreCreateMutex()
    │   └── motion_event_group = xEventGroupCreate()
    │
    ├── Inicializa g_state: { IDLE, 0.0, 0.0, DEFAULT_FEEDRATE, false, true }
    │
    ├── xTaskCreate(uart_task,    2048, Prio 2)
    ├── xTaskCreate(parser_task,  4096, Prio 3)
    ├── xTaskCreate(planner_task, 4096, Prio 3)
    ├── xTaskCreate(monitor_task, 2048, Prio 1)
    └── xTaskCreatePinnedToCore(executor_task, 4096, Prio 4, core=1)
        │
        └── [dentro do executor_task, após iniciar]:
            gptimer_new_timer() → gptimer_register_event_callbacks()
            → gptimer_enable() → (timer pronto, aguarda blocos)

    app_main → vTaskDelete(NULL)
    [FreeRTOS scheduler toma controle]
```

## 3. Responsabilidades Detalhadas por Tarefa

### UARTTask
| Aspecto | Detalhe |
|---------|---------|
| Produz | `char[96]` em `cmd_queue` |
| Consome | Bytes do UART ring buffer |
| Resposta ao '?' | Imediata — não vai para cmd_queue |
| Timeout send | 0 (não bloqueia — descarta se fila cheia) |
| Bloqueia em | `uart_read_bytes(..., portMAX_DELAY)` |

### GCodeParserTask
| Aspecto | Detalhe |
|---------|---------|
| Produz | `motion_cmd_t` em `motion_queue` |
| Consome | `char[96]` de `cmd_queue` |
| Comandos tratados | G0, G1, G28, G90, G91, M3, M5, M114, F |
| ok/error | Enviados via `uart_tx_mutex` após enfileirar |
| Timeout send | `portMAX_DELAY` — back-pressure correto |
| M3/M5 sem XY | `CMD_EXTRUDER_ONLY` com posição atual |

### MotionPlannerTask
| Aspecto | Detalhe |
|---------|---------|
| Produz | `motion_block_t` em `planner_queue` |
| Consome | `motion_cmd_t` de `motion_queue` |
| Cálculos | Bresenham, trapezoidal, conversão mm→steps |
| Bloco extrusor | `total_steps=0`, `extruder_action` preenchido |
| Timeout send | `portMAX_DELAY` — bloqueia se planner cheio |

### MotionExecutorTask (Core 1)
| Aspecto | Detalhe |
|---------|---------|
| Produz | Sinais de evento em `motion_event_group` |
| Consome | `motion_block_t` de `planner_queue` |
| Cria GPTimer | Dentro da própria task (garante ISR no Core 1) |
| Extrusor | `hal_extruder_on/off()` antes de cada bloco |
| Bloqueia em | `xTaskNotifyWait(portMAX_DELAY)` |

### MonitorTask
| Aspecto | Detalhe |
|---------|---------|
| Produz | `EVENT_ALARM` se detectar anomalia |
| Consome | Estado das filas (polling), `state_mutex` |
| Período | `vTaskDelay(pdMS_TO_TICKS(1000))` |
| Responsabilidade | Watchdog de saúde — não interfere no fluxo |


# Diagrama de Filas e Primitivas FreeRTOS — v2

## 1. Mapa Completo de IPC

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                    PRIMITIVAS FREERTOS v2 — FLUXO COMPLETO                  │
│                                                                             │
│  ╔══════════╗──────'?'─────────────────────────────────────────────────    │
│  ║ UARTTask ║  (detecção direta, bypassa todas as filas)                    │
│  ╚═════╤════╝──────────────────────────────────────────────────────────    │
│        │ cmd_queue (10 × 96 bytes)                                          │
│        ▼                                                                    │
│  ╔═════════════════╗                                                        │
│  ║ GCodeParserTask ║── M114 / ok / error ──► uart_tx_mutex ──► UART TX     │
│  ╚═══════╤═════════╝                                                        │
│          │ motion_queue (8 × motion_cmd_t)                                  │
│          ▼                                                                  │
│  ╔═════════════════════╗                                                    │
│  ║  MotionPlannerTask  ║                                                    │
│  ╚═══════╤═════════════╝                                                    │
│          │ planner_queue (16 × motion_block_t)  ← NOVO — 16 slots          │
│          ▼                                                                  │
│  ╔═════════════════════╗                                                    │
│  ║ MotionExecutorTask  ║──── xTaskNotifyFromISR ──── [GPTimer ISR]          │
│  ╚═════════════════════╝                                                    │
│          │ state_mutex (leitura/escrita de g_state)                         │
│          ├─────────────────────────────────────────────────────────────    │
│          │                                                                  │
│  ╔═══════╧═══════╗                                                          │
│  ║  MonitorTask  ║ (lê filas via uxQueueSpacesAvailable — não consome)      │
│  ╚═══════════════╝                                                          │
│                                                                             │
│  ─────────────────────────────────────────────────────────────────────     │
│  MUTEXES                                                                    │
│                                                                             │
│  state_mutex     ──► protege system_state_t g_state                        │
│                      escritores: MotionExecutor, GCodeParser (G90/G91)     │
│                      leitores: UARTTask ('?'), GCodeParser (M114/G91)      │
│                                                                             │
│  uart_tx_mutex   ──► protege uart_write_bytes() — NOVO (crítico)           │
│                      usuários: UARTTask ('?'), GCodeParser (ok/error/M114) │
│                                                                             │
│  ─────────────────────────────────────────────────────────────────────     │
│  EVENT GROUP: motion_event_group (3 bits ativos)                            │
│                                                                             │
│  BIT0: EVENT_HOMING_DONE  ← MotionExecutor ao concluir G28                 │
│  BIT1: EVENT_BLOCK_DONE   ← GPTimer ISR ao concluir bloco                  │
│  BIT2: EVENT_ALARM        ← MonitorTask ou Executor em erro                │
│  (BIT3 removido: EVENT_STATUS_REQ não existe mais)                          │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

## 2. Especificação Detalhada das Filas

### cmd_queue
| Atributo | v1 | v2 | Justificativa da mudança |
|----------|----|----|--------------------------|
| Tipo de item | `char[128]` | `char[96]` | G-Code real: max ~80 chars. 96 bytes com margem |
| Capacidade | 10 itens | 10 itens | Mantido — buffer razoável para burst do host |
| RAM total | ~1.280 bytes | ~960 bytes | -25% sem impacto funcional |
| Timeout produtor | `0` | `0` | Descarte intencional — host respeita ok/error |
| Timeout consumidor | `portMAX_DELAY` | `portMAX_DELAY` | Parser aguarda |

**Nota:** 96 bytes cobre qualquer linha G-Code válida, incluindo comentários inline.
A linha mais longa possível neste sistema: `G1 X-999.999 Y-999.999 F99999.9 ; comentario\n`
= 52 caracteres. Margem de 44 bytes.

### motion_queue
| Atributo | v1 | v2 | Justificativa da mudança |
|----------|----|----|--------------------------|
| Tipo de item | `motion_cmd_t` (~36 bytes) | `motion_cmd_t` (~40 bytes) | +4 bytes para `extruder_action` |
| Capacidade | 5 itens | 8 itens | Maior buffer entre Parser e Planner — menos stalls |
| RAM total | ~180 bytes | ~320 bytes | +140 bytes — justificado |
| Timeout produtor | `100ms` ❌ | `portMAX_DELAY` ✓ | Back-pressure correto; ok só enviado após aceite |
| Timeout consumidor | `portMAX_DELAY` | `portMAX_DELAY` | Mantido |

**Por que portMAX_DELAY no produtor?**

Com timeout de 100ms na v1, se a fila estivesse cheia por 101ms, o Parser:
1. Tentava enviar por 100ms
2. Desistia
3. Enviava `ok\n` mesmo assim (bug! — o comando foi descartado)

Com `portMAX_DELAY`, o Parser bloqueia até haver espaço. O host não recebe `ok`
até o firmware estar pronto. Isso é exatamente o protocolo GRBL.

### planner_queue (substitui block_queue)
| Atributo | v1 (block_queue) | v2 (planner_queue) | Justificativa |
|----------|------------------|--------------------|---------------|
| Tipo de item | `motion_block_t` (~64 bytes) | `motion_block_t` (~80 bytes) | +16 bytes para extruder_action e padding |
| Capacidade | 3 itens | **16 itens** | Lookahead adequado; anti-starvation |
| RAM total | ~272 bytes | ~1.360 bytes | +1.088 bytes — investimento correto |
| Timeout produtor | `portMAX_DELAY` | `portMAX_DELAY` | Mantido — Planner bloqueia se Executor lento |
| Timeout consumidor | `portMAX_DELAY` | `portMAX_DELAY` | Mantido |

**Análise de starvation com 16 slots:**

Cenário típico de deposição (movimentos curtos de 1–5mm):
```
Tempo de execução de 1mm a 600mm/min: 100ms
Tempo de planejamento de 1 bloco: ~500µs

Buffer = 16 blocos × 100ms = 1.600ms de lookahead

Para starvation acontecer: Parser precisaria parar por > 1.6 segundos
→ Praticamente impossível em condições normais de operação
```

**Mapeamento conceitual Planner Buffer ↔ GRBL:**

| GRBL | Este projeto |
|------|-------------|
| `block_buffer[]` (array circular) | `planner_queue` (FreeRTOS queue) |
| `block_buffer_head` | índice de escrita da queue (interno ao FreeRTOS) |
| `block_buffer_tail` | índice de leitura da queue (interno ao FreeRTOS) |
| `BLOCK_BUFFER_SIZE = 16` | capacidade = 16 |
| `plan_get_current_block()` | `xQueuePeek(planner_queue, ...)` |

A FreeRTOS queue implementa exatamente o buffer circular do GRBL, mas com
thread-safety nativa, sem precisar implementar manualmente os índices.

## 3. Especificação dos Mutexes

### state_mutex
| Atributo | Valor |
|----------|-------|
| Tipo | `xSemaphoreCreateMutex()` (com priority inheritance) |
| Protege | `system_state_t g_state` |
| Escritores | MotionExecutorTask (mpos, status), GCodeParserTask (mode, feedrate) |
| Leitores | UARTTask ('?'), GCodeParserTask (M114, G91), MonitorTask |
| Timeout máximo | 5ms em todos os acessos |
| Uso em ISR | **Proibido** — ISR usa g_isr_ctx isoladamente |

### uart_tx_mutex  ← NOVO
| Atributo | Valor |
|----------|-------|
| Tipo | `xSemaphoreCreateMutex()` |
| Protege | `uart_write_bytes()` — saída serial |
| Usuários | UARTTask ('?'), GCodeParserTask (ok/error/M114) |
| Timeout | `portMAX_DELAY` — nunca descartar resposta |
| Uso em ISR | **Proibido** — nenhuma resposta serial dentro de ISR |

## 4. Especificação do Event Group

### motion_event_group (3 bits)
```
BIT0: EVENT_HOMING_DONE
  Sinalizado por: MotionExecutorTask ao completar sequência G28
  Aguardado por:  GCodeParserTask (para sincronizar resposta 'ok' do G28)

BIT1: EVENT_BLOCK_DONE
  Sinalizado por: GPTimer ISR via xEventGroupSetBitsFromISR()
                  OU via xTaskNotifyFromISR diretamente ao Executor
  Aguardado por:  MotionExecutorTask

BIT2: EVENT_ALARM
  Sinalizado por: MotionExecutorTask (endstop inesperado), MonitorTask
  Aguardado por:  MotionExecutorTask (sai do wait), GCodeParserTask (monitora)
```

**Nota sobre EVENT_BLOCK_DONE:** Preferir `xTaskNotifyFromISR` (comunicação direta
ISR → Executor) ao invés de event group. O event group requer `xHigherPriorityTaskWoken`
e é ligeiramente mais pesado. Usar event group apenas para HOMING_DONE e ALARM
(comunicação entre tasks, não ISR→task).

## 5. Diagrama de Contenção

```
Qual tarefa pode bloquear qual?

UARTTask (Prio 2)
  ├── Bloqueia em uart_read_bytes (hardware, não FreeRTOS)
  ├── Bloqueia em state_mutex (leitura de 5ms max)
  └── Bloqueia em uart_tx_mutex (escrita de ok)

GCodeParserTask (Prio 3)
  ├── Bloqueia em cmd_queue (portMAX_DELAY — aguarda UARTTask)
  ├── Bloqueia em motion_queue send (portMAX_DELAY — aguarda Planner)
  ├── Bloqueia em state_mutex (G90/G91/M114)
  └── Bloqueia em uart_tx_mutex (ok/error/M114)

MotionPlannerTask (Prio 3)
  ├── Bloqueia em motion_queue recv (portMAX_DELAY — aguarda Parser)
  └── Bloqueia em planner_queue send (portMAX_DELAY — aguarda Executor)

MotionExecutorTask (Prio 4 — Core 1)
  ├── Bloqueia em planner_queue recv (portMAX_DELAY)
  ├── Bloqueia em xTaskNotifyWait (portMAX_DELAY — aguarda ISR)
  └── Bloqueia em state_mutex (atualização de posição — 5ms max)

MonitorTask (Prio 1)
  ├── Bloqueia em vTaskDelay(1000ms)
  └── Bloqueia em state_mutex (leitura — 5ms max)

→ Nenhum ciclo de dependência = sem deadlock possível ✓
```

## 6. Fluxo de Back-Pressure (v2 corrigido)

```
Host envia comandos rapidamente (arquivo G-Code longo):

  UART → cmd_queue (10 slots)
              ↓ GCodeParser (rápido — ~100µs/linha)
         motion_queue (8 slots)
              ↓ Planner (médio — ~500µs/bloco)
         planner_queue (16 slots)
              ↓ Executor (lento — tempo real, governa tudo)
           GPTimer ISR

Se Executor está consumindo a 600mm/min (10mm/s):
  Cada bloco de 1mm leva 100ms
  16 blocos = 1.6s de buffer

  O back-pressure natural:
  planner_queue cheia → Planner bloqueia (portMAX_DELAY)
  motion_queue cresce → Parser bloqueia (portMAX_DELAY)
  cmd_queue cresce → UARTTask não pode enfileirar (timeout 0: descarta)
  Host não recebe 'ok' → Para de enviar

  → Sistema auto-regula. Host responsável por não enviar sem 'ok'.
```


# Fluxograma de Processamento G-Code — v2

## 1. Pipeline Completo v2

```
                         ┌─────────────────────────┐
                         │   HOST (PC / Software)   │
                         └────────────┬────────────┘
                                      │ USB Serial
                                      ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│ UARTTask                                                                    │
│                                                                             │
│  ┌────────────┐    ┌──────────────────────────────────────────────────┐   │
│  │uart_read() │───►│ Para cada byte recebido:                         │   │
│  │(bloqueante)│    │                                                  │   │
│  └────────────┘    │  if (byte == '?') ──────────────────────────►   │   │
│                    │      state_mutex (5ms)                           │   │
│                    │      snap = g_state                              │   │
│                    │      uart_tx_mutex → grbl_send_status() ──► TX  │   │
│                    │      continue   ← NÃO acumula no buffer         │   │
│                    │                                                  │   │
│                    │  buffer[idx++] = byte                            │   │
│                    │  if (byte == '\n'):                              │   │
│                    │      xQueueSend(cmd_queue, buf, 0)  ← timeout 0 │   │
│                    │      idx = 0                                     │   │
│                    └──────────────────────────────────────────────────┘   │
└───────────────────────────────────────────────┬─────────────────────────────┘
                                                │ cmd_queue
                                                ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│ GCodeParserTask                                                             │
│                                                                             │
│  xQueueReceive(cmd_queue, portMAX_DELAY)                                   │
│          │                                                                  │
│          ▼                                                                  │
│  Linha vazia / comentário ';'? ──Sim──► descarta, sem resposta             │
│          │ Não                                                              │
│          ▼                                                                  │
│  Tokeniza: extrai pares letra+número (G, M, X, Y, F)                       │
│          │                                                                  │
│          ├──── G90 / G91 ──────────────────────────────────────────────►  │
│          │                    state_mutex → atualiza position_absolute     │
│          │                    uart_tx_mutex → "ok\n"                       │
│          │                                                                  │
│          ├──── M114 ───────────────────────────────────────────────────►  │
│          │                    state_mutex → lê mpos_x, mpos_y             │
│          │                    uart_tx_mutex → "X:%.3f Y:%.3f\n" + "ok\n" │
│          │                                                                  │
│          ├──── M3 / M5 ────────────────────────────────────────────────►  │
│          │           Cria motion_cmd_t:                                    │
│          │             type = CMD_EXTRUDER_ONLY                            │
│          │             target = posição atual (sem movimento)              │
│          │             extruder_action = 1 (M3) ou 0 (M5)                 │
│          │           → motion_queue (portMAX_DELAY)                        │
│          │           → uart_tx_mutex "ok\n"                                │
│          │                                                                  │
│          ├──── G0 / G1 ────────────────────────────────────────────────►  │
│          │           Resolve coordenadas:                                  │
│          │             if G90: target = values_parsed                      │
│          │             if G91: target = mpos + values_parsed               │
│          │           Cria motion_cmd_t:                                    │
│          │             type = CMD_MOVE_G0 ou CMD_MOVE_G1                   │
│          │             target_x, target_y, feedrate                        │
│          │             extruder_action = -1 (sem mudança)                  │
│          │           → motion_queue (portMAX_DELAY)                        │
│          │           → uart_tx_mutex "ok\n"                                │
│          │                                                                  │
│          └──── G28 ─────────────────────────────────────────────────────►  │
│                    Cria motion_cmd_t { type = CMD_HOMING }                 │
│                    → motion_queue (portMAX_DELAY)                          │
│                    xEventGroupWaitBits(EVENT_HOMING_DONE, portMAX_DELAY)  │
│                    uart_tx_mutex "ok\n"    ← só após homing concluir      │
│                                                                             │
│          Qualquer token desconhecido → uart_tx_mutex "error\n"             │
└─────────────────────────────────────────────────────────────────────────────┘
                              │
                              │ motion_queue
                              ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│ MotionPlannerTask                                                           │
│                                                                             │
│  xQueueReceive(motion_queue, portMAX_DELAY)                                │
│          │                                                                  │
│          ├── CMD_EXTRUDER_ONLY ──────────────────────────────────────────  │
│          │   Cria motion_block_t:                                          │
│          │     total_steps = 0                                              │
│          │     extruder_action = cmd.extruder_action                        │
│          │   → planner_queue (portMAX_DELAY)                               │
│          │                                                                  │
│          ├── CMD_MOVE_G0 / CMD_MOVE_G1 ──────────────────────────────────  │
│          │   1. Converte coordenadas → passos:                              │
│          │      steps_x = round((target_x - plan_x) * STEPS_PER_MM_X)     │
│          │      steps_y = round((target_y - plan_y) * STEPS_PER_MM_Y)     │
│          │                                                                  │
│          │   2. Parâmetros Bresenham:                                       │
│          │      dx = |steps_x|, dy = |steps_y|                             │
│          │      dominant = max(dx, dy), subordinate = min(dx, dy)          │
│          │      dominant_is_x = (dx >= dy)                                 │
│          │      dir_x = sign(steps_x), dir_y = sign(steps_y)              │
│          │      bresenham_error = dominant / 2  (erro inicial)             │
│          │                                                                  │
│          │   3. Perfil trapezoidal (G0 usa MAX_FEEDRATE):                  │
│          │      v_max = feedrate / 60.0  [mm/s]                            │
│          │      step_rate = v_max × STEPS_PER_MM                           │
│          │      Verifica movimento triangular: accel+decel > total         │
│          │      Calcula initial_period, min_period, increments             │
│          │                                                                  │
│          │   4. Atualiza plan_x, plan_y (posição de planejamento)          │
│          │   5. → planner_queue (portMAX_DELAY)                            │
│          │                                                                  │
│          └── CMD_HOMING ──────────────────────────────────────────────────  │
│              Cria motion_block_t especial { type = BLOCK_HOMING }          │
│              → planner_queue (portMAX_DELAY)                               │
└─────────────────────────────────────────────────────────────────────────────┘
                              │
                              │ planner_queue (16 slots)
                              ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│ MotionExecutorTask (Core 1)                                                 │
│                                                                             │
│  xQueueReceive(planner_queue, portMAX_DELAY)                               │
│          │                                                                  │
│          ├── BLOCK_HOMING ──► executa homing (ver fluxo G28 abaixo)       │
│          │                                                                  │
│          ├── total_steps == 0 (CMD_EXTRUDER_ONLY):                         │
│          │   hal_extruder_on/off(action)                                   │
│          │   state_mutex → g_state.extruder_on = action                   │
│          │   continua loop (sem GPTimer)                                   │
│          │                                                                  │
│          └── total_steps > 0 (movimento real):                             │
│              1. hal_extruder_on/off se extruder_action != -1               │
│              2. hal_stepper_set_dir(X, dir_x)                              │
│              3. hal_stepper_set_dir(Y, dir_y)                              │
│              4. hal_stepper_enable()                                        │
│              5. gptimer_stop() — garante timer parado                      │
│              6. portENTER_CRITICAL()                                        │
│                 g_isr_ctx = { block, step_count=0, ACCEL, initial_period } │
│                 portEXIT_CRITICAL()                                         │
│              7. state_mutex → g_state.status = STATE_RUN                  │
│              8. gptimer_set_alarm(initial_period_us)                       │
│              9. gptimer_start()                                             │
│             10. xTaskNotifyWait(BLOCK_DONE|ALARM, portMAX_DELAY) ← BLOQUEIA│
│             11. state_mutex → g_state.mpos_x/y += delta                   │
│             12. Se planner_queue vazia: g_state.status = STATE_IDLE        │
│             13. Loop                                                        │
└─────────────────────────────────────────────────────────────────────────────┘
```

## 2. Fluxo G28 (Homing) — v2

```
MotionExecutor recebe bloco BLOCK_HOMING:
    │
    ▼
state_mutex → g_state.status = STATE_HOMING

═══ FASE 1: Homing X ════════════════════════════════════════════════════════
    hal_stepper_set_dir(X, DIR_NEGATIVE)
    hal_stepper_enable()
    
    Loop de homing X (velocidade = HOMING_SPEED_STEPS_S):
        gptimer com period = 1e6 / HOMING_SPEED_STEPS_S
        A cada pulso da ISR (modo homing — ISR simplificada):
            hal_stepper_step(X)
            step_count++
            Verifica hal_endstop_read_x():
                true → sinaliza fim X
        Limite de segurança: se step_count > MAX_TRAVEL_STEPS_X: EVENT_ALARM
    
    Endstop X acionado:
        gptimer_stop()
        hal_stepper_disable()
        Recuo X: move +HOMING_PULLOFF_MM (direção oposta, velocidade reduzida)
        state_mutex → g_state.mpos_x = 0.0
        plan_x = 0  (Planner reset — importante!)

═══ FASE 2: Homing Y (mesmo procedimento) ═══════════════════════════════════

    state_mutex → g_state.mpos_y = 0.0
    plan_y = 0

═══ CONCLUSÃO ════════════════════════════════════════════════════════════════
    state_mutex → g_state.status = STATE_IDLE
    xEventGroupSetBits(EVENT_HOMING_DONE)
    
    ← GCodeParserTask estava bloqueado em xEventGroupWaitBits(HOMING_DONE)
    ← Agora desbloqueia e envia "ok\n"
```

## 3. Fluxo da ISR (GPTimer) — v2

```
gptimer_isr_callback() [IRAM_ATTR, Core 1]
    │
    ▼
ctx = &g_isr_ctx  ← leitura do contexto (sem lock — Executor garantiu exclusão)
    │
    ├── MODO NORMAL (movimento) ────────────────────────────────────────────
    │   │
    │   ├── Pulso no eixo dominante:
    │   │   gpio_set_level(STEP_dominant, 1)
    │   │   esp_rom_delay_us(2)          ← STEP pulse width ≥ 2µs
    │   │   gpio_set_level(STEP_dominant, 0)
    │   │
    │   ├── Bresenham eixo subordinado:
    │   │   ctx.error += ctx.subordinate
    │   │   if (ctx.error >= ctx.dominant):
    │   │       gpio_set_level(STEP_subordinate, 1)
    │   │       esp_rom_delay_us(2)
    │   │       gpio_set_level(STEP_subordinate, 0)
    │   │       ctx.error -= ctx.dominant
    │   │
    │   ├── Atualiza período trapezoidal:
    │   │   ACCEL:  ctx.period_us -= ctx.accel_increment
    │   │           clampa em min_period_us
    │   │   CRUISE: nenhuma mudança
    │   │   DECEL:  ctx.period_us += ctx.decel_increment
    │   │
    │   ├── Fase transition:
    │   │   if (step_count == accel_steps):  phase = CRUISE
    │   │   if (step_count == decel_start):  phase = DECEL
    │   │
    │   ├── ctx.step_count++
    │   │
    │   └── Fim de bloco?
    │       if (ctx.step_count >= ctx.total_steps):
    │           gptimer_stop_in_isr_context()
    │           BaseType_t woken = pdFALSE
    │           xTaskNotifyFromISR(executor_handle, BLOCK_DONE, eSetBits, &woken)
    │           portYIELD_FROM_ISR(woken)
    │       else:
    │           gptimer_alarm_config_t alarm = { .alarm_count = ctx.period_us }
    │           gptimer_set_alarm_action(timer, &alarm)  ← re-arma
    │
    └── MODO HOMING (ISR simplificada) ──────────────────────────────────────
        gpio_set_level(STEP_axis, 1)
        esp_rom_delay_us(2)
        gpio_set_level(STEP_axis, 0)
        ctx.homing_step_count++
        re-arma com period fixo (HOMING_SPEED)
        (verificação de endstop: polling no Executor, não na ISR)
```


# Análise de Desempenho e Limites — v2

## 1. Arquitetura de Limites em Três Camadas

### Camada 1 — GPTimer + ESP32 @ 240MHz

O GPTimer do ESP32-IDF tem resolução configurável.
Configuração padrão para este projeto: **clock base 1MHz (resolução 1µs)**.

```
Período mínimo do timer: 1µs  →  1.000.000 steps/s (teórico absoluto)
ISR overhead estimado:   ~1µs  →  período seguro mínimo: 5µs

Limite GPTimer prático:  200.000 steps/s  (período = 5µs)
```

Análise do tempo de ISR:

| Operação | Ciclos @ 240MHz | Tempo (ns) |
|----------|----------------|------------|
| Leitura g_isr_ctx (cache hit) | 1 | 4 |
| Bresenham (3 adições, 1 comp) | 6 | 25 |
| gpio_set_level (GPIO matrix) | 30 | 125 |
| esp_rom_delay_us(2) | 480 | 2.000 |
| gpio_set_level (clear) | 30 | 125 |
| Trapezoidal (2 adições, 1 comp) | 5 | 21 |
| Comparação fim de bloco | 3 | 13 |
| gptimer re-arm | 40 | 167 |
| **Total (pior caso — passo XY)** | **~600** | **~2.500 ns** |

O período mínimo seguro é **5µs** (passo simples) ou **7µs** (passo XY simultâneo)
para garantir que o próximo alarme não dispare durante a própria ISR.

### Camada 2 — Limites dos Drivers de Passo

| Driver | Freq. máx. (datasheet) | Largura mín. HIGH | Largura mín. LOW |
|--------|----------------------|-------------------|------------------|
| A4988  | 500 kHz | 1 µs | 1 µs |
| DRV8825| 250 kHz | 1.9 µs | 1.9 µs |

Usando `esp_rom_delay_us(2)` para HIGH → compatível com ambos.
O driver não é o gargalo neste projeto.

### Camada 3 — Motor + Mecânica (limite real)

O motor de passo perde torque com a frequência de passos. A frequência de pull-out
(acima da qual perde sincronismo) depende da tensão, corrente e carga mecânica.

Para um NEMA17 típico (42mm, 1.7A, 2.5V fase):

| Tensão de alimentação do driver | Frequência de pull-out típica |
|--------------------------------|-------------------------------|
| 12V (A4988 comum) | 600–1.000 RPM → 2.000–3.400 steps/s (full) |
| 24V (DRV8825 comum) | 1.200–2.000 RPM → 4.000–6.700 steps/s (full) |

Com microstepping, a frequência de passo aumenta (mais passos/rev) mas
o torque disponível diminui. Os valores acima valem para full step.

## 2. Tabela de Configurações Práticas

Para `STEPS_PER_MM = 80` (configuração de exemplo do projeto):

| Modo | Feedrate | Velocidade | Steps/s | Period (µs) | Seguro? |
|------|----------|-----------|---------|-------------|---------|
| Testes iniciais | 300 mm/min | 5 mm/s | 400 | 2.500 | ✓ Muito seguro |
| Operação normal | 600 mm/min | 10 mm/s | 800 | 1.250 | ✓ Seguro |
| Operação rápida | 1.500 mm/min | 25 mm/s | 2.000 | 500 | ✓ Seguro |
| Máximo recomendado | 3.000 mm/min | 50 mm/s | 4.000 | 250 | ✓ Margem 35× ISR |
| Avançado | 6.000 mm/min | 100 mm/s | 8.000 | 125 | ✓ Margem 17× ISR |

Para **STEPS_PER_MM diferentes** (outros mecanismos):

| Mecanismo | Steps/mm | Max feedrate recomendado | Steps/s máx |
|-----------|----------|--------------------------|-------------|
| Full step, fuso 2mm/rev | 100 | 2.400 mm/min | 4.000 |
| 1/8 step, fuso 8mm/rev | 200 | 1.200 mm/min | 4.000 |
| 1/16 step, fuso 8mm/rev | 400 | 600 mm/min | 4.000 |
| Full step, correia GT2 20T (40mm) | 5 | 48.000 mm/min | 4.000 |

**Conclusão:** A frequência de steps/s de ~4.000 a ~8.000 é a faixa prática segura
para NEMA17 com alimentação de 12–24V. O GPTimer e o driver não são os limitantes.

## 3. Parâmetros Recomendados para config.h

```c
// Velocidades (ajustar conforme mecanismo real)
#define DEFAULT_FEEDRATE_MM_MIN    600      // feedrate padrão ao ligar
#define MAX_FEEDRATE_MM_MIN        3000     // teto de segurança por software
#define HOMING_FEEDRATE_MM_MIN     300      // velocidade de homing (lenta)
#define HOMING_PULLOFF_MM          3.0f     // recuo após endstop

// Aceleração
#define ACCELERATION_MM_S2         500.0f   // 500 mm/s² (conservador)
#define MIN_SPEED_MM_S             0.5f     // velocidade mínima (evita stall em decel)

// Steps por mm (ajustar para o mecanismo)
#define STEPS_PER_MM_X             80.0f
#define STEPS_PER_MM_Y             80.0f

// GPTimer
#define GPTIMER_RESOLUTION_HZ      1000000  // 1MHz = resolução 1µs
#define MIN_STEP_PERIOD_US         10       // período mínimo seguro (10µs = 100kHz)
#define MAX_STEP_PERIOD_US         100000   // 100ms = velocidade mínima (10 steps/s)
```

## 4. Análise do Pior Caso de Timing (WCET Revisada)

### ISR em condições adversas

Pior caso: passo simultâneo em X e Y (dois gpio_set_level + delay por eixo):

```
Tempo total ISR pior caso:
  gpio_set X:     125ns
  delay:        2.000ns
  gpio_clear X:   125ns
  Bresenham:       25ns
  gpio_set Y:     125ns
  delay:        2.000ns
  gpio_clear Y:   125ns
  Trapezoidal:     21ns
  Re-arm timer:   167ns
  Total:       ~4.713ns ≈ 5µs

Período mínimo seguro: 2× WCET = 10µs → 100.000 steps/s máximo prático
```

Para o feedrate máximo recomendado de 3.000 mm/min = 50 mm/s:
- Pior caso: STEPS_PER_MM = 400 (1/16 step, fuso 8mm)
- Steps/s = 50 × 400 = 20.000
- Period = 50µs
- Margem: 50µs / 10µs = **5× acima do mínimo seguro** ✓

### Latência de resposta ao '?'

```
v2 — UARTTask responde diretamente:

  Byte '?' chega
  UART ISR move para buffer interno ESP-IDF:  ~1µs
  UARTTask acorda (do uart_read_bytes):       ~500µs (scheduler)
  Detecta '?', tenta state_mutex:             ~5µs (contention rara)
  Lê g_state (struct copy):                  ~100ns
  grbl_send_status(): formata + uart_write:  ~200µs (à 115200 bps, ~22 bytes)

  Total: ~700µs

  v1 (via Parser + MonitorTask): ~2-5ms

  Melhoria: 3-7× mais rápido ✓
```

# Estrutura de Diretórios — v2

## 1. Árvore Completa

```
xy_gcode_firmware/
│
├── CMakeLists.txt
├── sdkconfig.defaults
│
├── main/
│   ├── CMakeLists.txt
│   └── main.c                       ← app_main(): inicializa HAL, cria primitivas
│                                       FreeRTOS (filas, mutexes, event group),
│                                       cria 5 tarefas, deleta a si mesmo
│
├── components/
│   │
│   ├── config/
│   │   └── include/
│   │       └── config.h             ← Todos os parâmetros ajustáveis:
│   │                                   GPIO pins, STEPS_PER_MM, ACCELERATION,
│   │                                   MAX_FEEDRATE, HOMING_SPEED, queue sizes,
│   │                                   GPTIMER_RESOLUTION_HZ, driver selection
│   │
│   ├── hal/
│   │   ├── include/
│   │   │   ├── hal_stepper.h        ← init/set_dir/step/enable/disable
│   │   │   ├── hal_endstop.h        ← init/read_x/read_y
│   │   │   └── hal_extruder.h       ← init/on/off/is_on
│   │   └── src/
│   │       ├── hal_stepper.c        ← Compilação condicional A4988/DRV8825
│   │       ├── hal_endstop.c        ← GPIO input com pull-up, debounce
│   │       └── hal_extruder.c       ← GPIO output simples
│   │
│   ├── gcode/
│   │   ├── include/
│   │   │   ├── gcode_types.h        ← motion_cmd_t, motion_block_t,
│   │   │   │                           system_state_t, machine_state_t
│   │   │   └── gcode_parser.h       ← interface do parser
│   │   └── src/
│   │       └── gcode_parser.c       ← tokenização, extração de palavras,
│   │                                   resolução G90/G91, M114
│   │
│   ├── planner/
│   │   ├── include/
│   │   │   └── motion_planner.h
│   │   └── src/
│   │       └── motion_planner.c     ← Bresenham + trapezoidal
│   │                                   Mantém plan_x/plan_y (posição de planejamento)
│   │                                   Separada de g_state.mpos (posição de execução)
│   │
│   ├── executor/
│   │   ├── include/
│   │   │   └── motion_executor.h
│   │   └── src/
│   │       ├── motion_executor.c    ← MotionExecutorTask, homing
│   │       └── step_generator.c    ← g_isr_ctx, gptimer_isr_callback (IRAM_ATTR)
│   │
│   ├── protocol/
│   │   ├── include/
│   │   │   └── grbl_protocol.h     ← grbl_send_ok/error/status/position
│   │   └── src/
│   │       └── grbl_protocol.c     ← todas as funções adquirem uart_tx_mutex
│   │
│   ├── system/
│   │   ├── include/
│   │   │   └── system_state.h      ← system_state_t, handles globais de todas
│   │   │                              as primitivas FreeRTOS (extern)
│   │   └── src/
│   │       └── system_state.c      ← definição das variáveis globais,
│   │                                  função de inicialização
│   │
│   └── tasks/
│       ├── include/
│       │   ├── task_uart.h
│       │   ├── task_gcode_parser.h
│       │   ├── task_motion_planner.h
│       │   ├── task_motion_executor.h
│       │   └── task_monitor.h
│       │   (task_extruder.h REMOVIDO)
│       └── src/
│           ├── task_uart.c
│           ├── task_gcode_parser.c
│           ├── task_motion_planner.c
│           ├── task_motion_executor.c
│           └── task_monitor.c
│           (task_extruder.c REMOVIDO)
│
└── docs/
    ├── architecture/        ← v1 (arquivado)
    └── architecture/v2/     ← versão atual (este diretório)
```

## 2. Nota Importante: Duas Posições no Sistema

Um detalhe arquitetural que deve ser explicitado:

```
plan_x, plan_y     ← posição de PLANEJAMENTO (atualizada pelo Planner)
g_state.mpos_x/y   ← posição de EXECUÇÃO (atualizada pelo Executor)
```

Estas duas posições podem divergir temporariamente quando há blocos na planner_queue
ainda não executados. O Planner precisa de `plan_x/y` para calcular deltas corretamente
para blocos futuros. O host/monitor usa `g_state.mpos_x/y` para saber onde a ferramenta
fisicamente está.

M114 e '?' respondem com `g_state.mpos` (posição real da ferramenta).
O Parser usa `plan_x/y` para resolver coordenadas G91 (relativas).

```
┌─────────────────────────────────────────────────────────────┐
│  Host envia: G1 X10 / G1 X20 / M114                        │
│                                                             │
│  Planner processa G1 X10 → plan_x = 10, bloco na fila      │
│  Planner processa G1 X20 → plan_x = 20, bloco na fila      │
│  Parser processa M114 → responde g_state.mpos_x = ?        │
│                                                             │
│  Se Executor ainda não executou nada: mpos_x = 0.0         │
│  Se Executor executou G1 X10: mpos_x = 10.0               │
│  Se Executor executou G1 X20: mpos_x = 20.0               │
└─────────────────────────────────────────────────────────────┘
```

Esta divergência é intencional e documentada. Para M114 com sequenciamento exato,
seria necessário um bloco de consulta na fila — fora do escopo deste projeto.


# Auditoria Final — Arquitetura v2

## 1. Diagrama de Estado da Máquina

```
                    ┌──────────────────────────────────────────────────┐
                    │               ESTADOS DA MÁQUINA                 │
                    │                                                  │
                    │          ┌─────────┐                            │
                    │    G28 ──►  HOMING │── concluído ──►            │
                    │          └────┬────┘                            │
                    │               │ EVENT_HOMING_DONE               │
                    │               ▼                                  │
         ligou ────────────────► IDLE ◄─── planner_queue vazia ───   │
                    │              │                                   │
                    │     G0/G1 ───┘ (bloco enfileirado)              │
                    │              │                                   │
                    │              ▼                                   │
                    │            RUN ──── endstop inesperado ──►      │
                    │              │                                   │
                    │     planner  │ fila vazia                       │
                    │     vazia    ▼                                   │
                    │           IDLE                                   │
                    │                                                  │
                    │  qualquer estado ──► ALARM ──── reset ──► IDLE  │
                    └──────────────────────────────────────────────────┘
```

## 2. Condições de Corrida — Status Final

| ID | Descrição | Status v2 | Mitigação |
|----|-----------|-----------|-----------|
| CR-01 | g_isr_ctx escrito enquanto ISR ativa | ✓ Resolvido | gptimer_stop antes de escrever |
| CR-02 | g_state com múltiplos escritores/leitores | ✓ Resolvido | state_mutex (priority inheritance) |
| CR-03 | UART TX sem sincronização | ✓ Resolvido | uart_tx_mutex em grbl_protocol.c |
| CR-04 | planner_queue escrita/leitura concurrent | ✓ Sem risco | FreeRTOS Queue é thread-safe |
| CR-05 | plan_x/y diverge de g_state.mpos | ✓ Intencional | Documentado — comportamento correto |

## 3. Análise de Deadlock — Status Final

**Grafos de dependência de locks (ordem de aquisição):**

```
Tarefa              Sequência de locks possível
─────────────────────────────────────────────────────────────
UARTTask            state_mutex → uart_tx_mutex (em resposta a '?')
GCodeParserTask     state_mutex (breve) → uart_tx_mutex (ok/M114)
                    OU motion_queue (portMAX_DELAY) → uart_tx_mutex
MotionExecutorTask  state_mutex (breve, sempre após liberar outros)
MonitorTask         state_mutex (breve, apenas leitura)
MotionPlannerTask   Nenhum mutex — apenas operações de fila
```

**Verificação circular:**
- Existe alguma tarefa que adquire uart_tx_mutex e depois state_mutex? **Não.**
- Existe alguma tarefa que adquire state_mutex e depois tenta motion_queue + state_mutex? **Não.**
- Existe alguma tarefa que espera duas FreeRTOS queues simultaneamente? **Não.**

**Conclusão: sem possibilidade de deadlock.** ✓

## 4. Análise de Priority Inversion — Status Final

FreeRTOS mutexes criados com `xSemaphoreCreateMutex()` implementam
**priority inheritance** automaticamente.

Cenário de inversion resolvido pelo FreeRTOS:
```
MotionExecutorTask (Prio 4) tenta adquirir state_mutex
GCodeParserTask (Prio 3) está segurando state_mutex

FreeRTOS:
  → Promove temporariamente GCodeParserTask para Prio 4
  → GCodeParserTask completa sua seção crítica mais rapidamente
  → Libera state_mutex
  → MotionExecutorTask adquire, continua
  → GCodeParserTask volta a Prio 3
```

Não é necessário nenhum código adicional — o mecanismo é automático. ✓

## 5. Pontos de Atenção para a Implementação (v2)

### Regras absolutas (devem virar comentários de asserção no código)

1. **IRAM_ATTR obrigatório**: `gptimer_isr_callback()` e todas as funções
   que ele chama: `hal_stepper_step()`, `esp_rom_delay_us()`.
   Falha silenciosa: ISR carregada da flash = latência imprevisível.

2. **Proibido em ISR**: `state_mutex`, `uart_tx_mutex`, `xQueueSend/Receive`,
   qualquer função que possa bloquear. Usar apenas versões `FromISR`.

3. **GPTimer criado no Executor**: O GPTimer deve ser criado e habilitado
   dentro de `task_motion_executor.c` (não no `app_main`), para garantir
   que a ISR seja registrada no Core 1.

4. **gptimer_stop antes de escrever g_isr_ctx**: Nunca atualizar g_isr_ctx
   com o timer rodando. Sequência obrigatória: stop → seção crítica → escreve → start.

5. **plan_x/y vs g_state.mpos**: O Planner atualiza `plan_x/y`. O Executor
   atualiza `g_state.mpos`. São variáveis diferentes com propósitos diferentes.
   Nunca misturar.

6. **uart_tx_mutex via grbl_protocol.c**: Nenhuma tarefa deve chamar
   `uart_write_bytes()` diretamente. Toda saída serial passa pelas funções
   de `grbl_protocol.c` que já gerenciam o mutex.

7. **Homing reseta plan_x/y**: Após G28, o Executor atualiza `g_state.mpos = 0`
   e também deve notificar o Planner para resetar `plan_x/y = 0`. Mecanismo:
   flag protegida por mutex ou campo dedicado em g_state.

### Sequência de inicialização obrigatória

```
1. hal_extruder_init()         ← extrusor desligado (nível inicial seguro)
2. hal_endstop_init()          ← GPIO com pull-up
3. hal_stepper_init()          ← driver desabilitado (EN = HIGH)
4. uart_driver_install()       ← UART configurado antes das tasks
5. Criar TODOS os objetos FreeRTOS (filas, mutexes, event group)
6. Inicializar g_state = {IDLE, 0, 0, DEFAULT_FEEDRATE, false, true}
7. Criar tasks (nunca antes dos passos 1-6)
8. vTaskDelete(NULL)
```

## 6. Avaliação Final da Arquitetura v2

### Robustez
| Critério | Nota | Observação |
|----------|------|------------|
| Sincronização de concorrência | A | Todos os acessos compartilhados protegidos |
| Sequenciamento de comandos | A | Filas garantem ordem; extrusor embedded no bloco |
| Tratamento de alarme | B+ | EVENT_ALARM existe; recovery completo não implementado |
| Limites de segurança | B | Max feedrate por software; sem soft limits de posição |

### Simplicidade
| Critério | Nota | Observação |
|----------|------|------------|
| Número de tarefas | A | 5 tarefas — mínimo funcional para demonstrar FreeRTOS |
| Primitivas FreeRTOS | A | 1 cmd_q, 1 motion_q, 1 planner_q, 2 mutex, 1 event_group |
| Linhas de código estimadas | A | ~1.500–2.000 linhas total (excl. Doxygen) |

### Uso correto do FreeRTOS
| Primitiva | Uso correto? | Observação |
|-----------|-------------|------------|
| Queue | ✓ | Back-pressure via portMAX_DELAY no produtor |
| Mutex | ✓ | Priority inheritance ativo automaticamente |
| Event Group | ✓ | Multi-bit para eventos ortogonais (DONE vs ALARM) |
| TaskNotify | ✓ | ISR→Task: mais leve que semáforo, carrega 32 bits |
| vTaskDelay | ✓ | Apenas no MonitorTask (background, não crítico) |
| Sem polling ativo | ✓ | Todas as tasks bloqueiam em primitiva FreeRTOS |

### Facilidade de Implementação
| Módulo | Complexidade | Dependências |
|--------|-------------|-------------|
| HAL (stepper, endstop, extruder) | Baixa | Apenas ESP-IDF GPIO |
| system_state.c | Baixa | Apenas FreeRTOS |
| grbl_protocol.c | Baixa | uart_tx_mutex |
| task_uart.c | Baixa | cmd_queue, state_mutex, uart_tx_mutex |
| gcode_parser.c | Média | Tokenização de string |
| task_gcode_parser.c | Média | gcode_parser + filas |
| motion_planner.c | Alta | Bresenham + trapezoidal |
| step_generator.c | Alta | IRAM_ATTR, GPTimer API, ISR constraints |
| task_motion_executor.c | Média-Alta | GPTimer + homing + g_isr_ctx |

### Qualidade para Apresentação Acadêmica
| Critério | Avaliação |
|----------|-----------|
| Demonstra FreeRTOS claramente | ✓ 5 tarefas com papéis distintos e comunicação explícita |
| Demonstra sistemas em tempo real | ✓ ISR com GPTimer, sem polling |
| Demonstra HAL | ✓ Troca de driver por #define sem alterar lógica |
| Demonstra pipeline de processamento | ✓ UART → Parser → Planner → Executor → ISR |
| Demonstra concorrência e sincronização | ✓ 3 tipos de primitiva, problema de race condition resolvido |
| Código documentável com Doxygen | ✓ Interfaces bem definidas em .h separados |
| Comparável com sistemas reais (GRBL) | ✓ Mesmo conceito de planner buffer, protocolo serial compatível |

## 7. Decisão Final

**A arquitetura v2 está aprovada para implementação.**

Não há problemas abertos que justifiquem mais revisão antes de gerar código.
Todos os riscos identificados têm mitigação documentada.
A complexidade está calibrada para um projeto acadêmico de demonstração — nem
trivial demais para não demonstrar os conceitos, nem complexa a ponto de ser
inimplementável no escopo do trabalho.

```
APROVADO — Iniciar Etapa 2: Implementação dos módulos base.
```


# Revisão Técnica de Engenharia — Arquitetura XY G-Code ESP32
## Versão: v1 → v2  |  Status: REVISÃO COMPLETA

---

## Sumário Executivo

A arquitetura v1 é funcionalmente correta, mas contém **seis problemas estruturais** que
afetariam a qualidade da implementação:

| # | Problema | Severidade | Decisão |
|---|----------|-----------|---------|
| 1 | ExtruderTask superdimensionada para controle ON/OFF | Média | Remover — absorver na pipeline de movimento |
| 2 | Comando '?' passa pelo Parser — latência desnecessária | Alta | Mover para UARTTask como comando de tempo real |
| 3 | UART TX sem mutex — múltiplas tarefas escrevem sem sincronização | **Crítica** | Adicionar uart_tx_mutex (problema não identificado na v1) |
| 4 | block_queue com 3 slots — starvation em movimentos curtos | Alta | Aumentar para planner_queue com 16 slots |
| 5 | Limite de velocidade fixo em ~3000 steps/s sem justificativa | Baixa | Substituir por análise em três camadas |
| 6 | Timeout de 100ms no motion_queue send — protocolo ok/error incorreto | Média | Substituir por portMAX_DELAY + back-pressure explícito |

Adicionalmente, dois recursos foram incorporados:
- **M114** (consulta de posição): integrado ao GCodeParserTask
- **Sequenciamento do extrusor**: corrigido via embedding no motion_block_t

---

## Ponto 1: Remoção da ExtruderTask

### Diagnóstico

A ExtruderTask v1 executa esta lógica:
```
extruder_queue → gpio_set_level(EXTRUDER_PIN, ON/OFF) → atualiza flag no estado
```

Isso é equivalente a 4 linhas de código embrulhadas em uma tarefa inteira com stack de 1024 bytes,
contexto FreeRTOS e uma fila dedicada. O overhead é desproporcional à função.

### Problema de sequenciamento (não documentado na v1)

O problema real não é só a complexidade — é que a abordagem via fila separada **quebra o sequenciamento**:

```
Cenário de deposição:
  G1 X0 Y0          ← move para origem
  M3                 ← liga extrusor (deposita)
  G1 X100 Y0        ← move enquanto deposita
  M5                 ← desliga extrusor
  G1 X100 Y100      ← retorno rápido (sem deposição)
```

Com extruder_queue separada da motion_queue, existe uma condição de corrida:
o GCodeParser processa M3 e M5 e os enfileira em extruder_queue. Mas a ExtruderTask
consome extruder_queue independentemente do MotionExecutor. Se block_queue tiver
latência diferente de extruder_queue, M5 pode disparar antes ou durante G1 X100 Y0.

### Solução: embedding no motion_block_t

M3/M5 deixam de ser comandos independentes e passam a ser **atributos do bloco de movimento**:

```c
// motion_cmd_t (v2): extrusor como campo
typedef struct {
    motion_cmd_type_t type;   // G0, G1, G28
    float target_x;
    float target_y;
    float feedrate;
    int8_t extruder_action;   // -1 = sem mudança, 0 = desligar, 1 = ligar
} motion_cmd_t;
```

```c
// motion_block_t (v2): herdado do cmd
typedef struct {
    // ... todos os campos Bresenham e trapezoidal ...
    int8_t extruder_action;   // aplicado pelo Executor ANTES de iniciar o bloco
} motion_block_t;
```

Quando o GCodeParser encontra M3 ou M5 **sem movimento associado**:
- Cria um `motion_cmd_t` com `type = CMD_EXTRUDER_ONLY`, `target = posição atual`, `extruder_action`
- O Planner gera um bloco com `total_steps = 0` e o `extruder_action` correto
- O Executor executa o bloco (que é instantâneo), altera o GPIO, e passa ao próximo

Sequenciamento garantido: o extrusor só muda de estado quando o Executor chega àquele bloco na fila.

### Ganhos

| Recurso liberado | Quantidade |
|-----------------|-----------|
| Stack da ExtruderTask | 1024 bytes de RAM |
| Overhead TCB FreeRTOS | ~88 bytes |
| extruder_queue (5 × 4 bytes + overhead) | ~100 bytes |
| Contexto de switch evitado | 1 tarefa a menos no scheduler |
| Linhas de código eliminadas | ~80 linhas |

---

## Ponto 2: Comando '?' como Comando de Tempo Real na UARTTask

### Diagnóstico do fluxo v1

```
'?' chega na UART
  → UARTTask acumula como linha normal
  → cmd_queue (espera Parser estar livre)
  → GCodeParserTask processa
  → sinaliza status_semaphore
  → MonitorTask acorda (depende do scheduler)
  → lê state_mutex
  → formata string
  → UART TX

Latência total estimada: 2–5ms (dependente de quantas linhas estão na cmd_queue)
```

Este comportamento é incorreto para um sistema CNC. O GRBL define '?', '!' e '~' como
**comandos de tempo real** que ignoram a fila de comandos e são processados imediatamente.
A razão é simples: se a máquina estiver em ALARM, a fila pode estar bloqueada e o host
precisa saber o estado sem depender dela.

### Solução: detecção na UARTTask

```
UARTTask acumula caracteres byte a byte.
Para CADA byte recebido, antes de acumular no buffer de linha:

  if (byte == '?') {
      // Responder imediatamente — não vai para cmd_queue
      system_state_t snap;
      xSemaphoreTake(state_mutex, pdMS_TO_TICKS(5));
      snap = g_state;
      xSemaphoreGive(state_mutex);
      grbl_send_status(&snap);   // UART TX via uart_tx_mutex
      continue;  // não acumula '?' no buffer de linha
  }
  
  buffer[idx++] = byte;
  if (byte == '\n') { xQueueSend(cmd_queue, buffer, 0); }
```

### Ganhos

| Aspecto | v1 | v2 |
|---------|----|----|
| Latência '?' | 2–5ms | ~200µs |
| Tarefas envolvidas | 4 (UART, Parser, Monitor, Semáforo) | 1 (UART) |
| status_semaphore | Necessário | **Eliminado** |
| EVENT_STATUS_REQ no event_group | Necessário | **Eliminado** |
| MonitorTask | Responde ao '?' | Apenas watchdog / overflow |

### Impacto na MonitorTask

Com '?' fora do fluxo, a MonitorTask perde sua função principal.
Ela é mantida com responsabilidade redefinida:

**MonitorTask v2:**
- Verifica periodicamente overflow das filas (`uxQueueSpacesAvailable`)
- Detecta starvation: se MotionExecutor está bloqueado há mais de N segundos sem estado IDLE
- Sinaliza EVENT_ALARM se detectar inconsistência
- Permanece com prioridade 1 (mínima) — totalmente background

---

## Ponto 3: Problema Crítico Não Identificado — UART TX sem Sincronização

### Diagnóstico

Na arquitetura v1, as seguintes tarefas escrevem diretamente na UART:
- GCodeParserTask: envia `ok\n` ou `error\n`
- MonitorTask: envia `<State|MPos:x,y>`

Na v2 revisada, adicionamos:
- UARTTask: envia resposta ao `?`
- GCodeParserTask: envia resposta ao M114

A função `uart_write_bytes()` do ESP-IDF **não é thread-safe** — múltiplas chamadas
concorrentes podem intercalar bytes na saída, corrompendo o protocolo.

Exemplo de corrupção:
```
GCodeParser envia: "ok\n"
UARTTask envia:    "<Idle|MPos:0.000,0.000>\n"

Saída real possível: "ok<Idle|MPos:0.000,0.000>\n\n"
```

O host receberia uma linha corrompida e entraria em estado de erro.

### Solução: uart_tx_mutex

Criar um mutex dedicado para UART TX:

```c
SemaphoreHandle_t uart_tx_mutex;  // criado em app_main()
```

Toda escrita na UART passa por:
```c
xSemaphoreTake(uart_tx_mutex, portMAX_DELAY);
uart_write_bytes(UART_NUM, data, len);
xSemaphoreGive(uart_tx_mutex);
```

Encapsular isso em `grbl_protocol.c` para que os callers não precisem gerenciar o mutex.

---

## Ponto 4: Buffer de Planejamento — Substituição do block_queue

### Diagnóstico da v1

O `block_queue` tem capacidade 3. O problema:

```
Trajetória com 100 movimentos curtos de 1mm cada:
  - Tempo de execução de cada bloco: ~60ms (a 1000mm/min)
  - Tempo de planejamento de cada bloco: ~500µs
  
  Com 3 slots:
  - Executor executa bloco 1 (60ms)
  - Enquanto isso, Planner planeja blocos 2, 3, 4 → preenche os 3 slots
  - Executor conclui bloco 1 → consome bloco 2 → Planner planeja bloco 5
  
  → Sem starvation neste exemplo.
  
  Mas: se o host enviar linhas em burst (arquivo G-Code), e o Parser for mais rápido
  que o Executor, cmd_queue enche, UARTTask descarta comandos. Com 3 blocos no Planner,
  a "janela de look-ahead" é mínima e qualquer stall no Parser causa pausa visível.
```

O problema real aparece em movimentos MUITO curtos (< 0.1mm) em alta velocidade:
- Tempo de execução: ~5ms
- 3 blocos = 15ms de buffer
- Qualquer stall de Parser > 15ms causa pausa

### Solução: planner_queue com 16 slots

Renomear `block_queue` para `planner_queue` e expandir para 16 slots.

Não é necessário implementar um circular buffer customizado — a FreeRTOS queue com
16 itens fornece exatamente o mesmo comportamento com menos código:

```
Capacidade: 16 × sizeof(motion_block_t) = 16 × 80 bytes = 1280 bytes
Overhead FreeRTOS queue struct: ~80 bytes
Total RAM: ~1360 bytes
```

**Por que 16 e não 8?**

O GRBL usa 16 (configurável até 32). Para movimentos de 1mm a 1000mm/min:
- Tempo por bloco: 60ms
- 16 blocos = ~960ms de buffer antecipado
- Praticamente nenhum stall visível em condições normais

Para 8 blocos = 480ms → ainda bom, mas 16 é o padrão do setor por uma razão.

**Impacto no fluxo de back-pressure:**

```
cmd_queue (10) → Parser → motion_queue (8) → Planner → planner_queue (16) → Executor
                                                                              ↑
                                              back-pressure correto:
                                              Planner bloqueia em portMAX_DELAY quando
                                              planner_queue está cheia
```

### Correção do protocolo ok/error

Na v1, o GCodeParser usa `xQueueSend(motion_queue, ..., 100ms)`. Se a fila encher,
a send falha após 100ms, mas o Parser ainda envia `ok\n` (comportamento incorreto).

**Regra correta GRBL:** `ok` é enviado quando o comando é aceito na fila.
Se a fila está cheia, a tarefa deve **bloquear** até ter espaço, e só então enviar `ok`.

```c
// v2: portMAX_DELAY garante que ok só é enviado após aceitação
xQueueSend(motion_queue, &cmd, portMAX_DELAY);
grbl_send_ok();   // só chega aqui quando o item foi aceito
```

Isso torna o back-pressure explícito e correto: o host só recebe `ok` quando o
firmware realmente tem capacidade de processar mais um comando.

---

## Ponto 5: Revisão dos Limites de Desempenho

### Diagnóstico da v1

A afirmação "velocidade máxima prática (A4988 @ 1/16): ~3000 steps/s" é imprecisa e
subestimada em pelo menos uma ordem de grandeza.

### Análise em Três Camadas

#### Camada 1: Limite do Hardware (GPTimer + ESP32)

O GPTimer do ESP32 tem resolução de 1µs. A ISR leva ~1–2µs por ciclo (IRAM_ATTR).
O período mínimo seguro é **5µs** (para não sobrepor ISRs consecutivas):

```
Limite teórico GPTimer: 1.000.000 steps/s  (período = 1µs, não é seguro)
Limite prático ISR:       200.000 steps/s  (período = 5µs, margem 2.5×)
```

#### Camada 2: Limite do Driver

| Driver | Freq. máxima (datasheet) | Observação |
|--------|--------------------------|-----------|
| A4988  | 500 kHz               | Teórico, sem carga |
| DRV8825| 250 kHz               | Teórico, sem carga |

Ambos superam largamente o limite de ISR. O driver não é o gargalo.

#### Camada 3: Limite do Motor + Mecânica

O motor de passo perde torque (e portanto sincronismo) em função da velocidade de rotação.
Um NEMA17 típico começa a perder torque acima de 400–600 RPM sem driver de alta tensão.

Para configurações comuns:

| Configuração | Steps/rev | Lead/passo | Steps/mm | Velocidade razoável | Freq. de step |
|---|---|---|---|---|---|
| Full step, parafuso M8 (1.25mm) | 200 | 1.25 mm | 160 | 1500 mm/min = 25 mm/s | 4.000 steps/s |
| 1/8 step, GT2 belt 20T (40mm) | 1600 | 0.025 mm | — | — | — |
| 1/16 step, fuso 8mm (8mm/rev) | 3200 | 0.0025 mm | 400 | 600 mm/min = 10 mm/s | 4.000 steps/s |
| 1/8 step, fuso 8mm | 1600 | 0.005 mm | 200 | 1200 mm/min = 20 mm/s | 4.000 steps/s |
| Full step, fuso 2mm | 200 | 0.01 mm | 100 | 3000 mm/min = 50 mm/s | 5.000 steps/s |

O steps/mm de 80 usado como exemplo (04_fluxograma) implica um mecanismo de
~2.5mm de deslocamento por revolução com full step, ou ~5mm com 1/2 step.
Para esse valor:

| Nível | Freq. de step | Velocidade (80 steps/mm) |
|-------|--------------|--------------------------|
| Conservador (testes iniciais) | 1.000 – 5.000 steps/s | 12,5 – 62,5 mm/s |
| Realista (sistema bem ajustado) | 5.000 – 40.000 steps/s | 62,5 – 500 mm/s |
| Teórico (GPTimer, sem motor) | 200.000 steps/s | 2.500 mm/s |

**Recomendação prática para testes iniciais:**
- `HOMING_SPEED_STEPS_S = 500`  (lento, para validar endstops)
- `DEFAULT_FEEDRATE_MM_MIN = 600` (10 mm/s) → 800 steps/s com 80 steps/mm
- `MAX_FEEDRATE_MM_MIN = 3000` (50 mm/s) → 4000 steps/s com 80 steps/mm

Estes valores são conservadores e funcionarão com qualquer NEMA17 padrão.
O config.h deve expor todos esses parâmetros para ajuste sem recompilar.

---

## Ponto 6: Suporte ao Comando M114

### Análise

M114 é um comando de consulta de posição corrente. Formato de resposta:
```
X:120.000 Y:80.000
```

**Onde tratar:** No GCodeParserTask, em ordem com os demais comandos.

**Por que não na UARTTask como '?'?**

A diferença fundamental: '?' é um comando de tempo real — deve responder ao estado
*atual* da máquina, mesmo se houver movimentos na fila. Ele intencionalmente "fura"
a fila para dar feedback imediato.

M114 é um comando G-Code normal — deve responder com a posição *após todos os
comandos anteriores terem sido executados*. Se você envia:

```
G1 X100 Y50
M114
```

O M114 deve responder X:100 Y:50, não a posição intermediária durante a execução do G1.

**Portanto, M114 vai pela fila normal:**

```
GCodeParser recebe M114
  → Não cria motion_cmd_t
  → lê g_state.mpos via state_mutex (brevemente)
  → formata e envia "X:%.3f Y:%.3f\n" via uart_tx_mutex
  → envia ok\n
```

**Mas há um problema de sequenciamento:** se M114 for pela cmd_queue e o Parser
responder imediatamente, a posição reportada será a posição no momento em que
o Planner processou os comandos anteriores — não quando foram *executados*.

A solução correta para sequenciamento exato seria: o Planner emite um bloco especial
"M114_QUERY" para a planner_queue, o Executor o processa (depois de todos os blocos
anteriores), e então responde. Mas isso complica a arquitetura.

**Decisão para este projeto:** reportar a posição do *planning state* (posição após
o que o Planner sabe que vai executar) é suficiente para fins práticos e educacionais.
O impacto é documentado como limitação conhecida.

**Impacto na arquitetura:** Nenhuma nova tarefa, fila ou semáforo.
Apenas uma nova branch no switch/case do GCodeParser.

---

## Ponto 7: Revisão do Uso de Dual-Core

### Diagnóstico da v1

A v1 usa `xTaskCreatePinnedToCore()` para todas as tarefas com distribuição explícita:
- Core 0: todas as tarefas
- Core 1: MotionExecutorTask (isolada)

### Análise

**Argumento favor dual-core:**
- Core 1 dedicado ao Executor significa que o GPTimer ISR nunca compete com Parser ou Planner
- No ESP-IDF, o GPTimer ISR corre no mesmo core que criou/habilitou o timer. Sem pinning,
  o Executor pode migrar entre cores entre chamadas e o timer segue — comportamento não determinístico

**Argumento contra (para v1):**
- Força o uso de `xTaskCreatePinnedToCore()` em toda parte — código ligeiramente mais verboso
- O benefício real só é perceptível em step rates > 50.000 steps/s, fora do escopo deste projeto
- Torna debugging ligeiramente mais complexo (precisa saber em qual core está)

### Decisão Revisada

**v2 (implementação inicial):** Manter pinning **apenas para MotionExecutorTask no Core 1**.
Todas as outras tarefas usam `tskNO_AFFINITY` (equivalente a `xTaskCreate`).

Isso é o equilíbrio correto:
- O Executor (+ ISR do GPTimer) fica no Core 1 — garantia de tempo real
- Demais tarefas: o SMP scheduler do FreeRTOS decide — menos configuração manual

```c
// app_main() v2:
xTaskCreate(uart_task,     "uart",    2048, NULL, 2, NULL);          // qualquer core
xTaskCreate(parser_task,   "parser",  4096, NULL, 3, NULL);          // qualquer core
xTaskCreate(planner_task,  "planner", 4096, NULL, 3, NULL);          // qualquer core
xTaskCreate(monitor_task,  "monitor", 2048, NULL, 1, NULL);          // qualquer core
xTaskCreatePinnedToCore(executor_task, "executor", 4096, NULL, 4, NULL, 1);  // Core 1 fixo
```

**Nota sobre o GPTimer:** O timer deve ser criado e habilitado dentro do MotionExecutorTask
(que corre no Core 1), não no app_main. Isso garante que a ISR corra no Core 1.

---

## Ponto 8: Auditoria Final — Condições de Corrida, Deadlocks e Gargalos

### 8.1 Condições de Corrida Identificadas

#### CR-01: g_isr_ctx sem proteção explícita [RISCO MÉDIO]

**Situação:** O MotionExecutorTask escreve em `g_isr_ctx` (contexto global da ISR)
antes de armar o GPTimer. A ISR lê `g_isr_ctx` a cada callback.

**Risco:** Se o Executor escrever em `g_isr_ctx` enquanto o timer ainda está
disparando de um bloco anterior, a ISR lerá dados inconsistentes.

**Mitigação:** O Executor **para o GPTimer antes de escrever** em g_isr_ctx:
```
gptimer_stop() → portENTER_CRITICAL() → escreve g_isr_ctx → portEXIT_CRITICAL() → gptimer_start()
```
Isso garante exclusão mútua sem overhead de semáforo.

#### CR-02: state_mutex com escritores múltiplos [RISCO BAIXO — RESOLVIDO]

**Escritores de g_state:**
- MotionExecutorTask: atualiza mpos_x, mpos_y, status
- GCodeParserTask: atualiza position_absolute (G90/G91), feedrate

**Leitores:**
- UARTTask: lê mpos e status para resposta ao '?'
- GCodeParserTask: lê mpos para resolver G91 → coordenadas absolutas
- MonitorTask: lê tudo periodicamente

**Mitigação:** Todos acessos via `xSemaphoreTake(state_mutex, 5ms)`. FreeRTOS mutex
implementa priority inheritance — o Executor (Prio 4) promove temporariamente o Parser
(Prio 3) se o Parser estiver segurando o mutex quando o Executor precisar. ✓

#### CR-03: UART TX sem sincronização [RISCO CRÍTICO — IDENTIFICADO NO PONTO 3]

Conforme descrito no Ponto 3. Resolvido via `uart_tx_mutex`.

#### CR-04: planner_queue — escrita pelo Planner, leitura pelo Executor [SEM RISCO]

Mecanismo nativo do FreeRTOS Queue — thread-safe por design. ✓

### 8.2 Análise de Deadlock

Um deadlock exige que dois agentes possuam recursos que o outro precisa.

**Verificação de lock ordering (ordem de aquisição de locks):**

| Tarefa | Locks que pode segurar simultaneamente |
|--------|----------------------------------------|
| UARTTask | uart_tx_mutex |
| GCodeParserTask | state_mutex (brevemente) → uart_tx_mutex (para ok/error) |
| MotionPlannerTask | Nenhum (apenas operações de fila) |
| MotionExecutorTask | state_mutex (brevemente) |
| MonitorTask | state_mutex (brevemente) |

**Problema potencial:** GCodeParserTask pode:
1. Adquirir `state_mutex` para ler mpos (G91 → absoluto)
2. Depois adquirir `uart_tx_mutex` para enviar ok

MotionExecutorTask pode:
1. Adquirir `state_mutex` para atualizar posição (após bloco)
2. Nunca adquire uart_tx_mutex

**Não há lock reverso**: nenhuma tarefa adquire uart_tx_mutex e depois tenta adquirir state_mutex.
**Conclusão: sem deadlock possível.** ✓

### 8.3 Gargalos de Desempenho

| Gargalo | Localização | Severidade | Mitigação |
|---------|------------|-----------|-----------|
| Cópia de 96 bytes por item na cmd_queue | xQueueSend/Receive | Baixa | Aceitável para 10 itens; alternativa seria queue de ponteiros |
| Cálculo trapezoidal com float | MotionPlannerTask | Baixa | ESP32 tem FPU, ~10µs por bloco. 16-slot buffer absorve |
| gpio_matrix latência para STEP pulse | ISR | Baixa | ~125ns extra vs. RTC_IO. Aceitável para >5µs period |
| UART TX com mutex | uart_tx_mutex | Muito Baixa | ok\n = 3 bytes = 260µs @ 115200. Mutex contention desprezível |

### 8.4 Complexidade Desnecessária — Identificada e Removida

| Item removido | Economia |
|---------------|---------|
| ExtruderTask | 1 tarefa, 1 fila, ~1.2KB RAM |
| status_semaphore | 1 primitiva FreeRTOS |
| EVENT_STATUS_REQ no event_group | 1 bit do event group |
| timeout 100ms no motion_queue send | Comportamento incorreto substituído por portMAX_DELAY |
| MonitorTask respondendo '?' | Responsabilidade focada em watchdog |

---

## Resumo das Mudanças v1 → v2

### Tarefas

| Tarefa | v1 | v2 |
|--------|----|----|
| UARTTask | Acumula linhas | Acumula linhas + responde '?' diretamente |
| GCodeParserTask | Trata '?', M3/M5, G-codes | Trata M3/M5 (embedded), M114, G-codes |
| MotionPlannerTask | Sem mudança | Usa portMAX_DELAY; considera extruder_action |
| MotionExecutorTask | Core 1 | Core 1 (mantido) + aplica extruder_action |
| **ExtruderTask** | **Existe (Prio 2)** | **Removida** |
| MonitorTask | Responde '?', watchdog | Apenas watchdog / overflow |

### Primitivas FreeRTOS

| Primitiva | v1 | v2 |
|-----------|----|----|
| cmd_queue | 10 × 128 bytes | 10 × 96 bytes |
| motion_queue | 5 items | 8 items |
| **extruder_queue** | **5 items** | **Removida** |
| block_queue | 3 items | Substituída por planner_queue |
| **planner_queue** | Não existe | **16 items × 80 bytes** |
| state_mutex | Existe | Existe |
| **uart_tx_mutex** | **Não existe** | **Adicionado (crítico)** |
| **status_semaphore** | Existe | **Removido** |
| motion_event_group | 4 bits | 3 bits (STATUS_REQ removido) |

### Consumo de RAM estimado (filas)

| Componente | v1 | v2 | Δ |
|-----------|-----|-----|---|
| cmd_queue | 1.280 bytes | 960 bytes | -320 |
| motion_queue | 160 bytes | 256 bytes | +96 |
| extruder_queue | ~100 bytes | 0 | -100 |
| block/planner_queue | ~272 bytes | ~1.360 bytes | +1.088 |
| Stacks (ExtruderTask removida) | — | -1.024 bytes | -1.024 |
| **Total** | **~1.812** | **~2.576** | **+764** |

O aumento de ~764 bytes é justificado: a planner_queue com 16 slots elimina starvation
e é um investimento correto no desempenho de fluência de movimento.
O ESP32 tem 520KB de SRAM — este delta é irrelevante.

---

## Veredicto Final

A arquitetura v2 está **aprovada para implementação** com as seguintes garantias:

- ✓ Sem deadlocks possíveis (lock ordering verificado)
- ✓ Condições de corrida identificadas e mitigadas
- ✓ UART TX sincronizado (problema crítico corrigido)
- ✓ Sequenciamento extrusor correto (embedding no bloco)
- ✓ Protocolo ok/error correto (back-pressure via portMAX_DELAY)
- ✓ Fluidez de movimento com 16 blocos de lookahead
- ✓ Limites de velocidade documentados com base em hardware real
- ✓ M114 integrado sem complexidade adicional
- ✓ '?' com latência < 500µs (tempo real)

**Próximo passo: Etapa 2 — Implementação dos módulos base.**
