# Revisão da Arquitetura — Checklist pré-implementação

## Resultado: APROVADA ✓

Este documento registra a revisão da arquitetura antes de iniciar qualquer implementação.

---

## 1. Checklist de Requisitos do Projeto

| Requisito | Abordado | Onde |
|-----------|----------|------|
| ESP32 + ESP-IDF | ✓ | config.h, CMakeLists.txt raiz |
| Motores X e Y (A4988/DRV8825) | ✓ | hal/hal_stepper.h, config.h STEPPER_DRIVER |
| Camada HAL trocável por config | ✓ | #ifdef em hal_stepper.c |
| Extrusor ON/OFF (M3/M5) | ✓ | hal_extruder, ExtruderTask, extruder_queue |
| Fim de curso X e Y | ✓ | hal_endstop.h, MotionExecutor (homing) |
| USB Serial (UART) | ✓ | UARTTask + grbl_protocol |
| G0, G1 | ✓ | GCodeParser → motion_cmd_t CMD_MOVE_G0/G1 |
| G28 (homing) | ✓ | GCodeParser → CMD_HOMING → MotionExecutor |
| M3, M5 | ✓ | GCodeParser → extruder_queue |
| F (feedrate) | ✓ | motion_cmd_t.feedrate |
| G90/G91 | ✓ | system_state.position_absolute |
| Resposta GRBL '?' | ✓ | MonitorTask + status_semaphore |
| Estados Idle/Run/Alarm/Homing | ✓ | machine_state_t enum |
| ok / error | ✓ | grbl_protocol.c |
| FreeRTOS — 6 tarefas | ✓ | tasks/ (UART, Parser, Planner, Executor, Extruder, Monitor) |
| Queues | ✓ | cmd_q, motion_q, extruder_q, block_q |
| Semáforos | ✓ | status_semaphore (binário) |
| Event Groups | ✓ | motion_event_group (4 bits) |
| Mutex | ✓ | state_mutex |
| Sem vTaskDelay para passos | ✓ | GPTimer ISR justificada |
| GPTimer ou RMT | ✓ | GPTimer escolhido + justificativa |
| Interpolação linear XY | ✓ | Bresenham documentado com exemplo numérico |
| Bresenham ou equivalente | ✓ | Implementação completa em 05_matematica |
| Aceleração trapezoidal | ✓ | Equações + aproximação de Olds |
| Estrutura de diretórios | ✓ | 06_estrutura_diretorios.md |
| Comentários Doxygen | ✓ | (planejados para Etapa 7) |
| Dual-core ESP32 | ✓ | Executor no Core 1, demais no Core 0 |

---

## 2. Decisões Arquiteturais Críticas — Revisão

### 2.1 GPTimer (não RMT) — CORRETO
**Motivo validado**: O período de step muda a cada ciclo durante aceleração/desaceleração.
O RMT exigiria reconstruir o buffer inteiro a cada mudança, adicionando latência imprevisível.
O GPTimer re-arma o alarme na própria ISR com o novo período — O(1) por ciclo.

**Risco identificado**: A ISR do GPTimer roda no Core onde o timer foi criado.
O GPTimer deve ser criado pela MotionExecutorTask (Core 1) para garantir afinidade.
**Mitigação**: Documentado no task_motion_executor.c.

### 2.2 Bresenham inteiro — CORRETO
**Motivo validado**: Sem `float` na ISR. O ESP32 tem FPU, mas operações float na ISR
aumentam o tempo de serviço e risco de preemção. Aritmética inteira é determinística.

**Limitação conhecida**: O Bresenham puro não faz arcos (G2/G3). Este projeto não requer.

### 2.3 Planner separado do Executor — CORRETO
**Motivo validado**: Bresenham + trapezoidal envolve divisões e sqrt.
Rodar isso no Planner (Core 0, prioridade 3) não afeta o tempo real do Executor (Core 1, prio 4).

**Risco identificado**: block_queue tem capacidade 3.
Se o Planner for mais lento que o Executor (movimento muito curto com baixa aceleração),
o Executor ficará aguardando. Isso é correto — é back-pressure.

### 2.4 Notificação ISR → Task (xTaskNotifyFromISR) — CORRETO
**Motivo validado**: Mais leve que semáforo. A notificação carrega um valor de 32 bits,
permitindo passar o motivo (BLOCK_DONE vs ALARM) em um único mecanismo.

### 2.5 Mutex para system_state — CORRETO
**Risco identificado**: MonitorTask lê state com `state_mutex` — OK.
MotionExecutor escreve posição após bloco concluir — OK.
**Cuidado**: NUNCA tentar adquirir state_mutex dentro da ISR.
A ISR usa um ponteiro para o bloco atual (`g_isr_ctx`) que é atualizado com seção crítica
(`portENTER_CRITICAL_ISR`) antes de iniciar o GPTimer — padrão seguro.

---

## 3. Análise de Pior Caso (WCET)

### ISR do GPTimer
Operações por ciclo:
1. Bresenham: 3 comparações + 2 adições = ~10 ciclos de CPU
2. Atualização trapezoidal: 1 comparação + 1 adição = ~5 ciclos
3. GPIO set/clear: 2 `gpio_set_level` = ~20 ciclos (via GPIO matrix)
4. GPTimer re-arm: 1 chamada = ~30 ciclos
5. Verificação de fim de bloco: 1 comparação = ~3 ciclos
6. Total estimado: ~70 ciclos @ 240MHz = ~300ns

Período mínimo do timer: 333µs (3000 steps/s) >> 300ns → margem de 1000x. ✓

### Latência de resposta ao comando '?'
1. UARTTask recebe '?' → cmd_queue: ~1ms (UART + fila)
2. GCodeParser processa: ~100µs
3. MonitorTask acorda: ~1ms (contexto switch)
4. UART TX: ~200µs (20 bytes @ 115200 bps)
Total: ~2-3ms — aceitável para polling de status.

---

## 4. Pontos de Atenção para a Implementação

1. **IRAM_ATTR obrigatório** em `gptimer_isr_callback` e em todas as funções
   chamadas por ela (hal_stepper_step, etc.)

2. **Seção crítica vs portENTER_CRITICAL_ISR**: dentro da ISR usar `portENTER_CRITICAL_ISR`;
   nas tasks usar `portENTER_CRITICAL` (taskENTER_CRITICAL).

3. **GPIO pulse width**: A4988 exige mínimo 1µs de HIGH no STEP.
   DRV8825 exige 1.9µs. Usar `esp_rom_delay_us(2)` entre set e clear (IRAM-safe).

4. **Homing sem interrupção de GPIO**: Para simplificar, usar polling de endstop
   dentro da MotionExecutorTask durante a fase de homing (movimento lento).
   Velocidade de homing: 10% do feedrate máximo.

5. **Re-entrância do parser**: GCodeParserTask processa uma linha por vez;
   não há re-entrância. Estado de posição absoluta/relativa é protegido pelo mutex.

6. **Inicialização de ordem**: app_main() deve criar filas e semáforos ANTES
   das tarefas. Tasks não devem iniciar antes de todos os objetos existirem.

---

## 5. O que NÃO é implementado (escopo reduzido intencional)

| Funcionalidade | Motivo da omissão |
|----------------|-------------------|
| G2/G3 (arcos) | Requer interpolação circular — fora do escopo |
| G4 (dwell/pausa) | Não solicitado |
| G17/18/19 (plano de trabalho) | Sistema 2D apenas |
| Buffer lookahead (como GRBL) | Simplificado — block_queue com 3 blocos |
| Jerk/junction velocity | Perfil trapezoidal simples (v_entry=0) |
| Soft limits | Não solicitado |
| WiFi / BLE | Não solicitado |
| SD Card | Não solicitado |

---

## Conclusão

A arquitetura cobre todos os requisitos do projeto.
As decisões de design são justificadas e os riscos identificados têm mitigações documentadas.

**Próximo passo: Etapa 2 — Implementação dos módulos base (HAL, Tasks, Filas).**

# Arquitetura Geral — Firmware XY G-Code (ESP32 + FreeRTOS)

## 1. Visão Sistêmica

O firmware implementa um pipeline de processamento de G-Code em camadas, onde cada camada se comunica
com a próxima exclusivamente por primitivas FreeRTOS (queues, semáforos, event groups).
Nenhuma tarefa acessa diretamente o hardware; toda interação com periféricos passa pela HAL.

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                          FIRMWARE XY G-CODE ESP32                           │
│                                                                             │
│   ┌─────────────────────────────────────────────────────────────────────┐   │
│   │                        CAMADA DE APLICAÇÃO                          │   │
│   │                                                                     │   │
│   │  ┌──────────┐  ┌──────────────┐  ┌──────────────┐  ┌───────────┐  │   │
│   │  │ UARTTask │  │GCodeParser   │  │MotionPlanner │  │ Monitor   │  │   │
│   │  │          │  │Task          │  │Task          │  │Task       │  │   │
│   │  └────┬─────┘  └──────┬───────┘  └──────┬───────┘  └───────────┘  │   │
│   │       │               │                  │                          │   │
│   │  ┌────▼───────────────▼──────────────────▼──────────────────────┐  │   │
│   │  │              CAMADA DE COMUNICAÇÃO (FreeRTOS IPC)             │  │   │
│   │  │   cmd_queue    motion_queue    status_semaphore   event_group  │  │   │
│   │  └────────────────────────┬──────────────────────────────────────┘  │   │
│   │                           │                                          │   │
│   │  ┌────────────────────────▼──────────────────────────────────────┐  │   │
│   │  │                     CAMADA DE EXECUÇÃO                        │  │   │
│   │  │                                                               │  │   │
│   │  │  ┌──────────────────┐          ┌──────────────────────────┐  │  │   │
│   │  │  │ MotionExecutor   │          │      ExtruderTask        │  │  │   │
│   │  │  │ Task             │          │                          │  │  │   │
│   │  │  └────────┬─────────┘          └───────────┬──────────────┘  │  │   │
│   │  └───────────┼────────────────────────────────┼─────────────────┘  │   │
│   └─────────────────────────────────────────────────────────────────────┘  │
│               │                                    │                        │
│   ┌───────────▼────────────────────────────────────▼───────────────────┐   │
│   │                        CAMADA HAL                                   │   │
│   │                                                                     │   │
│   │  ┌───────────────────┐   ┌──────────────────┐  ┌───────────────┐  │   │
│   │  │  hal_stepper.h    │   │  hal_endstop.h   │  │hal_extruder.h │  │   │
│   │  │  (A4988 / DRV8825)│   │  (GPIO input)    │  │(GPIO output)  │  │   │
│   │  └───────────────────┘   └──────────────────┘  └───────────────┘  │   │
│   └─────────────────────────────────────────────────────────────────────┘   │
│               │                                                              │
│   ┌───────────▼─────────────────────────────────────────────────────────┐   │
│   │                      HARDWARE ESP32                                  │   │
│   │  GPTimer(ISR)  GPIO(STEP/DIR/EN)  GPIO(Endstop)  UART0(USB-Serial)  │   │
│   └─────────────────────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────────────────────┘
```

## 2. Princípios de Design

| Princípio | Decisão | Justificativa |
|-----------|---------|---------------|
| Isolamento de hardware | HAL obrigatória | Troca de driver (A4988↔DRV8825) sem alterar lógica |
| Comunicação assíncrona | Apenas FreeRTOS IPC | Elimina dependências temporais entre tarefas |
| Sem polling em ISR | GPTimer para passos | `vTaskDelay` bloquearia o scheduler |
| Planejamento separado da execução | Planner ≠ Executor | Matemática pesada não interfere no tempo real |
| Estado centralizado | `system_state_t` global protegido por mutex | Monitoramento e resposta GRBL consistentes |

## 3. Fluxo de Dados Principal

```
Serial IN  →  [cmd_queue]  →  GCodeParser  →  [motion_queue]  →  MotionPlanner
                                           →  [extruder_queue] →  ExtruderTask
                                                                        ↓
                          MotionPlanner  →  [block_queue]  →  MotionExecutor
                                                                        ↓
                                                              GPTimer ISR
                                                                        ↓
                                                           HAL_Stepper (STEP/DIR)
```

## 4. Núcleo de Execução: GPTimer ISR

O ponto mais crítico do sistema é a ISR do GPTimer. Ela:
1. Lê o bloco de movimento atual do MotionExecutor
2. Aplica o algoritmo de Bresenham para decidir qual eixo avança
3. Atualiza o acumulador de aceleração trapezoidal
4. Reprograma o próximo alarme do GPTimer com o novo `step_period`
5. Gera os pulsos STEP via GPIO

Toda essa lógica deve ser executada em IRAM (`IRAM_ATTR`) para zero latência de cache.

# Diagrama de Tarefas FreeRTOS

## 1. Mapa de Tarefas

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                        TAREFAS FREERTOS                                     │
│                                                                             │
│  Prioridade 1 (mais baixa)                                                  │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │  MonitorTask                                                        │   │
│  │  Core: 0  |  Stack: 2048  |  Período: 500ms                        │   │
│  │  • Lê system_state (mutex)                                          │   │
│  │  • Reporta via Serial se solicitado (comando '?')                   │   │
│  │  • Checa overflow de filas                                          │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                             │
│  Prioridade 2                                                               │
│  ┌──────────────────────────┐   ┌──────────────────────────────────────┐   │
│  │  UARTTask                │   │  ExtruderTask                        │   │
│  │  Core: 0  |  Stack: 2048 │   │  Core: 0  |  Stack: 1024            │   │
│  │  • Lê UART byte a byte   │   │  • Aguarda extruder_queue            │   │
│  │  • Acumula linha         │   │  • Liga/desliga GPIO extrusor        │   │
│  │  • Envia cmd_queue       │   │  • Atualiza extruder_state           │   │
│  └──────────────────────────┘   └──────────────────────────────────────┘   │
│                                                                             │
│  Prioridade 3                                                               │
│  ┌──────────────────────────┐   ┌──────────────────────────────────────┐   │
│  │  GCodeParserTask         │   │  MotionPlannerTask                   │   │
│  │  Core: 0  |  Stack: 4096 │   │  Core: 0  |  Stack: 4096            │   │
│  │  • Consome cmd_queue     │   │  • Consome motion_queue              │   │
│  │  • Parseia G-Code        │   │  • Calcula bloco trapezoidal         │   │
│  │  • Emite motion_queue    │   │  • Calcula Bresenham parameters      │   │
│  │  • Emite extruder_queue  │   │  • Emite block_queue                 │   │
│  │  • Responde ok/error     │   │                                      │   │
│  └──────────────────────────┘   └──────────────────────────────────────┘   │
│                                                                             │
│  Prioridade 4 (mais alta — tempo real)                                      │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │  MotionExecutorTask                                                 │   │
│  │  Core: 1  |  Stack: 4096  |  Prioridade máxima userspace           │   │
│  │  • Consome block_queue                                              │   │
│  │  • Inicializa GPTimer com primeiro step_period                      │   │
│  │  • Aguarda EVENT_BLOCK_DONE do event_group                          │   │
│  │  • Atualiza system_state (posição, estado)                          │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                             │
│  ISR (fora do scheduler — IRAM)                                             │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │  gptimer_isr_callback (IRAM_ATTR)                                   │   │
│  │  • Bresenham step de um ciclo                                       │   │
│  │  • Atualiza acumulador de aceleração                                │   │
│  │  • Reprograma alarme GPTimer                                        │   │
│  │  • GPIO: pulso STEP (set → clear)                                   │   │
│  │  • Ao fim do bloco: notifica MotionExecutor via xTaskNotifyFromISR  │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────────────────────┘
```

## 2. Afinidade de Núcleo (Dual-Core ESP32)

| Tarefa | Núcleo | Razão |
|--------|--------|-------|
| UARTTask | Core 0 | I/O não crítico, compartilha com WiFi stack (se usado) |
| GCodeParserTask | Core 0 | CPU-bound leve, sem requisito de tempo real |
| MotionPlannerTask | Core 0 | Matemática pesada que não interfere no executor |
| ExtruderTask | Core 0 | Controle simples, baixa frequência |
| MonitorTask | Core 0 | Background, baixa prioridade |
| MotionExecutorTask | Core 1 | **Isolado** — sem concorrência com tarefas de Core 0 |
| GPTimer ISR | Core 1 | Mesma afinidade que o Executor para coerência de cache |

## 3. Ciclo de Vida das Tarefas

```
app_main()
    │
    ├── Inicializa HAL (GPIO, UART, GPTimer)
    ├── Cria todas as filas e semáforos
    ├── Cria event_group
    ├── Inicializa system_state (IDLE)
    │
    ├── xTaskCreatePinnedToCore(UARTTask,         Core 0, Prio 2)
    ├── xTaskCreatePinnedToCore(GCodeParserTask,  Core 0, Prio 3)
    ├── xTaskCreatePinnedToCore(MotionPlannerTask,Core 0, Prio 3)
    ├── xTaskCreatePinnedToCore(MotionExecutorTask,Core 1, Prio 4)
    ├── xTaskCreatePinnedToCore(ExtruderTask,     Core 0, Prio 2)
    ├── xTaskCreatePinnedToCore(MonitorTask,      Core 0, Prio 1)
    │
    └── vTaskDelete(NULL)  ← app_main encerra, scheduler toma controle
```

## 4. Descrição Detalhada de Cada Tarefa

### UARTTask
- **Produz**: strings de comando em `cmd_queue`
- **Consome**: bytes do buffer UART (via `uart_read_bytes`)
- **Comportamento**: acumula bytes até `\n`, envia string completa para `cmd_queue`
- **Bloqueia em**: `uart_read_bytes` com timeout `portMAX_DELAY`

### GCodeParserTask
- **Produz**: `motion_cmd_t` em `motion_queue`, `extruder_cmd_t` em `extruder_queue`
- **Consome**: strings de `cmd_queue`
- **Comportamento**: tokeniza linha, identifica letra+número (G0/G1/G28/M3/M5/F/?), preenche struct
- **Bloqueia em**: `xQueueReceive(cmd_queue, ..., portMAX_DELAY)`
- **Responde**: `ok\n` ou `error\n` via UART diretamente

### MotionPlannerTask
- **Produz**: `motion_block_t` em `block_queue`
- **Consome**: `motion_cmd_t` de `motion_queue`
- **Comportamento**: converte coordenadas → passos, calcula perfil trapezoidal, parâmetros Bresenham
- **Bloqueia em**: `xQueueReceive(motion_queue, ..., portMAX_DELAY)`

### MotionExecutorTask
- **Produz**: notificações de evento `EVENT_BLOCK_DONE`
- **Consome**: `motion_block_t` de `block_queue`
- **Comportamento**: inicializa ISR com parâmetros do bloco, aguarda conclusão, atualiza posição
- **Bloqueia em**: `xTaskNotifyWait` aguardando ISR completar o bloco

### ExtruderTask
- **Produz**: nada (efeito colateral no GPIO)
- **Consome**: `extruder_cmd_t` de `extruder_queue`
- **Comportamento**: liga ou desliga GPIO do extrusor, atualiza estado

### MonitorTask
- **Produz**: respostas GRBL `<State|MPos:x,y>` via UART
- **Consome**: `status_request_flag` (semáforo binário), lê `system_state` via mutex
- **Comportamento**: ativado pelo comando `?` parseado pelo GCodeParser

# Diagrama de Filas e Primitivas FreeRTOS

## 1. Mapa Completo de IPC

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                    PRIMITIVAS FREERTOS — FLUXO COMPLETO                     │
│                                                                             │
│                                                                             │
│  ╔══════════╗    cmd_queue (10 items)     ╔═══════════════╗                │
│  ║ UARTTask ╠────────────────────────────►║GCodeParser    ║                │
│  ╚══════════╝    char[128]                ╚═══════╤═══════╝                │
│                                                   │                        │
│                         ┌─────────────────────────┤                        │
│                         │                         │                        │
│               motion_queue (5 items)    extruder_queue (5 items)           │
│               motion_cmd_t              extruder_cmd_t                     │
│                         │                         │                        │
│                         ▼                         ▼                        │
│  ╔═══════════════╗              ╔═══════════════════════╗                  │
│  ║MotionPlanner  ║              ║   ExtruderTask        ║                  │
│  ╚═══════╤═══════╝              ╚═══════════════════════╝                  │
│          │                              ▲                                  │
│    block_queue (3 items)                │ extruder_queue                   │
│    motion_block_t                       │                                  │
│          │                        ┌────┘                                   │
│          ▼                        │                                        │
│  ╔═══════════════╗    xTaskNotify ║     ╔═══════════════╗                  │
│  ║MotionExecutor ╠───────────────►║     ║  MonitorTask  ║                  │
│  ╚═══════╤═══════╝  (block done)  ║     ╚═══════════════╝                  │
│          │                        ║           ▲                            │
│    [GPTimer ISR]                  ║           │ status_semaphore           │
│          │                        ║           │ (binário)                  │
│          │ xTaskNotifyFromISR     ║           │                            │
│          └────────────────────────┘    ╔══════╧════════╗                  │
│                                        ║ GCodeParser   ║                  │
│                                        ║ (sinaliza '?')║                  │
│                                        ╚═══════════════╝                  │
│                                                                             │
│  ─────────────────────────────────────────────────────────────────────     │
│  MUTEX                                                                      │
│                                                                             │
│  state_mutex ──► protege system_state_t (lida por Monitor, escrita         │
│                  por MotionExecutor e GCodeParser)                          │
│                                                                             │
│  ─────────────────────────────────────────────────────────────────────     │
│  EVENT GROUP: motion_event_group                                            │
│                                                                             │
│  Bit 0: EVENT_HOMING_DONE   ← sinalizado por MotionExecutor após G28       │
│  Bit 1: EVENT_BLOCK_DONE    ← sinalizado pela ISR ao fim de bloco          │
│  Bit 2: EVENT_ALARM         ← sinalizado por qualquer tarefa em erro       │
│  Bit 3: EVENT_STATUS_REQ    ← sinalizado por GCodeParser ao receber '?'    │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

## 2. Especificação das Filas

### cmd_queue
| Atributo | Valor |
|----------|-------|
| Tipo de item | `char[128]` (string terminada em `\0`) |
| Capacidade | 10 itens |
| Produtor | UARTTask |
| Consumidor | GCodeParserTask |
| Comportamento produtor | `xQueueSend` com timeout 0 (descarta se cheia — não bloqueia UART) |
| Comportamento consumidor | `xQueueReceive` com `portMAX_DELAY` |

### motion_queue
| Atributo | Valor |
|----------|-------|
| Tipo de item | `motion_cmd_t` (struct ~32 bytes) |
| Capacidade | 5 itens |
| Produtor | GCodeParserTask |
| Consumidor | MotionPlannerTask |
| Comportamento produtor | `xQueueSend` com timeout 100ms |
| Comportamento consumidor | `xQueueReceive` com `portMAX_DELAY` |

### extruder_queue
| Atributo | Valor |
|----------|-------|
| Tipo de item | `extruder_cmd_t` (enum: ON/OFF) |
| Capacidade | 5 itens |
| Produtor | GCodeParserTask |
| Consumidor | ExtruderTask |
| Comportamento produtor | `xQueueSend` com timeout 0 |
| Comportamento consumidor | `xQueueReceive` com `portMAX_DELAY` |

### block_queue
| Atributo | Valor |
|----------|-------|
| Tipo de item | `motion_block_t` (struct ~64 bytes) |
| Capacidade | 3 itens |
| Produtor | MotionPlannerTask |
| Consumidor | MotionExecutorTask |
| Comportamento produtor | `xQueueSend` com `portMAX_DELAY` (bloqueia — back-pressure natural) |
| Comportamento consumidor | `xQueueReceive` com `portMAX_DELAY` |

## 3. Especificação dos Semáforos e Mutex

### state_mutex
- Tipo: `SemaphoreHandle_t` (mutex)
- Protege: `system_state_t g_state` (posição, status, feedrate)
- Escritores: MotionExecutorTask, GCodeParserTask (modo abs/rel)
- Leitores: MonitorTask
- Timeout máximo: 10ms (nunca bloquear indefinidamente)

### status_semaphore
- Tipo: semáforo binário
- Sinalizado por: GCodeParserTask ao receber comando `?`
- Aguardado por: MonitorTask (acorda, lê estado, responde, dorme novamente)

## 4. Especificação do Event Group

### motion_event_group
```c
#define EVENT_HOMING_DONE   BIT0   // G28 concluído
#define EVENT_BLOCK_DONE    BIT1   // ISR completou bloco de movimento
#define EVENT_ALARM         BIT2   // Erro de endstop ou overflow
#define EVENT_STATUS_REQ    BIT3   // Comando '?' recebido
```

Uso pelo MotionExecutorTask:
```c
// Aguarda bloco concluir OU alarme disparar
xEventGroupWaitBits(motion_event_group,
    EVENT_BLOCK_DONE | EVENT_ALARM,
    pdTRUE,   // limpa bits ao retornar
    pdFALSE,  // OR (qualquer um dos bits)
    portMAX_DELAY);
```

## 5. Fluxo de Back-Pressure

O `block_queue` com capacidade 3 e `xQueueSend(..., portMAX_DELAY)` no Planner
implementa back-pressure natural:

```
Se MotionExecutor está lento consumindo blocos:
    → block_queue enche
    → MotionPlannerTask bloqueia em xQueueSend
    → motion_queue começa a encher
    → GCodeParserTask desacelera (timeout de 100ms)
    → cmd_queue pode encher
    → UARTTask descarta com timeout 0 (comportamento intencional — host deve respeitar ok/error)
```

Este comportamento é consistente com o protocolo GRBL: o host não deve enviar
mais comandos do que o firmware confirma com `ok`.


# Fluxograma de Processamento G-Code

## 1. Pipeline Completo

```
                         ┌─────────────────────────┐
                         │   HOST (PC / Software)   │
                         │   Envia linha G-Code      │
                         │   ex: "G1 X50 Y30 F600\n"│
                         └────────────┬────────────┘
                                      │ USB Serial
                                      ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│ UARTTask                                                                    │
│                                                                             │
│  ┌─────────────┐    ┌──────────────────┐    ┌─────────────────────────┐   │
│  │ uart_read() │───►│ Acumula buffer   │───►│ '\n' encontrado?        │   │
│  │ (bloqueante)│    │ char por char    │    │  Sim → envia cmd_queue  │   │
│  └─────────────┘    └──────────────────┘    │  Não → continua lendo   │   │
│                                             └─────────────────────────┘   │
└───────────────────────────────────────────────┬─────────────────────────────┘
                                                │ cmd_queue
                                                ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│ GCodeParserTask                                                             │
│                                                                             │
│  ┌──────────────────┐                                                      │
│  │ Recebe string    │                                                      │
│  │ da cmd_queue     │                                                      │
│  └────────┬─────────┘                                                      │
│           │                                                                 │
│           ▼                                                                 │
│  ┌──────────────────┐    Não    ┌─────────────────────────────────────┐   │
│  │ Linha vazia ou   ├──────────►│              Tokeniza               │   │
│  │ comentário ';'?  │           │  extrai pares letra+número          │   │
│  └──────────────────┘           └──────────────┬────────────────────┘   │
│                                                 │                          │
│           ┌─────────────────────────────────────┤                          │
│           │                                     │                          │
│    ┌──────▼──────┐   ┌──────────────┐   ┌──────▼──────┐                  │
│    │ '?' (status)│   │ M3 / M5      │   │ G0/G1/G28   │                  │
│    │             │   │ (extrusor)   │   │ (movimento) │                  │
│    └──────┬──────┘   └──────┬───────┘   └──────┬──────┘                  │
│           │                 │                   │                          │
│           ▼                 ▼                   ▼                          │
│  Sinaliza          extruder_queue        motion_queue                     │
│  status_semaphore  (ON ou OFF)           (motion_cmd_t)                   │
│           │                 │                   │                          │
│           └────────┬────────┘                   │                          │
│                    ▼                             ▼                          │
│              Envia "ok\n"                  Envia "ok\n"                    │
│              via UART                      via UART                        │
└─────────────────────────────────────────────────────────────────────────────┘
                              │                   │
                              ▼                   ▼
                       ExtruderTask       MotionPlannerTask
                       (GPIO direto)           (ver abaixo)
```

## 2. Fluxo do MotionPlannerTask

```
┌─────────────────────────────────────────────────────────────────────────────┐
│ MotionPlannerTask                                                           │
│                                                                             │
│  ┌────────────────────────────────────────────────────────────────────┐    │
│  │ Recebe motion_cmd_t da motion_queue                                │    │
│  │   { type: G0/G1/G28, x, y, feedrate, mode: ABS/REL }              │    │
│  └──────────────────────────────┬─────────────────────────────────────┘    │
│                                 │                                           │
│                                 ▼                                           │
│  ┌──────────────────────────────────────────────────────────────────────┐  │
│  │ Converte coordenadas para passos                                     │  │
│  │   steps_x = (target_x - current_x) * STEPS_PER_MM_X                │  │
│  │   steps_y = (target_y - current_y) * STEPS_PER_MM_Y                │  │
│  └──────────────────────────────┬───────────────────────────────────────┘  │
│                                 │                                           │
│                                 ▼                                           │
│  ┌──────────────────────────────────────────────────────────────────────┐  │
│  │ Calcula parâmetros Bresenham                                         │  │
│  │   dx = |steps_x|,  dy = |steps_y|                                   │  │
│  │   dominant = max(dx, dy)  → eixo principal                          │  │
│  │   error_init = dominant / 2                                          │  │
│  │   dir_x, dir_y = sinais dos deltas                                  │  │
│  └──────────────────────────────┬───────────────────────────────────────┘  │
│                                 │                                           │
│                                 ▼                                           │
│  ┌──────────────────────────────────────────────────────────────────────┐  │
│  │ Calcula perfil trapezoidal                                           │  │
│  │   v_entry = 0 (simplificado — pode ser melhorado)                   │  │
│  │   v_exit  = 0                                                        │  │
│  │   v_max   = feedrate / 60.0 (mm/s)                                  │  │
│  │   step_rate_max = v_max * STEPS_PER_MM                              │  │
│  │   accel_steps = (v_max² - v_entry²) / (2 * ACCEL_MM_S2)            │  │
│  │   decel_steps = (v_max² - v_exit²)  / (2 * ACCEL_MM_S2)            │  │
│  │   cruise_steps = total_steps - accel_steps - decel_steps            │  │
│  └──────────────────────────────┬───────────────────────────────────────┘  │
│                                 │                                           │
│                                 ▼                                           │
│  ┌──────────────────────────────────────────────────────────────────────┐  │
│  │ Preenche motion_block_t e envia para block_queue                     │  │
│  │   { steps_x, steps_y, dir_x, dir_y, dx, dy, error,                  │  │
│  │     accel_steps, cruise_steps, decel_steps,                          │  │
│  │     initial_rate, max_rate, final_rate }                             │  │
│  └──────────────────────────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────────────────────────┘
```

## 3. Fluxo do MotionExecutorTask + ISR

```
┌─────────────────────────────────────────────────────────────────────────────┐
│ MotionExecutorTask                                                          │
│                                                                             │
│  ┌────────────────────────────┐                                            │
│  │ Recebe motion_block_t      │                                            │
│  │ da block_queue             │                                            │
│  └────────────────┬───────────┘                                            │
│                   │                                                         │
│                   ▼                                                         │
│  ┌────────────────────────────────────────────────────────────────────┐    │
│  │ Configura variáveis globais da ISR (em seção crítica)              │    │
│  │   g_isr_ctx.block  = &current_block                                │    │
│  │   g_isr_ctx.step_count = 0                                         │    │
│  │   g_isr_ctx.phase = ACCEL                                          │    │
│  │   g_isr_ctx.current_rate = block.initial_rate                      │    │
│  └────────────────┬───────────────────────────────────────────────────┘    │
│                   │                                                         │
│                   ▼                                                         │
│  ┌────────────────────────────────────────────────────────────────────┐    │
│  │ Configura GPIO DIR para X e Y                                       │    │
│  │ Habilita stepper (EN_PIN = LOW)                                     │    │
│  │ Arma GPTimer com initial_period_us                                  │    │
│  └────────────────┬───────────────────────────────────────────────────┘    │
│                   │                                                         │
│                   ▼                                                         │
│  ┌────────────────────────────────────────────────────────────────────┐    │
│  │ xTaskNotifyWait(EVENT_BLOCK_DONE | EVENT_ALARM, portMAX_DELAY)     │    │
│  │ (BLOQUEIA — ISR controla o hardware)                               │    │
│  └────────────────┬───────────────────────────────────────────────────┘    │
│                   │ (ISR completa o bloco e notifica)                       │
│                   ▼                                                         │
│  ┌────────────────────────────────────────────────────────────────────┐    │
│  │ Atualiza g_state.mpos_x += block.steps_x / STEPS_PER_MM_X         │    │
│  │ Atualiza g_state.mpos_y += block.steps_y / STEPS_PER_MM_Y         │    │
│  │ Se fila vazia: g_state.status = IDLE                               │    │
│  └────────────────────────────────────────────────────────────────────┘    │
└─────────────────────────────────────────────────────────────────────────────┘
                   │
                   │ (GPTimer ISR — IRAM_ATTR, Core 1)
                   ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│ gptimer_isr_callback()                                                      │
│                                                                             │
│  ┌────────────────────────────────────────────────────────────────────┐    │
│  │ Bresenham — eixo X (dominante neste exemplo):                      │    │
│  │   Sempre: pulso STEP no eixo X                                     │    │
│  │   error += dy                                                      │    │
│  │   if (error >= dx):                                                │    │
│  │       pulso STEP no eixo Y                                         │    │
│  │       error -= dx                                                  │    │
│  └────────────────┬───────────────────────────────────────────────────┘    │
│                   │                                                         │
│                   ▼                                                         │
│  ┌────────────────────────────────────────────────────────────────────┐    │
│  │ Atualiza fase trapezoidal:                                         │    │
│  │   ACCEL:  step_count < accel_steps → diminui period               │    │
│  │   CRUISE: step_count < accel+cruise → mantém period               │    │
│  │   DECEL:  step_count < total       → aumenta period               │    │
│  └────────────────┬───────────────────────────────────────────────────┘    │
│                   │                                                         │
│                   ▼                                                         │
│  ┌────────────────────────────────────────────────────────────────────┐    │
│  │ step_count++                                                       │    │
│  │ Se step_count >= total_steps:                                      │    │
│  │   Para GPTimer                                                     │    │
│  │   xTaskNotifyFromISR(executor_task, EVENT_BLOCK_DONE, ...)         │    │
│  │ Senão:                                                             │    │
│  │   gptimer_set_alarm(new_period)  ← re-arma com period atualizado  │    │
│  └────────────────────────────────────────────────────────────────────┘    │
└─────────────────────────────────────────────────────────────────────────────┘
```

## 4. Fluxo de Homing (G28)

```
GCodeParser recebe "G28"
    │
    ▼
Envia motion_cmd_t { type: HOMING } para motion_queue
    │
    ▼
MotionPlanner recebe → cria bloco especial HOMING → block_queue
    │
    ▼
MotionExecutor detecta bloco HOMING:
    1. Move X em direção negativa (baixa velocidade)
    2. Monitora endstop X (polling GPIO ou ISR de GPIO)
    3. Endstop X acionado → para, zera posição X
    4. Recua X alguns passos (de-bounce mechanical)
    5. Repete para Y
    6. g_state.mpos = {0, 0}
    7. Sinaliza EVENT_HOMING_DONE
    │
    ▼
GCodeParser responde "ok\n"
```


# Matemática do Planejamento de Movimento

## 1. Algoritmo de Bresenham (Interpolação Linear XY)

### Conceito

O algoritmo de Bresenham, originalmente criado para rasterização de linhas em monitores,
é amplamente usado em CNC porque opera inteiramente em aritmética inteira — sem divisões
nem ponto flutuante na ISR crítica.

### Formulação

Dado um movimento de (x₀, y₀) até (x₁, y₁) em passos inteiros:

```
dx = |x₁ - x₀|
dy = |y₁ - y₀|
```

Definimos o eixo dominante como o que possui maior delta:
- Se dx ≥ dy: eixo X é dominante
- Caso contrário: eixo Y é dominante

O eixo dominante avança um passo a cada ciclo da ISR.
O eixo subordinado avança somente quando o **acumulador de erro** ultrapassa o limiar.

### Código da ISR (pseudocódigo)

```c
// Inicialização (no Planner, antes de enviar o bloco):
ctx.error = dominant / 2;   // erro inicial (arredondamento central)
ctx.dominant_steps = dominant;
ctx.subordinate_steps = subordinate;

// A cada ciclo da ISR:
// 1. Avança eixo dominante sempre
step(dominant_axis);

// 2. Acumula erro
ctx.error += ctx.subordinate_steps;

// 3. Avança eixo subordinado se erro ultrapassou limiar
if (ctx.error >= ctx.dominant_steps) {
    step(subordinate_axis);
    ctx.error -= ctx.dominant_steps;
}

ctx.step_count++;
```

### Exemplo Numérico

Movimento: (0,0) → (5,3) em passos
- dx = 5, dy = 3 → X é dominante
- error_init = 5/2 = 2

| Ciclo | Passo X | error += 3 | error ≥ 5? | Passo Y | error após |
|-------|---------|------------|------------|---------|------------|
| 1     | ✓       | 2+3=5      | 5≥5 ✓      | ✓       | 5-5=0      |
| 2     | ✓       | 0+3=3      | 3≥5 ✗      |         | 3          |
| 3     | ✓       | 3+3=6      | 6≥5 ✓      | ✓       | 6-5=1      |
| 4     | ✓       | 1+3=4      | 4≥5 ✗      |         | 4          |
| 5     | ✓       | 4+3=7      | 7≥5 ✓      | ✓       | 7-5=2      |

Resultado: 5 passos em X, 3 passos em Y — linha (0,0)→(5,3) perfeitamente interpolada.

## 2. Perfil de Velocidade Trapezoidal

### Conceito

O perfil trapezoidal divide o movimento em 3 fases:

```
  Velocidade
      │
  v_max ─────────────────────────────────
      │           ╱─────────────╲
      │          ╱               ╲
  v_entry      ╱                 ╲     v_exit
      │────────╱                   ╲────────
      │
      └──────────────────────────────────── Passos
            accel    cruise    decel
```

### Equações

**Conversão feedrate → step_rate:**
```
v_mm_s = feedrate_mm_min / 60.0
step_rate_max = v_mm_s × STEPS_PER_MM    [passos/segundo]
step_period_min_us = 1e6 / step_rate_max  [µs entre passos]
```

**Cálculo de passos em cada fase:**
```
accel_dist_mm = (v_max² - v_entry²) / (2 × ACCELERATION)
decel_dist_mm = (v_max² - v_exit²)  / (2 × ACCELERATION)

accel_steps = accel_dist_mm × STEPS_PER_MM
decel_steps = decel_dist_mm × STEPS_PER_MM
cruise_steps = total_steps - accel_steps - decel_steps

// Se cruise_steps < 0: movimento triangular (não atinge v_max)
// Neste caso, reduzir v_max até cruise_steps = 0
```

**Variação do period durante aceleração:**

A variação do step_period durante aceleração usa a aproximação de Olds
(usada no GRBL original):

```
// Inicialização:
period_us = sqrt(2.0 / ACCEL_STEPS_S2) × 1e6   // período para primeiro passo

// A cada passo na fase de aceleração:
period_us = period_us × (2N - 1) / (2N + 1)
// onde N = número do passo atual (1, 2, 3, ...)

// Na fase de desaceleração: inverso (período aumenta)
period_us = period_us × (2N + 1) / (2N - 1)
```

**Por que essa aproximação?**

A equação exata seria `period_n = sqrt(2s/a) × (sqrt(n) - sqrt(n-1))`,
que requer `sqrt()` a cada passo — inviável em ISR.
A aproximação de Olds usa apenas multiplicação inteira e tem erro < 1%
para N > 3, o que é aceitável para motores de passo.

**Implementação prática (inteira):**

Para evitar ponto flutuante na ISR, pré-calculamos a tabela de periods
no Planner (que roda com mais tempo) e armazenamos somente:
- `initial_period_us` (período do primeiro passo)
- `min_period_us` (período mínimo = velocidade máxima)
- `accel_steps`, `decel_steps` (limites de fase)

Na ISR, usamos uma aproximação inteira simplificada:

```c
// Aceleração: subtrai delta_accel de period a cada passo
// delta_accel = (initial_period - min_period) / accel_steps
if (phase == ACCEL) {
    period_us -= accel_delta;
    if (period_us <= min_period_us) {
        period_us = min_period_us;
        phase = CRUISE;
    }
}
// Desaceleração: adiciona delta_decel a cada passo
else if (phase == DECEL) {
    period_us += decel_delta;
}
```

Esta simplificação (ramp linear em período) não é fisicamente exata
(velocidade não é linear), mas é suficiente para demonstração educacional
e evita `sqrt` na ISR.

## 3. Relação entre GPTimer e Step Rate

O GPTimer opera com resolução de 1µs (clock base 1MHz).

```
step_rate [steps/s] = 1e6 / period_us

Exemplo:
- Feedrate = 600 mm/min = 10 mm/s
- STEPS_PER_MM = 80 (A4988, 1/16 step, 200 steps/rev, 2.5mm/rev leadscrew)
- step_rate = 10 × 80 = 800 steps/s
- period_us = 1e6 / 800 = 1250 µs entre passos

Velocidade mínima (para não perder passos):
- GRBL usa ~30 steps/s mínimo → 33333 µs
- Velocidade máxima prática (A4988 @ 1/16): ~3000 steps/s → 333 µs
```

## 4. Diagrama de Timing dos Pulsos STEP

```
Sinal STEP (GPIO):

          ┌──┐    ┌──┐    ┌──┐         ┌──┐  ┌──┐  ┌──┐
          │  │    │  │    │  │   ...   │  │  │  │  │  │
──────────┘  └────┘  └────┘  └─────────┘  └──┘  └──┘  └────

←── T1 ──►←── T2 ──►←── T3 ──►       ←T_min→←T_min→←T_min→
  (accel)  (accel)  (accel)           (cruise)(cruise)(cruise)

T1 > T2 > T3 > ... > T_min (aceleração: periods decrescem)
T_min = constante (cruzeiro)
T_min < ... < T_n (desaceleração: periods crescem)

Largura do pulso HIGH: mínimo 1µs (A4988 exige ≥ 1µs, DRV8825 ≥ 1.9µs)
→ Usar 2µs de HIGH para compatibilidade com ambos os drivers
→ Na ISR: set GPIO, aguardar 2 ciclos NOP, clear GPIO
```

# Estrutura de Diretórios do Projeto

## 1. Árvore Completa

```
xy_gcode_firmware/
│
├── CMakeLists.txt                   ← Raiz do projeto ESP-IDF
├── sdkconfig.defaults               ← Configurações padrão do menuconfig
├── partitions.csv                   ← Tabela de partições (opcional)
│
├── main/
│   ├── CMakeLists.txt
│   └── main.c                       ← Ponto de entrada: app_main()
│                                       Inicializa HAL, cria filas/semáforos,
│                                       cria tarefas, deleta a si mesmo
│
├── components/
│   │
│   ├── config/
│   │   ├── CMakeLists.txt
│   │   └── include/
│   │       └── config.h             ← Todas as constantes configuráveis:
│   │                                   STEPS_PER_MM_X/Y, ACCELERATION,
│   │                                   MAX_FEEDRATE, GPIO pins, UART port,
│   │                                   tamanhos de filas, stack sizes
│   │
│   ├── hal/
│   │   ├── CMakeLists.txt
│   │   ├── include/
│   │   │   ├── hal_stepper.h        ← Interface da HAL de motores de passo
│   │   │   ├── hal_endstop.h        ← Interface da HAL de fim de curso
│   │   │   └── hal_extruder.h       ← Interface da HAL do extrusor
│   │   └── src/
│   │       ├── hal_stepper.c        ← Implementação: init/step/dir/enable
│   │       │                           Seleção A4988 vs DRV8825 via #ifdef
│   │       ├── hal_endstop.c        ← Leitura de GPIO com debounce
│   │       └── hal_extruder.c       ← Set/clear GPIO extrusor
│   │
│   ├── gcode/
│   │   ├── CMakeLists.txt
│   │   ├── include/
│   │   │   ├── gcode_parser.h       ← Interface do parser
│   │   │   └── gcode_types.h        ← Tipos: motion_cmd_t, extruder_cmd_t,
│   │   │                               gcode_word_t, position_mode_t
│   │   └── src/
│   │       └── gcode_parser.c       ← Tokenização, extração de palavras G-Code
│   │
│   ├── planner/
│   │   ├── CMakeLists.txt
│   │   ├── include/
│   │   │   ├── motion_planner.h     ← Interface do planejador
│   │   │   └── motion_block.h       ← Tipo motion_block_t
│   │   └── src/
│   │       └── motion_planner.c     ← Cálculo Bresenham + trapezoidal
│   │
│   ├── executor/
│   │   ├── CMakeLists.txt
│   │   ├── include/
│   │   │   └── motion_executor.h    ← Interface do executor
│   │   └── src/
│   │       ├── motion_executor.c    ← Lógica da MotionExecutorTask
│   │       └── step_generator.c     ← ISR do GPTimer (IRAM_ATTR)
│   │                                   Contexto global da ISR
│   │
│   ├── protocol/
│   │   ├── CMakeLists.txt
│   │   ├── include/
│   │   │   └── grbl_protocol.h      ← Interface: respostas ok/error/status
│   │   └── src/
│   │       └── grbl_protocol.c      ← Formata e envia strings GRBL via UART
│   │
│   ├── system/
│   │   ├── CMakeLists.txt
│   │   ├── include/
│   │   │   └── system_state.h       ← system_state_t, mutex, event group
│   │   │                               handles globais das filas
│   │   └── src/
│   │       └── system_state.c       ← Inicialização do estado global
│   │
│   └── tasks/
│       ├── CMakeLists.txt
│       ├── include/
│       │   ├── task_uart.h
│       │   ├── task_gcode_parser.h
│       │   ├── task_motion_planner.h
│       │   ├── task_motion_executor.h
│       │   ├── task_extruder.h
│       │   └── task_monitor.h
│       └── src/
│           ├── task_uart.c          ← UARTTask
│           ├── task_gcode_parser.c  ← GCodeParserTask
│           ├── task_motion_planner.c← MotionPlannerTask
│           ├── task_motion_executor.c← MotionExecutorTask
│           ├── task_extruder.c      ← ExtruderTask
│           └── task_monitor.c       ← MonitorTask
│
└── docs/
    ├── architecture/                ← Documentos desta etapa (você está aqui)
    │   ├── 01_visao_geral.md
    │   ├── 02_diagrama_tarefas.md
    │   ├── 03_diagrama_filas.md
    │   ├── 04_fluxograma_gcode.md
    │   ├── 05_matematica_movimento.md
    │   └── 06_estrutura_diretorios.md
    ├── manual_tecnico.md            ← Gerado na Etapa 7
    ├── manual_usuario.md            ← Gerado na Etapa 7
    └── freertos_usage.md            ← Gerado na Etapa 7
```

## 2. Justificativa de Cada Módulo

| Módulo | Responsabilidade | Não faz |
|--------|-----------------|---------|
| `config/` | Centraliza todos os `#define` configuráveis | Nenhuma lógica |
| `hal/` | Abstrai o hardware específico | Não conhece G-Code nem FreeRTOS |
| `gcode/` | Parseia strings em structs | Não planeja movimento nem acessa hardware |
| `planner/` | Matemática de trajetória | Não acessa hardware, não conhece UART |
| `executor/` | Execução em tempo real via GPTimer ISR | Não parseia G-Code |
| `protocol/` | Formata respostas GRBL | Não toma decisões de estado |
| `system/` | Estado compartilhado protegido | Nenhuma lógica de negócio |
| `tasks/` | Glue code FreeRTOS | Apenas coordena módulos acima |
| `main/` | Bootstrap | Apenas cria tasks e deleta a si mesmo |

## 3. Diagrama de Dependências entre Módulos

```
main
 └── tasks
      ├── task_uart          → protocol, system
      ├── task_gcode_parser  → gcode, protocol, system
      ├── task_motion_planner→ planner, system
      ├── task_motion_executor→executor, hal, system
      ├── task_extruder      → hal, system
      └── task_monitor       → protocol, system

executor
 └── step_generator (ISR)   → hal (stepper), system (ISR-safe reads only)

planner   → config, gcode_types
gcode     → config, gcode_types
hal       → config (GPIO pins, driver selection)
protocol  → system (state para resposta '?')
system    → (sem dependências internas — apenas ESP-IDF + FreeRTOS)
config    → (sem dependências — apenas #defines)
```

## 4. Regras de Acesso ao Hardware

```
Regra: SOMENTE a HAL toca registradores de hardware diretamente.
       SOMENTE o step_generator.c (ISR) chama hal_stepper_step() diretamente.
       Todas as outras chamadas de hardware passam pela fila ou pelo executor.

Exceção permitida: grbl_protocol.c chama uart_write_bytes() diretamente
                   (UART TX é não-bloqueante e thread-safe no ESP-IDF).
```

# Diagrama de Componentes

## 1. Componentes de Software e suas Interfaces

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                        DIAGRAMA DE COMPONENTES                              │
│                                                                             │
│  ┌────────────────────────────────────────────────────────────────────┐    │
│  │                         «component»                                │    │
│  │                           tasks/                                   │    │
│  │                                                                    │    │
│  │  ┌─────────────┐  ┌──────────────┐  ┌─────────────────────────┐  │    │
│  │  │  UARTTask   │  │GCodeParser   │  │   MotionPlannerTask     │  │    │
│  │  │             │  │Task          │  │                         │  │    │
│  │  └──────┬──────┘  └──────┬───────┘  └────────────┬────────────┘  │    │
│  │         │[cmd_q]         │[motion_q] [extruder_q] │[block_q]      │    │
│  │  ┌──────┴──────────┐     │           │            │              │    │
│  │  │  MonitorTask    │     │           │            │              │    │
│  │  │  [state_mutex]  │     │           │            │              │    │
│  │  └─────────────────┘     │           │            │              │    │
│  │                    ┌─────┘           │     ┌──────┘              │    │
│  │                    │                 │     │                     │    │
│  │  ┌─────────────────┴────┐   ┌────────┴─────┴──────────────────┐  │    │
│  │  │   ExtruderTask       │   │      MotionExecutorTask         │  │    │
│  │  │                      │   │      + step_generator ISR       │  │    │
│  │  └──────────┬───────────┘   └──────────────┬──────────────────┘  │    │
│  └─────────────┼────────────────────────────────┼───────────────────┘    │
│                │                                │                          │
│                ▼ «uses»                         ▼ «uses»                   │
│  ┌─────────────────────────────────────────────────────────────────────┐  │
│  │                         «component»                                 │  │
│  │                           hal/                                      │  │
│  │                                                                     │  │
│  │  ┌───────────────────────┐  ┌────────────────┐  ┌───────────────┐  │  │
│  │  │   hal_stepper         │  │  hal_endstop   │  │hal_extruder   │  │  │
│  │  │                       │  │                │  │               │  │  │
│  │  │ +init()               │  │ +init()        │  │ +init()       │  │  │
│  │  │ +set_dir(axis, dir)   │  │ +read_x(): bool│  │ +on()         │  │  │
│  │  │ +step(axis)           │  │ +read_y(): bool│  │ +off()        │  │  │
│  │  │ +enable(axis)         │  │                │  │ +is_on(): bool│  │  │
│  │  │ +disable(axis)        │  └────────────────┘  └───────────────┘  │  │
│  │  └───────────────────────┘                                          │  │
│  └─────────────────────────────────────────────────────────────────────┘  │
│                                │                                            │
│                                ▼ «uses»                                    │
│  ┌─────────────────────────────────────────────────────────────────────┐  │
│  │                         «component»                                 │  │
│  │                           config/                                   │  │
│  │                                                                     │  │
│  │  #define STEPS_PER_MM_X    80                                       │  │
│  │  #define STEPS_PER_MM_Y    80                                       │  │
│  │  #define ACCELERATION      500   // mm/s²                           │  │
│  │  #define MAX_FEEDRATE      3000  // mm/min                          │  │
│  │  #define DRIVER_A4988             // ou DRIVER_DRV8825              │  │
│  │  #define GPIO_STEP_X       18                                       │  │
│  │  #define GPIO_DIR_X        19                                       │  │
│  │  ... (todos os demais defines)                                      │  │
│  └─────────────────────────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────────────────────────┘
```

## 2. Interfaces das Structs Principais

### motion_cmd_t (saída do GCodeParser → entrada do Planner)
```c
typedef struct {
    enum { CMD_MOVE_G0, CMD_MOVE_G1, CMD_HOMING } type;
    float target_x;         // mm (coordenada absoluta já resolvida)
    float target_y;         // mm
    float feedrate;         // mm/min
} motion_cmd_t;
```

### motion_block_t (saída do Planner → entrada do Executor)
```c
typedef struct {
    // Bresenham
    int32_t steps_x;        // total de passos em X (com sinal = direção)
    int32_t steps_y;        // total de passos em Y
    int32_t dominant;       // max(|steps_x|, |steps_y|)
    int32_t subordinate;    // min(|steps_x|, |steps_y|)
    int32_t bresenham_error;// erro inicial = dominant/2
    bool    dominant_is_x;  // true se X é dominante
    int8_t  dir_x;          // +1 ou -1
    int8_t  dir_y;          // +1 ou -1

    // Perfil trapezoidal
    uint32_t total_steps;       // = dominant
    uint32_t accel_steps;
    uint32_t decel_step_start;  // = total_steps - decel_steps
    uint32_t initial_period_us; // período do 1º passo
    uint32_t min_period_us;     // período no cruzeiro
    uint32_t accel_increment;   // subtrai do period por passo (accel)
    uint32_t decel_increment;   // soma ao period por passo (decel)
} motion_block_t;
```

### system_state_t (estado global protegido por mutex)
```c
typedef enum {
    STATE_IDLE,
    STATE_RUN,
    STATE_HOMING,
    STATE_ALARM
} machine_state_t;

typedef struct {
    machine_state_t status;
    float           mpos_x;   // posição em mm
    float           mpos_y;
    float           feedrate;
    bool            extruder_on;
    bool            position_absolute; // true=G90, false=G91
} system_state_t;
```

## 3. Seleção de Driver por Configuração

A HAL usa compilação condicional para suportar A4988 e DRV8825:

```c
// Em config.h:
// #define STEPPER_DRIVER  DRIVER_A4988
// #define STEPPER_DRIVER  DRIVER_DRV8825

// Em hal_stepper.c:
#if STEPPER_DRIVER == DRIVER_A4988
    // A4988: MS1, MS2, MS3 para microstepping
    // RESET e SLEEP ativos-baixo
    // Step pulse: mín 1µs HIGH
    #define STEP_PULSE_US   2
    #define DIR_SETUP_US    1

#elif STEPPER_DRIVER == DRIVER_DRV8825
    // DRV8825: MODE0, MODE1, MODE2 para microstepping
    // RESET ativo-baixo, SLEEP ativo-alto
    // Step pulse: mín 1.9µs HIGH
    #define STEP_PULSE_US   3
    #define DIR_SETUP_US    1
#endif
```

