# Matemática do Planejamento de Movimento

## 1. Algoritmo de Bresenham (Interpolação Linear XY)

### Conceito

O algoritmo de Bresenham, originalmente criado para rasterização de linhas em monitores,
é amplamente usado em CNC porque opera inteiramente em aritmética inteira — sem divisões
nem ponto flutuante na ISR crítica.

### Formulação

Dado um movimento de (x₀, y₀) até (x₁, y₁) em passos inteiros:

```
dx = |x₁ - x₀|
dy = |y₁ - y₀|
```

Definimos o eixo dominante como o que possui maior delta:
- Se dx ≥ dy: eixo X é dominante
- Caso contrário: eixo Y é dominante

O eixo dominante avança um passo a cada ciclo da ISR.
O eixo subordinado avança somente quando o **acumulador de erro** ultrapassa o limiar.

### Código da ISR (pseudocódigo)

```c
// Inicialização (no Planner, antes de enviar o bloco):
ctx.error = dominant / 2;   // erro inicial (arredondamento central)
ctx.dominant_steps = dominant;
ctx.subordinate_steps = subordinate;

// A cada ciclo da ISR:
// 1. Avança eixo dominante sempre
step(dominant_axis);

// 2. Acumula erro
ctx.error += ctx.subordinate_steps;

// 3. Avança eixo subordinado se erro ultrapassou limiar
if (ctx.error >= ctx.dominant_steps) {
    step(subordinate_axis);
    ctx.error -= ctx.dominant_steps;
}

ctx.step_count++;
```

### Exemplo Numérico

Movimento: (0,0) → (5,3) em passos
- dx = 5, dy = 3 → X é dominante
- error_init = 5/2 = 2

| Ciclo | Passo X | error += 3 | error ≥ 5? | Passo Y | error após |
|-------|---------|------------|------------|---------|------------|
| 1     | ✓       | 2+3=5      | 5≥5 ✓      | ✓       | 5-5=0      |
| 2     | ✓       | 0+3=3      | 3≥5 ✗      |         | 3          |
| 3     | ✓       | 3+3=6      | 6≥5 ✓      | ✓       | 6-5=1      |
| 4     | ✓       | 1+3=4      | 4≥5 ✗      |         | 4          |
| 5     | ✓       | 4+3=7      | 7≥5 ✓      | ✓       | 7-5=2      |

Resultado: 5 passos em X, 3 passos em Y — linha (0,0)→(5,3) perfeitamente interpolada.

## 2. Perfil de Velocidade Trapezoidal

### Conceito

O perfil trapezoidal divide o movimento em 3 fases:

```
  Velocidade
      │
  v_max ─────────────────────────────────
      │           ╱─────────────╲
      │          ╱               ╲
  v_entry      ╱                 ╲     v_exit
      │────────╱                   ╲────────
      │
      └──────────────────────────────────── Passos
            accel    cruise    decel
```

### Equações

**Conversão feedrate → step_rate:**
```
v_mm_s = feedrate_mm_min / 60.0
step_rate_max = v_mm_s × STEPS_PER_MM    [passos/segundo]
step_period_min_us = 1e6 / step_rate_max  [µs entre passos]
```

**Cálculo de passos em cada fase:**
```
accel_dist_mm = (v_max² - v_entry²) / (2 × ACCELERATION)
decel_dist_mm = (v_max² - v_exit²)  / (2 × ACCELERATION)

accel_steps = accel_dist_mm × STEPS_PER_MM
decel_steps = decel_dist_mm × STEPS_PER_MM
cruise_steps = total_steps - accel_steps - decel_steps

// Se cruise_steps < 0: movimento triangular (não atinge v_max)
// Neste caso, reduzir v_max até cruise_steps = 0
```

**Variação do period durante aceleração:**

A variação do step_period durante aceleração usa a aproximação de Olds
(usada no GRBL original):

```
// Inicialização:
period_us = sqrt(2.0 / ACCEL_STEPS_S2) × 1e6   // período para primeiro passo

// A cada passo na fase de aceleração:
period_us = period_us × (2N - 1) / (2N + 1)
// onde N = número do passo atual (1, 2, 3, ...)

// Na fase de desaceleração: inverso (período aumenta)
period_us = period_us × (2N + 1) / (2N - 1)
```

**Por que essa aproximação?**

A equação exata seria `period_n = sqrt(2s/a) × (sqrt(n) - sqrt(n-1))`,
que requer `sqrt()` a cada passo — inviável em ISR.
A aproximação de Olds usa apenas multiplicação inteira e tem erro < 1%
para N > 3, o que é aceitável para motores de passo.

**Implementação prática (inteira):**

Para evitar ponto flutuante na ISR, pré-calculamos a tabela de periods
no Planner (que roda com mais tempo) e armazenamos somente:
- `initial_period_us` (período do primeiro passo)
- `min_period_us` (período mínimo = velocidade máxima)
- `accel_steps`, `decel_steps` (limites de fase)

Na ISR, usamos uma aproximação inteira simplificada:

```c
// Aceleração: subtrai delta_accel de period a cada passo
// delta_accel = (initial_period - min_period) / accel_steps
if (phase == ACCEL) {
    period_us -= accel_delta;
    if (period_us <= min_period_us) {
        period_us = min_period_us;
        phase = CRUISE;
    }
}
// Desaceleração: adiciona delta_decel a cada passo
else if (phase == DECEL) {
    period_us += decel_delta;
}
```

Esta simplificação (ramp linear em período) não é fisicamente exata
(velocidade não é linear), mas é suficiente para demonstração educacional
e evita `sqrt` na ISR.

## 3. Relação entre GPTimer e Step Rate

O GPTimer opera com resolução de 1µs (clock base 1MHz).

```
step_rate [steps/s] = 1e6 / period_us

Exemplo:
- Feedrate = 600 mm/min = 10 mm/s
- STEPS_PER_MM = 80 (A4988, 1/16 step, 200 steps/rev, 2.5mm/rev leadscrew)
- step_rate = 10 × 80 = 800 steps/s
- period_us = 1e6 / 800 = 1250 µs entre passos

Velocidade mínima (para não perder passos):
- GRBL usa ~30 steps/s mínimo → 33333 µs
- Velocidade máxima prática (A4988 @ 1/16): ~3000 steps/s → 333 µs
```

## 4. Diagrama de Timing dos Pulsos STEP

```
Sinal STEP (GPIO):

          ┌──┐    ┌──┐    ┌──┐         ┌──┐  ┌──┐  ┌──┐
          │  │    │  │    │  │   ...   │  │  │  │  │  │
──────────┘  └────┘  └────┘  └─────────┘  └──┘  └──┘  └────

←── T1 ──►←── T2 ──►←── T3 ──►       ←T_min→←T_min→←T_min→
  (accel)  (accel)  (accel)           (cruise)(cruise)(cruise)

T1 > T2 > T3 > ... > T_min (aceleração: periods decrescem)
T_min = constante (cruzeiro)
T_min < ... < T_n (desaceleração: periods crescem)

Largura do pulso HIGH: mínimo 1µs (A4988 exige ≥ 1µs, DRV8825 ≥ 1.9µs)
→ Usar 2µs de HIGH para compatibilidade com ambos os drivers
→ Na ISR: set GPIO, aguardar 2 ciclos NOP, clear GPIO
```
