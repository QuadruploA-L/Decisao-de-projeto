# Arquitetura Geral v2 — Firmware XY G-Code (ESP32 + FreeRTOS)

## 1. Visão Sistêmica

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                     FIRMWARE XY G-CODE ESP32 — v2                           │
│                                                                             │
│  ┌────────────────────────────────────────────────────────────────────┐    │
│  │                     CAMADA DE APLICAÇÃO (Core 0)                   │    │
│  │                                                                    │    │
│  │  ┌──────────────┐  ┌───────────────┐  ┌──────────────┐            │    │
│  │  │  UARTTask    │  │ GCodeParser   │  │MotionPlanner │            │    │
│  │  │  Prio 2      │  │ Task  Prio 3  │  │Task  Prio 3  │            │    │
│  │  │              │  │               │  │              │            │    │
│  │  │ ┌──────────┐ │  │               │  │              │            │    │
│  │  │ │'?' detect│ │  │               │  │              │            │    │
│  │  │ │imediato  │ │  │               │  │              │            │    │
│  │  │ └──────────┘ │  │               │  │              │            │    │
│  │  └──────┬───────┘  └───────┬───────┘  └──────┬───────┘           │    │
│  │         │                  │                  │                   │    │
│  │  ┌──────┴───────────────────────────────────┐ │                   │    │
│  │  │          MonitorTask  Prio 1             │ │                   │    │
│  │  │    (watchdog + overflow — background)    │ │                   │    │
│  │  └──────────────────────────────────────────┘ │                   │    │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                    │                    │                                   │
│           CAMADA DE IPC (FreeRTOS)      │                                   │
│  ┌─────────────────────────────────────┼─────────────────────────────┐    │
│  │                                     │                             │    │
│  │  cmd_queue (10×96B)                 │                             │    │
│  │  motion_queue (8 items)             │                             │    │
│  │  planner_queue (16 items)  ◄────────┘                             │    │
│  │  state_mutex                                                      │    │
│  │  uart_tx_mutex                                                    │    │
│  │  motion_event_group (3 bits)                                      │    │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                        │                                   │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │              CAMADA DE EXECUÇÃO (Core 1 — tempo real)               │   │
│  │                                                                     │   │
│  │  ┌────────────────────────────────────────────────────────────────┐ │   │
│  │  │  MotionExecutorTask  Prio 4  (Core 1 fixo)                     │ │   │
│  │  │  • Consome planner_queue                                       │ │   │
│  │  │  • Aplica extruder_action (hal_extruder) antes de cada bloco   │ │   │
│  │  │  • Configura g_isr_ctx (seção crítica)                         │ │   │
│  │  │  • Arma GPTimer → bloqueia em xTaskNotifyWait                  │ │   │
│  │  │  • Atualiza g_state após conclusão                             │ │   │
│  │  └────────────────────────────────────────────────────────────────┘ │   │
│  │                                                                     │   │
│  │  ┌────────────────────────────────────────────────────────────────┐ │   │
│  │  │  GPTimer ISR  (IRAM_ATTR — Core 1)                             │ │   │
│  │  │  • Bresenham + trapezoidal por ciclo                           │ │   │
│  │  │  • GPIO STEP pulso (set → delay_ns → clear)                   │ │   │
│  │  │  • Re-arma timer com novo period                               │ │   │
│  │  │  • Fim de bloco: xTaskNotifyFromISR → Executor                 │ │   │
│  │  └────────────────────────────────────────────────────────────────┘ │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                        │                                   │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │                           CAMADA HAL                                │   │
│  │                                                                     │   │
│  │   hal_stepper  (A4988/DRV8825 por #ifdef)                          │   │
│  │   hal_endstop  (GPIO input + debounce)                             │   │
│  │   hal_extruder (GPIO output ON/OFF) ← chamado pelo Executor        │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                        │                                   │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │                         HARDWARE ESP32                              │   │
│  │  GPTimer  •  GPIO(STEP/DIR/EN)  •  GPIO(Endstop)  •  UART0(USB)   │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────────────────────┘
```

## 2. Comparativo v1 → v2

| Aspecto | v1 | v2 | Motivo |
|---------|----|----|--------|
| Tarefas | 6 (inclui ExtruderTask) | 5 | Extrusor absorvido na pipeline de movimento |
| '?' handler | GCodeParser + MonitorTask | UARTTask direto | Comando de tempo real |
| UART TX sync | Não sincronizado ❌ | uart_tx_mutex ✓ | Evita corrupção de protocolo |
| planner buffer | 3 blocos (block_queue) | 16 blocos (planner_queue) | Anti-starvation |
| ok/error timing | Incorreto (timeout 100ms) | Correto (portMAX_DELAY) | Protocolo GRBL |
| M114 | Não suportado | GCodeParser responde | Sem nova tarefa |
| Sequência extrusor | Pode dessincronizar ❌ | Embedded no bloco ✓ | Correto para deposição |

## 3. Fluxo de Dados v2

```
Serial IN
    │
    ▼
UARTTask
    │── '?' detectado? → Resposta imediata (uart_tx_mutex) ──► Serial OUT
    │
    └── Linha completa → cmd_queue
                              │
                              ▼
                       GCodeParserTask
                              │── M114   → lê state → uart_tx_mutex → Serial OUT
                              │── G90/91 → atualiza state_mutex
                              │── M3/M5  → cria motion_cmd com extruder_action
                              │── G0/G1  → cria motion_cmd
                              │── G28    → cria motion_cmd HOMING
                              │
                              └── motion_queue
                                        │
                                        ▼
                               MotionPlannerTask
                                        │── Converte mm → passos
                                        │── Calcula Bresenham
                                        │── Calcula trapezoidal
                                        │
                                        └── planner_queue (16 slots)
                                                    │
                                                    ▼
                                         MotionExecutorTask (Core 1)
                                                    │── Aplica extruder_action
                                                    │── Configura g_isr_ctx
                                                    │── Arma GPTimer
                                                    │── Aguarda xTaskNotify
                                                    │── Atualiza g_state
                                                    │
                                               GPTimer ISR (Core 1, IRAM)
                                                    │── Bresenham
                                                    │── Trapezoidal
                                                    └── GPIO STEP pulses
```
