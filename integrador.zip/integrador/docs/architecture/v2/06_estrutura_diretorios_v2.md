# Estrutura de Diretórios — v2

## 1. Árvore Completa

```
xy_gcode_firmware/
│
├── CMakeLists.txt
├── sdkconfig.defaults
│
├── main/
│   ├── CMakeLists.txt
│   └── main.c                       ← app_main(): inicializa HAL, cria primitivas
│                                       FreeRTOS (filas, mutexes, event group),
│                                       cria 5 tarefas, deleta a si mesmo
│
├── components/
│   │
│   ├── config/
│   │   └── include/
│   │       └── config.h             ← Todos os parâmetros ajustáveis:
│   │                                   GPIO pins, STEPS_PER_MM, ACCELERATION,
│   │                                   MAX_FEEDRATE, HOMING_SPEED, queue sizes,
│   │                                   GPTIMER_RESOLUTION_HZ, driver selection
│   │
│   ├── hal/
│   │   ├── include/
│   │   │   ├── hal_stepper.h        ← init/set_dir/step/enable/disable
│   │   │   ├── hal_endstop.h        ← init/read_x/read_y
│   │   │   └── hal_extruder.h       ← init/on/off/is_on
│   │   └── src/
│   │       ├── hal_stepper.c        ← Compilação condicional A4988/DRV8825
│   │       ├── hal_endstop.c        ← GPIO input com pull-up, debounce
│   │       └── hal_extruder.c       ← GPIO output simples
│   │
│   ├── gcode/
│   │   ├── include/
│   │   │   ├── gcode_types.h        ← motion_cmd_t, motion_block_t,
│   │   │   │                           system_state_t, machine_state_t
│   │   │   └── gcode_parser.h       ← interface do parser
│   │   └── src/
│   │       └── gcode_parser.c       ← tokenização, extração de palavras,
│   │                                   resolução G90/G91, M114
│   │
│   ├── planner/
│   │   ├── include/
│   │   │   └── motion_planner.h
│   │   └── src/
│   │       └── motion_planner.c     ← Bresenham + trapezoidal
│   │                                   Mantém plan_x/plan_y (posição de planejamento)
│   │                                   Separada de g_state.mpos (posição de execução)
│   │
│   ├── executor/
│   │   ├── include/
│   │   │   └── motion_executor.h
│   │   └── src/
│   │       ├── motion_executor.c    ← MotionExecutorTask, homing
│   │       └── step_generator.c    ← g_isr_ctx, gptimer_isr_callback (IRAM_ATTR)
│   │
│   ├── protocol/
│   │   ├── include/
│   │   │   └── grbl_protocol.h     ← grbl_send_ok/error/status/position
│   │   └── src/
│   │       └── grbl_protocol.c     ← todas as funções adquirem uart_tx_mutex
│   │
│   ├── system/
│   │   ├── include/
│   │   │   └── system_state.h      ← system_state_t, handles globais de todas
│   │   │                              as primitivas FreeRTOS (extern)
│   │   └── src/
│   │       └── system_state.c      ← definição das variáveis globais,
│   │                                  função de inicialização
│   │
│   └── tasks/
│       ├── include/
│       │   ├── task_uart.h
│       │   ├── task_gcode_parser.h
│       │   ├── task_motion_planner.h
│       │   ├── task_motion_executor.h
│       │   └── task_monitor.h
│       │   (task_extruder.h REMOVIDO)
│       └── src/
│           ├── task_uart.c
│           ├── task_gcode_parser.c
│           ├── task_motion_planner.c
│           ├── task_motion_executor.c
│           └── task_monitor.c
│           (task_extruder.c REMOVIDO)
│
└── docs/
    ├── architecture/        ← v1 (arquivado)
    └── architecture/v2/     ← versão atual (este diretório)
```

## 2. Nota Importante: Duas Posições no Sistema

Um detalhe arquitetural que deve ser explicitado:

```
plan_x, plan_y     ← posição de PLANEJAMENTO (atualizada pelo Planner)
g_state.mpos_x/y   ← posição de EXECUÇÃO (atualizada pelo Executor)
```

Estas duas posições podem divergir temporariamente quando há blocos na planner_queue
ainda não executados. O Planner precisa de `plan_x/y` para calcular deltas corretamente
para blocos futuros. O host/monitor usa `g_state.mpos_x/y` para saber onde a ferramenta
fisicamente está.

M114 e '?' respondem com `g_state.mpos` (posição real da ferramenta).
O Parser usa `plan_x/y` para resolver coordenadas G91 (relativas).

```
┌─────────────────────────────────────────────────────────────┐
│  Host envia: G1 X10 / G1 X20 / M114                        │
│                                                             │
│  Planner processa G1 X10 → plan_x = 10, bloco na fila      │
│  Planner processa G1 X20 → plan_x = 20, bloco na fila      │
│  Parser processa M114 → responde g_state.mpos_x = ?        │
│                                                             │
│  Se Executor ainda não executou nada: mpos_x = 0.0         │
│  Se Executor executou G1 X10: mpos_x = 10.0               │
│  Se Executor executou G1 X20: mpos_x = 20.0               │
└─────────────────────────────────────────────────────────────┘
```

Esta divergência é intencional e documentada. Para M114 com sequenciamento exato,
seria necessário um bloco de consulta na fila — fora do escopo deste projeto.
