# Análise de Desempenho e Limites — v2

## 1. Arquitetura de Limites em Três Camadas

### Camada 1 — GPTimer + ESP32 @ 240MHz

O GPTimer do ESP32-IDF tem resolução configurável.
Configuração padrão para este projeto: **clock base 1MHz (resolução 1µs)**.

```
Período mínimo do timer: 1µs  →  1.000.000 steps/s (teórico absoluto)
ISR overhead estimado:   ~1µs  →  período seguro mínimo: 5µs

Limite GPTimer prático:  200.000 steps/s  (período = 5µs)
```

Análise do tempo de ISR:

| Operação | Ciclos @ 240MHz | Tempo (ns) |
|----------|----------------|------------|
| Leitura g_isr_ctx (cache hit) | 1 | 4 |
| Bresenham (3 adições, 1 comp) | 6 | 25 |
| gpio_set_level (GPIO matrix) | 30 | 125 |
| esp_rom_delay_us(2) | 480 | 2.000 |
| gpio_set_level (clear) | 30 | 125 |
| Trapezoidal (2 adições, 1 comp) | 5 | 21 |
| Comparação fim de bloco | 3 | 13 |
| gptimer re-arm | 40 | 167 |
| **Total (pior caso — passo XY)** | **~600** | **~2.500 ns** |

O período mínimo seguro é **5µs** (passo simples) ou **7µs** (passo XY simultâneo)
para garantir que o próximo alarme não dispare durante a própria ISR.

### Camada 2 — Limites dos Drivers de Passo

| Driver | Freq. máx. (datasheet) | Largura mín. HIGH | Largura mín. LOW |
|--------|----------------------|-------------------|------------------|
| A4988  | 500 kHz | 1 µs | 1 µs |
| DRV8825| 250 kHz | 1.9 µs | 1.9 µs |

Usando `esp_rom_delay_us(2)` para HIGH → compatível com ambos.
O driver não é o gargalo neste projeto.

### Camada 3 — Motor + Mecânica (limite real)

O motor de passo perde torque com a frequência de passos. A frequência de pull-out
(acima da qual perde sincronismo) depende da tensão, corrente e carga mecânica.

Para um NEMA17 típico (42mm, 1.7A, 2.5V fase):

| Tensão de alimentação do driver | Frequência de pull-out típica |
|--------------------------------|-------------------------------|
| 12V (A4988 comum) | 600–1.000 RPM → 2.000–3.400 steps/s (full) |
| 24V (DRV8825 comum) | 1.200–2.000 RPM → 4.000–6.700 steps/s (full) |

Com microstepping, a frequência de passo aumenta (mais passos/rev) mas
o torque disponível diminui. Os valores acima valem para full step.

## 2. Tabela de Configurações Práticas

Para `STEPS_PER_MM = 80` (configuração de exemplo do projeto):

| Modo | Feedrate | Velocidade | Steps/s | Period (µs) | Seguro? |
|------|----------|-----------|---------|-------------|---------|
| Testes iniciais | 300 mm/min | 5 mm/s | 400 | 2.500 | ✓ Muito seguro |
| Operação normal | 600 mm/min | 10 mm/s | 800 | 1.250 | ✓ Seguro |
| Operação rápida | 1.500 mm/min | 25 mm/s | 2.000 | 500 | ✓ Seguro |
| Máximo recomendado | 3.000 mm/min | 50 mm/s | 4.000 | 250 | ✓ Margem 35× ISR |
| Avançado | 6.000 mm/min | 100 mm/s | 8.000 | 125 | ✓ Margem 17× ISR |

Para **STEPS_PER_MM diferentes** (outros mecanismos):

| Mecanismo | Steps/mm | Max feedrate recomendado | Steps/s máx |
|-----------|----------|--------------------------|-------------|
| Full step, fuso 2mm/rev | 100 | 2.400 mm/min | 4.000 |
| 1/8 step, fuso 8mm/rev | 200 | 1.200 mm/min | 4.000 |
| 1/16 step, fuso 8mm/rev | 400 | 600 mm/min | 4.000 |
| Full step, correia GT2 20T (40mm) | 5 | 48.000 mm/min | 4.000 |

**Conclusão:** A frequência de steps/s de ~4.000 a ~8.000 é a faixa prática segura
para NEMA17 com alimentação de 12–24V. O GPTimer e o driver não são os limitantes.

## 3. Parâmetros Recomendados para config.h

```c
// Velocidades (ajustar conforme mecanismo real)
#define DEFAULT_FEEDRATE_MM_MIN    600      // feedrate padrão ao ligar
#define MAX_FEEDRATE_MM_MIN        3000     // teto de segurança por software
#define HOMING_FEEDRATE_MM_MIN     300      // velocidade de homing (lenta)
#define HOMING_PULLOFF_MM          3.0f     // recuo após endstop

// Aceleração
#define ACCELERATION_MM_S2         500.0f   // 500 mm/s² (conservador)
#define MIN_SPEED_MM_S             0.5f     // velocidade mínima (evita stall em decel)

// Steps por mm (ajustar para o mecanismo)
#define STEPS_PER_MM_X             80.0f
#define STEPS_PER_MM_Y             80.0f

// GPTimer
#define GPTIMER_RESOLUTION_HZ      1000000  // 1MHz = resolução 1µs
#define MIN_STEP_PERIOD_US         10       // período mínimo seguro (10µs = 100kHz)
#define MAX_STEP_PERIOD_US         100000   // 100ms = velocidade mínima (10 steps/s)
```

## 4. Análise do Pior Caso de Timing (WCET Revisada)

### ISR em condições adversas

Pior caso: passo simultâneo em X e Y (dois gpio_set_level + delay por eixo):

```
Tempo total ISR pior caso:
  gpio_set X:     125ns
  delay:        2.000ns
  gpio_clear X:   125ns
  Bresenham:       25ns
  gpio_set Y:     125ns
  delay:        2.000ns
  gpio_clear Y:   125ns
  Trapezoidal:     21ns
  Re-arm timer:   167ns
  Total:       ~4.713ns ≈ 5µs

Período mínimo seguro: 2× WCET = 10µs → 100.000 steps/s máximo prático
```

Para o feedrate máximo recomendado de 3.000 mm/min = 50 mm/s:
- Pior caso: STEPS_PER_MM = 400 (1/16 step, fuso 8mm)
- Steps/s = 50 × 400 = 20.000
- Period = 50µs
- Margem: 50µs / 10µs = **5× acima do mínimo seguro** ✓

### Latência de resposta ao '?'

```
v2 — UARTTask responde diretamente:

  Byte '?' chega
  UART ISR move para buffer interno ESP-IDF:  ~1µs
  UARTTask acorda (do uart_read_bytes):       ~500µs (scheduler)
  Detecta '?', tenta state_mutex:             ~5µs (contention rara)
  Lê g_state (struct copy):                  ~100ns
  grbl_send_status(): formata + uart_write:  ~200µs (à 115200 bps, ~22 bytes)

  Total: ~700µs

  v1 (via Parser + MonitorTask): ~2-5ms

  Melhoria: 3-7× mais rápido ✓
```
