# Validação Formal — Troca de Bloco e Condições de Corrida

## Status: APROVADO — Nenhuma condição de corrida, perda de sinal ou execução dupla possível

---

## 2. Fluxo completo de troca de bloco

### Diagrama de sequência temporal

```
Tempo →

Core 1 — MotionExecutorTask (Prio 4):
  [bloqueado em xTaskNotifyWait]
  .
  .
  .

Core 1 — GPTimer ISR (última invocação do bloco N):
  │ step(eixo_dominante)                    ← último pulso STEP
  │ bresenham_error += subordinate
  │ (subordinate step se necessário)
  │ step_count++ → step_count == total_steps
  │ Atualiza current_period (DECEL, ignorado na prática)
  │ step_count >= total_steps → TRUE
  │ xTaskNotifyFromISR(executor, EVENT_BLOCK_DONE, eSetBits, &woken)
  │   → seta bit EVENT_BLOCK_DONE no TCB do Executor
  │   → woken = pdTRUE (Executor tem prio > qualquer task interrompida)
  │ NÃO chama gptimer_set_alarm_action → timer não re-arma
  │ return true
  ↓
  [hardware: timer counter continua incrementando, sem alarme pendente]
  [ISR encerrada: portYIELD_FROM_ISR ativado]
  ↓
  [contexto switch → Executor assume imediatamente]

Core 1 — MotionExecutorTask (retorna do xTaskNotifyWait):
  │ notify_val = EVENT_BLOCK_DONE
  │ notify_val & EVENT_ALARM? → FALSE  (caminho normal)
  │
  │ [ATUALIZAÇÃO DE POSIÇÃO]
  │ xSemaphoreTake(g_state_mutex, 5ms)
  │   g_state.mpos_x += (float)block.steps_x / STEPS_PER_MM_X
  │   g_state.mpos_y += (float)block.steps_y / STEPS_PER_MM_Y
  │   g_state.status = (planner_queue vazia?) IDLE : RUN
  │ xSemaphoreGive(g_state_mutex)
  │
  │ [CARREGAMENTO DO PRÓXIMO BLOCO]
  │ xTaskNotifyStateClear(NULL)          ← limpa notificação residual
  │ xQueueReceive(g_planner_queue, &block, portMAX_DELAY)
  │   → bloqueia se fila vazia; acorda quando Planner enfileira próximo bloco
  │
  │ [CONFIGURAÇÃO ANTES DO TIMER]
  │ apply_extruder_action(block.extruder_action)  ← GPIO extrusor
  │ hal_stepper_set_dir(AXIS_X, block.dir_x)      ← GPIO DIR X
  │ hal_stepper_set_dir(AXIS_Y, block.dir_y)      ← GPIO DIR Y
  │ hal_stepper_enable()                          ← GPIO EN
  │ g_state.status = STATE_RUN                    ← com state_mutex
  │
  │ [REINICIALIZAÇÃO DO TIMER]
  │ step_generator_start_block(&block):
  │   gptimer_stop(g_gptimer)          ← para o contador (ainda rodando)
  │   gptimer_set_raw_count(g_gptimer, 0)  ← RESET DO CONTADOR PARA ZERO ✓
  │   portENTER_CRITICAL(&s_isr_mux)
  │     g_isr_ctx = {.block=*block, .step_count=0,
  │                  .current_period=initial_period_us,
  │                  .phase=ACCEL,
  │                  .bresenham_error=block.bresenham_error}
  │   portEXIT_CRITICAL(&s_isr_mux)
  │   gptimer_set_alarm_action(alarm_count = initial_period_us)
  │   gptimer_start(g_gptimer)
  │
  │ [AGUARDA PRÓXIMO BLOCO]
  │ xTaskNotifyWait(0, ULONG_MAX, &notify_val, portMAX_DELAY)
  ↓
  [bloqueado — ISR do bloco N+1 assume o controle]
```

### Estados do GPTimer ao longo do fluxo

```
Estado do timer:

RUNNING  ════════════════╗    ╔══════════════════════════════════
                          ║    ║  (bloco N+1)
STOPPED                   ╚════╝
                     (fim bloco N)  (start bloco N+1)
                                     ↑
                          gptimer_set_raw_count(0) aqui
                          → contador zerado antes de start ✓
```

---

## 3. Demonstração: ausência de condição de corrida

### CR-01: ISR vs. MotionExecutorTask — acesso a `g_isr_ctx`

**Análise de estados mutuamente exclusivos:**

```
Estado A — TIMER RODANDO:
  Quem acessa g_isr_ctx:  ISR (leitura e escrita de step_count, error, period, phase)
  Quem NÃO acessa:        Executor (está bloqueado em xTaskNotifyWait)

Estado B — TIMER PARADO:
  Quem acessa g_isr_ctx:  Executor (dentro de step_generator_start_block, com spinlock)
  Quem NÃO acessa:        ISR (hardware não gera mais interrupções após gptimer_stop)
```

**Prova formal de exclusão mútua:**

Definição de invariante do sistema:
```
INV: (timer == RUNNING) XOR (executor_writing_ctx == true)
```

Demonstração:
1. O Executor entra em `step_generator_start_block()`.
2. Chama `gptimer_stop()` → `timer == STOPPED`.
3. Chama `portENTER_CRITICAL(&s_isr_mux)` → desabilita interrupções no Core 1.
4. Escreve `g_isr_ctx`.
5. `portEXIT_CRITICAL(&s_isr_mux)` → reabilita interrupções.
6. Chama `gptimer_start()` → `timer == RUNNING`.

Entre os passos 3 e 5, interrupções estão desabilitadas no Core 1. O GPTimer hardware não pode disparar interrupções enquanto `portENTER_CRITICAL` está ativo. Portanto, a ISR não pode executar durante a escrita de `g_isr_ctx`.

Após o passo 6, a ISR pode executar — mas o Executor está agora em `xTaskNotifyWait` (bloqueado), não está mais acessando `g_isr_ctx`.

**Conclusão: INV é satisfeita em todos os estados. Sem corrida. ✓**

---

### CR-02: ISR vs. `g_planner_queue`

**A ISR nunca acessa `g_planner_queue`.**

A ISR usa exclusivamente `g_isr_ctx` e `g_executor_task_handle`. Nenhuma referência a `g_planner_queue` existe em `step_generator.c` (verificação por inspeção de código).

O único consumidor de `g_planner_queue` é `xQueueReceive` no Executor, que é uma task (não ISR). FreeRTOS Queue é internamente thread-safe.

**Conclusão: sem corrida entre ISR e planner_queue. ✓**

---

### CR-03: MotionExecutorTask vs. `g_planner_queue`

`xQueueReceive` é uma operação atômica do FreeRTOS. O item é removido da fila em uma única operação protegida internamente pelo scheduler. O Executor é o único consumidor de `g_planner_queue`.

O Planner (único produtor) usa `xQueueSend` com `portMAX_DELAY`, também internamente protegido. Produção e consumo em tarefas diferentes com API FreeRTOS.

**Conclusão: FreeRTOS Queue garante thread-safety. Sem corrida. ✓**

---

### CR-04: MotionExecutorTask vs. `g_state` (atualização de posição)

A atualização `g_state.mpos_x/y` ocorre no Executor APÓS `xTaskNotifyWait` retornar, dentro de uma seção protegida por `state_mutex`. Outros leitores de `g_state` (UARTTask para '?', Parser para M114, Monitor) também acessam via `state_mutex`. FreeRTOS mutex com priority inheritance garante exclusão mútua.

**Conclusão: sem corrida em g_state. ✓**

---

### Tabela resumo de corridas

| Par | Recurso | Mecanismo de proteção | Status |
|-----|---------|----------------------|--------|
| ISR ↔ Executor | `g_isr_ctx` | Stop/Start + portENTER_CRITICAL | Sem corrida ✓ |
| ISR ↔ Planner | `g_planner_queue` | ISR não acessa | Sem corrida ✓ |
| Executor ↔ Planner | `g_planner_queue` | FreeRTOS Queue thread-safe | Sem corrida ✓ |
| Executor ↔ outros | `g_state` | `state_mutex` (priority inheritance) | Sem corrida ✓ |
| UARTTask ↔ Parser | UART TX | `uart_tx_mutex` | Sem corrida ✓ |

---

## 4. Demonstração de impossibilidade de falhas específicas

### 4.1 Perda de sinal de conclusão (`EVENT_BLOCK_DONE`)

**Mecanismo:** `xTaskNotifyFromISR` usa o campo `ulNotifiedValue` do TCB da task,
não uma fila. Este campo persiste até ser lido, independentemente do estado da task.

**Cenário de risco:** ISR dispara ANTES de `xTaskNotifyWait` ser chamado.

```
Timeline A (sequência normal):
  gptimer_start() → timer inicia
  [tempo T = initial_period_us]
  ISR dispara → xTaskNotifyFromISR → ulNotifiedValue |= EVENT_BLOCK_DONE
  xTaskNotifyWait(0, ULONG_MAX, ...) → lê ulNotifiedValue = EVENT_BLOCK_DONE
                                     → limpa bits → retorna imediatamente ✓

Timeline B (ISR "muito rápida" — período muito curto):
  gptimer_start() → timer inicia
  ISR dispara → xTaskNotifyFromISR → ulNotifiedValue |= EVENT_BLOCK_DONE (ANTES do Wait)
  xTaskNotifyWait(0, ULONG_MAX, ...) → campo já está setado
                                     → retorna imediatamente com notify_val ✓
```

Em ambas as timelines, `xTaskNotifyWait` recebe o valor. Não há janela onde
a notificação possa ser descartada, pois:
- `xTaskNotifyFromISR` com `eSetBits` nunca sobrescreve — faz OR dos bits.
- `ulBitsToClearOnEntry = 0` (primeiro parâmetro do Wait) não limpa bits existentes.
- O campo `ulNotifiedValue` é persistente até `xTaskNotifyWait` ler.

**Proteção adicional:** `xTaskNotifyStateClear(NULL)` é chamado ANTES de
`gptimer_start()`, eliminando qualquer notificação residual de ciclos anteriores.
A sequência é:
```
xTaskNotifyStateClear()   ← limpa stale (timer parado, nenhuma ISR ativa)
gptimer_start()           ← a partir daqui, ISR pode disparar e setar notificação
xTaskNotifyWait()         ← recebe notificação (presente ou futura)
```

**Conclusão: perda de sinal é impossível. ✓**

---

### 4.2 Dupla execução do mesmo bloco

**Argumento 1 — Queue remove o item:**
`xQueueReceive` remove o item da `g_planner_queue` de forma atômica. O mesmo
`motion_block_t` não pode ser recebido duas vezes. A FreeRTOS Queue garante
entrega exatamente-uma-vez para um único consumidor.

**Argumento 2 — ISR tem barreira de término:**
A ISR só executa enquanto o GPTimer gera alarmes. Após o último passo:
- A ISR detecta `step_count >= total_steps`.
- NÃO chama `gptimer_set_alarm_action` → nenhum novo alarme é agendado.
- O timer counter continua incrementando, mas sem alarme pendente, nenhuma
  callback é invocada.
- A próxima `gptimer_start()` só acontece após `gptimer_stop()` + reset +
  carga de novo contexto pelo Executor.

**Argumento 3 — Sequência estritamente linear:**
```
bloco_N recebido da fila → executado pela ISR → Executor atualiza posição
→ bloco_N+1 recebido da fila → executado pela ISR → ...
```
Cada bloco é processado na sequência FIFO da planner_queue.
O Executor não chama `step_generator_start_block` enquanto a ISR está rodando
(está bloqueado em `xTaskNotifyWait`).

**Conclusão: dupla execução é impossível. ✓**

---

### 4.3 Início de bloco sem reset do timer

**Após a correção aplicada, o código em `step_generator_start_block()` é:**

```c
gptimer_stop(g_gptimer);                    // linha 1
gptimer_set_raw_count(g_gptimer, 0);        // linha 2 — RESET OBRIGATÓRIO
portENTER_CRITICAL(&s_isr_mux);             // linha 3
  g_isr_ctx = {...};                        // escreve contexto
portEXIT_CRITICAL(&s_isr_mux);              // linha 4
gptimer_set_alarm_action(...);              // linha 5
gptimer_start(g_gptimer);                  // linha 6
```

**Prova de que a linha 2 sempre precede a linha 6:**

Isso é garantido pela estrutura sequencial do código C. `gptimer_start` (linha 6)
só é chamada após `gptimer_set_raw_count` (linha 2) dentro da mesma função.

Não existe outro caminho de código que chame `gptimer_start` em `g_gptimer`:
- `step_generator_init()` chama `gptimer_enable()` (não `gptimer_start()`).
- `step_generator_stop()` chama `gptimer_stop()` (não `gptimer_start()`).
- A ISR nunca chama `gptimer_start()`.

**Verificação de valor do contador após reset:**
`gptimer_set_raw_count(g_gptimer, 0)` escreve 0 no registrador do contador.
`gptimer_set_alarm_action` configura `alarm_count = initial_period_us`.
`gptimer_start()` começa a contar de 0.
Primeiro alarme dispara em t = initial_period_us µs. ✓

**Conclusão: início de bloco sem reset é impossível. ✓**

---

## Resumo da validação

| Garantia | Mecanismo | Status |
|----------|-----------|--------|
| Sem corrida ISR ↔ Executor | Stop/Start + portENTER_CRITICAL (hardware + spinlock) | ✓ Provada |
| Sem corrida Executor ↔ Planner | FreeRTOS Queue thread-safe | ✓ Provada |
| Sem perda de sinal de conclusão | Task Notification é persistente; xTaskNotifyStateClear antes do start | ✓ Provada |
| Sem dupla execução de bloco | Queue remove item; ISR tem barreira de término | ✓ Provada |
| Timer sempre com reset antes do start | Sequência linear obrigatória em step_generator_start_block | ✓ Provada |
| Bug original (sem reset) | `gptimer_set_raw_count(0)` adicionado e comentado | ✓ Corrigido |

**A implementação da Etapa 5 pode prosseguir sem reservas.**
