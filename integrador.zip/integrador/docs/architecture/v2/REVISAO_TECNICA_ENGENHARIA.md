# Revisão Técnica de Engenharia — Arquitetura XY G-Code ESP32
## Versão: v1 → v2  |  Status: REVISÃO COMPLETA

---

## Sumário Executivo

A arquitetura v1 é funcionalmente correta, mas contém **seis problemas estruturais** que
afetariam a qualidade da implementação:

| # | Problema | Severidade | Decisão |
|---|----------|-----------|---------|
| 1 | ExtruderTask superdimensionada para controle ON/OFF | Média | Remover — absorver na pipeline de movimento |
| 2 | Comando '?' passa pelo Parser — latência desnecessária | Alta | Mover para UARTTask como comando de tempo real |
| 3 | UART TX sem mutex — múltiplas tarefas escrevem sem sincronização | **Crítica** | Adicionar uart_tx_mutex (problema não identificado na v1) |
| 4 | block_queue com 3 slots — starvation em movimentos curtos | Alta | Aumentar para planner_queue com 16 slots |
| 5 | Limite de velocidade fixo em ~3000 steps/s sem justificativa | Baixa | Substituir por análise em três camadas |
| 6 | Timeout de 100ms no motion_queue send — protocolo ok/error incorreto | Média | Substituir por portMAX_DELAY + back-pressure explícito |

Adicionalmente, dois recursos foram incorporados:
- **M114** (consulta de posição): integrado ao GCodeParserTask
- **Sequenciamento do extrusor**: corrigido via embedding no motion_block_t

---

## Ponto 1: Remoção da ExtruderTask

### Diagnóstico

A ExtruderTask v1 executa esta lógica:
```
extruder_queue → gpio_set_level(EXTRUDER_PIN, ON/OFF) → atualiza flag no estado
```

Isso é equivalente a 4 linhas de código embrulhadas em uma tarefa inteira com stack de 1024 bytes,
contexto FreeRTOS e uma fila dedicada. O overhead é desproporcional à função.

### Problema de sequenciamento (não documentado na v1)

O problema real não é só a complexidade — é que a abordagem via fila separada **quebra o sequenciamento**:

```
Cenário de deposição:
  G1 X0 Y0          ← move para origem
  M3                 ← liga extrusor (deposita)
  G1 X100 Y0        ← move enquanto deposita
  M5                 ← desliga extrusor
  G1 X100 Y100      ← retorno rápido (sem deposição)
```

Com extruder_queue separada da motion_queue, existe uma condição de corrida:
o GCodeParser processa M3 e M5 e os enfileira em extruder_queue. Mas a ExtruderTask
consome extruder_queue independentemente do MotionExecutor. Se block_queue tiver
latência diferente de extruder_queue, M5 pode disparar antes ou durante G1 X100 Y0.

### Solução: embedding no motion_block_t

M3/M5 deixam de ser comandos independentes e passam a ser **atributos do bloco de movimento**:

```c
// motion_cmd_t (v2): extrusor como campo
typedef struct {
    motion_cmd_type_t type;   // G0, G1, G28
    float target_x;
    float target_y;
    float feedrate;
    int8_t extruder_action;   // -1 = sem mudança, 0 = desligar, 1 = ligar
} motion_cmd_t;
```

```c
// motion_block_t (v2): herdado do cmd
typedef struct {
    // ... todos os campos Bresenham e trapezoidal ...
    int8_t extruder_action;   // aplicado pelo Executor ANTES de iniciar o bloco
} motion_block_t;
```

Quando o GCodeParser encontra M3 ou M5 **sem movimento associado**:
- Cria um `motion_cmd_t` com `type = CMD_EXTRUDER_ONLY`, `target = posição atual`, `extruder_action`
- O Planner gera um bloco com `total_steps = 0` e o `extruder_action` correto
- O Executor executa o bloco (que é instantâneo), altera o GPIO, e passa ao próximo

Sequenciamento garantido: o extrusor só muda de estado quando o Executor chega àquele bloco na fila.

### Ganhos

| Recurso liberado | Quantidade |
|-----------------|-----------|
| Stack da ExtruderTask | 1024 bytes de RAM |
| Overhead TCB FreeRTOS | ~88 bytes |
| extruder_queue (5 × 4 bytes + overhead) | ~100 bytes |
| Contexto de switch evitado | 1 tarefa a menos no scheduler |
| Linhas de código eliminadas | ~80 linhas |

---

## Ponto 2: Comando '?' como Comando de Tempo Real na UARTTask

### Diagnóstico do fluxo v1

```
'?' chega na UART
  → UARTTask acumula como linha normal
  → cmd_queue (espera Parser estar livre)
  → GCodeParserTask processa
  → sinaliza status_semaphore
  → MonitorTask acorda (depende do scheduler)
  → lê state_mutex
  → formata string
  → UART TX

Latência total estimada: 2–5ms (dependente de quantas linhas estão na cmd_queue)
```

Este comportamento é incorreto para um sistema CNC. O GRBL define '?', '!' e '~' como
**comandos de tempo real** que ignoram a fila de comandos e são processados imediatamente.
A razão é simples: se a máquina estiver em ALARM, a fila pode estar bloqueada e o host
precisa saber o estado sem depender dela.

### Solução: detecção na UARTTask

```
UARTTask acumula caracteres byte a byte.
Para CADA byte recebido, antes de acumular no buffer de linha:

  if (byte == '?') {
      // Responder imediatamente — não vai para cmd_queue
      system_state_t snap;
      xSemaphoreTake(state_mutex, pdMS_TO_TICKS(5));
      snap = g_state;
      xSemaphoreGive(state_mutex);
      grbl_send_status(&snap);   // UART TX via uart_tx_mutex
      continue;  // não acumula '?' no buffer de linha
  }
  
  buffer[idx++] = byte;
  if (byte == '\n') { xQueueSend(cmd_queue, buffer, 0); }
```

### Ganhos

| Aspecto | v1 | v2 |
|---------|----|----|
| Latência '?' | 2–5ms | ~200µs |
| Tarefas envolvidas | 4 (UART, Parser, Monitor, Semáforo) | 1 (UART) |
| status_semaphore | Necessário | **Eliminado** |
| EVENT_STATUS_REQ no event_group | Necessário | **Eliminado** |
| MonitorTask | Responde ao '?' | Apenas watchdog / overflow |

### Impacto na MonitorTask

Com '?' fora do fluxo, a MonitorTask perde sua função principal.
Ela é mantida com responsabilidade redefinida:

**MonitorTask v2:**
- Verifica periodicamente overflow das filas (`uxQueueSpacesAvailable`)
- Detecta starvation: se MotionExecutor está bloqueado há mais de N segundos sem estado IDLE
- Sinaliza EVENT_ALARM se detectar inconsistência
- Permanece com prioridade 1 (mínima) — totalmente background

---

## Ponto 3: Problema Crítico Não Identificado — UART TX sem Sincronização

### Diagnóstico

Na arquitetura v1, as seguintes tarefas escrevem diretamente na UART:
- GCodeParserTask: envia `ok\n` ou `error\n`
- MonitorTask: envia `<State|MPos:x,y>`

Na v2 revisada, adicionamos:
- UARTTask: envia resposta ao `?`
- GCodeParserTask: envia resposta ao M114

A função `uart_write_bytes()` do ESP-IDF **não é thread-safe** — múltiplas chamadas
concorrentes podem intercalar bytes na saída, corrompendo o protocolo.

Exemplo de corrupção:
```
GCodeParser envia: "ok\n"
UARTTask envia:    "<Idle|MPos:0.000,0.000>\n"

Saída real possível: "ok<Idle|MPos:0.000,0.000>\n\n"
```

O host receberia uma linha corrompida e entraria em estado de erro.

### Solução: uart_tx_mutex

Criar um mutex dedicado para UART TX:

```c
SemaphoreHandle_t uart_tx_mutex;  // criado em app_main()
```

Toda escrita na UART passa por:
```c
xSemaphoreTake(uart_tx_mutex, portMAX_DELAY);
uart_write_bytes(UART_NUM, data, len);
xSemaphoreGive(uart_tx_mutex);
```

Encapsular isso em `grbl_protocol.c` para que os callers não precisem gerenciar o mutex.

---

## Ponto 4: Buffer de Planejamento — Substituição do block_queue

### Diagnóstico da v1

O `block_queue` tem capacidade 3. O problema:

```
Trajetória com 100 movimentos curtos de 1mm cada:
  - Tempo de execução de cada bloco: ~60ms (a 1000mm/min)
  - Tempo de planejamento de cada bloco: ~500µs
  
  Com 3 slots:
  - Executor executa bloco 1 (60ms)
  - Enquanto isso, Planner planeja blocos 2, 3, 4 → preenche os 3 slots
  - Executor conclui bloco 1 → consome bloco 2 → Planner planeja bloco 5
  
  → Sem starvation neste exemplo.
  
  Mas: se o host enviar linhas em burst (arquivo G-Code), e o Parser for mais rápido
  que o Executor, cmd_queue enche, UARTTask descarta comandos. Com 3 blocos no Planner,
  a "janela de look-ahead" é mínima e qualquer stall no Parser causa pausa visível.
```

O problema real aparece em movimentos MUITO curtos (< 0.1mm) em alta velocidade:
- Tempo de execução: ~5ms
- 3 blocos = 15ms de buffer
- Qualquer stall de Parser > 15ms causa pausa

### Solução: planner_queue com 16 slots

Renomear `block_queue` para `planner_queue` e expandir para 16 slots.

Não é necessário implementar um circular buffer customizado — a FreeRTOS queue com
16 itens fornece exatamente o mesmo comportamento com menos código:

```
Capacidade: 16 × sizeof(motion_block_t) = 16 × 80 bytes = 1280 bytes
Overhead FreeRTOS queue struct: ~80 bytes
Total RAM: ~1360 bytes
```

**Por que 16 e não 8?**

O GRBL usa 16 (configurável até 32). Para movimentos de 1mm a 1000mm/min:
- Tempo por bloco: 60ms
- 16 blocos = ~960ms de buffer antecipado
- Praticamente nenhum stall visível em condições normais

Para 8 blocos = 480ms → ainda bom, mas 16 é o padrão do setor por uma razão.

**Impacto no fluxo de back-pressure:**

```
cmd_queue (10) → Parser → motion_queue (8) → Planner → planner_queue (16) → Executor
                                                                              ↑
                                              back-pressure correto:
                                              Planner bloqueia em portMAX_DELAY quando
                                              planner_queue está cheia
```

### Correção do protocolo ok/error

Na v1, o GCodeParser usa `xQueueSend(motion_queue, ..., 100ms)`. Se a fila encher,
a send falha após 100ms, mas o Parser ainda envia `ok\n` (comportamento incorreto).

**Regra correta GRBL:** `ok` é enviado quando o comando é aceito na fila.
Se a fila está cheia, a tarefa deve **bloquear** até ter espaço, e só então enviar `ok`.

```c
// v2: portMAX_DELAY garante que ok só é enviado após aceitação
xQueueSend(motion_queue, &cmd, portMAX_DELAY);
grbl_send_ok();   // só chega aqui quando o item foi aceito
```

Isso torna o back-pressure explícito e correto: o host só recebe `ok` quando o
firmware realmente tem capacidade de processar mais um comando.

---

## Ponto 5: Revisão dos Limites de Desempenho

### Diagnóstico da v1

A afirmação "velocidade máxima prática (A4988 @ 1/16): ~3000 steps/s" é imprecisa e
subestimada em pelo menos uma ordem de grandeza.

### Análise em Três Camadas

#### Camada 1: Limite do Hardware (GPTimer + ESP32)

O GPTimer do ESP32 tem resolução de 1µs. A ISR leva ~1–2µs por ciclo (IRAM_ATTR).
O período mínimo seguro é **5µs** (para não sobrepor ISRs consecutivas):

```
Limite teórico GPTimer: 1.000.000 steps/s  (período = 1µs, não é seguro)
Limite prático ISR:       200.000 steps/s  (período = 5µs, margem 2.5×)
```

#### Camada 2: Limite do Driver

| Driver | Freq. máxima (datasheet) | Observação |
|--------|--------------------------|-----------|
| A4988  | 500 kHz               | Teórico, sem carga |
| DRV8825| 250 kHz               | Teórico, sem carga |

Ambos superam largamente o limite de ISR. O driver não é o gargalo.

#### Camada 3: Limite do Motor + Mecânica

O motor de passo perde torque (e portanto sincronismo) em função da velocidade de rotação.
Um NEMA17 típico começa a perder torque acima de 400–600 RPM sem driver de alta tensão.

Para configurações comuns:

| Configuração | Steps/rev | Lead/passo | Steps/mm | Velocidade razoável | Freq. de step |
|---|---|---|---|---|---|
| Full step, parafuso M8 (1.25mm) | 200 | 1.25 mm | 160 | 1500 mm/min = 25 mm/s | 4.000 steps/s |
| 1/8 step, GT2 belt 20T (40mm) | 1600 | 0.025 mm | — | — | — |
| 1/16 step, fuso 8mm (8mm/rev) | 3200 | 0.0025 mm | 400 | 600 mm/min = 10 mm/s | 4.000 steps/s |
| 1/8 step, fuso 8mm | 1600 | 0.005 mm | 200 | 1200 mm/min = 20 mm/s | 4.000 steps/s |
| Full step, fuso 2mm | 200 | 0.01 mm | 100 | 3000 mm/min = 50 mm/s | 5.000 steps/s |

O steps/mm de 80 usado como exemplo (04_fluxograma) implica um mecanismo de
~2.5mm de deslocamento por revolução com full step, ou ~5mm com 1/2 step.
Para esse valor:

| Nível | Freq. de step | Velocidade (80 steps/mm) |
|-------|--------------|--------------------------|
| Conservador (testes iniciais) | 1.000 – 5.000 steps/s | 12,5 – 62,5 mm/s |
| Realista (sistema bem ajustado) | 5.000 – 40.000 steps/s | 62,5 – 500 mm/s |
| Teórico (GPTimer, sem motor) | 200.000 steps/s | 2.500 mm/s |

**Recomendação prática para testes iniciais:**
- `HOMING_SPEED_STEPS_S = 500`  (lento, para validar endstops)
- `DEFAULT_FEEDRATE_MM_MIN = 600` (10 mm/s) → 800 steps/s com 80 steps/mm
- `MAX_FEEDRATE_MM_MIN = 3000` (50 mm/s) → 4000 steps/s com 80 steps/mm

Estes valores são conservadores e funcionarão com qualquer NEMA17 padrão.
O config.h deve expor todos esses parâmetros para ajuste sem recompilar.

---

## Ponto 6: Suporte ao Comando M114

### Análise

M114 é um comando de consulta de posição corrente. Formato de resposta:
```
X:120.000 Y:80.000
```

**Onde tratar:** No GCodeParserTask, em ordem com os demais comandos.

**Por que não na UARTTask como '?'?**

A diferença fundamental: '?' é um comando de tempo real — deve responder ao estado
*atual* da máquina, mesmo se houver movimentos na fila. Ele intencionalmente "fura"
a fila para dar feedback imediato.

M114 é um comando G-Code normal — deve responder com a posição *após todos os
comandos anteriores terem sido executados*. Se você envia:

```
G1 X100 Y50
M114
```

O M114 deve responder X:100 Y:50, não a posição intermediária durante a execução do G1.

**Portanto, M114 vai pela fila normal:**

```
GCodeParser recebe M114
  → Não cria motion_cmd_t
  → lê g_state.mpos via state_mutex (brevemente)
  → formata e envia "X:%.3f Y:%.3f\n" via uart_tx_mutex
  → envia ok\n
```

**Mas há um problema de sequenciamento:** se M114 for pela cmd_queue e o Parser
responder imediatamente, a posição reportada será a posição no momento em que
o Planner processou os comandos anteriores — não quando foram *executados*.

A solução correta para sequenciamento exato seria: o Planner emite um bloco especial
"M114_QUERY" para a planner_queue, o Executor o processa (depois de todos os blocos
anteriores), e então responde. Mas isso complica a arquitetura.

**Decisão para este projeto:** reportar a posição do *planning state* (posição após
o que o Planner sabe que vai executar) é suficiente para fins práticos e educacionais.
O impacto é documentado como limitação conhecida.

**Impacto na arquitetura:** Nenhuma nova tarefa, fila ou semáforo.
Apenas uma nova branch no switch/case do GCodeParser.

---

## Ponto 7: Revisão do Uso de Dual-Core

### Diagnóstico da v1

A v1 usa `xTaskCreatePinnedToCore()` para todas as tarefas com distribuição explícita:
- Core 0: todas as tarefas
- Core 1: MotionExecutorTask (isolada)

### Análise

**Argumento favor dual-core:**
- Core 1 dedicado ao Executor significa que o GPTimer ISR nunca compete com Parser ou Planner
- No ESP-IDF, o GPTimer ISR corre no mesmo core que criou/habilitou o timer. Sem pinning,
  o Executor pode migrar entre cores entre chamadas e o timer segue — comportamento não determinístico

**Argumento contra (para v1):**
- Força o uso de `xTaskCreatePinnedToCore()` em toda parte — código ligeiramente mais verboso
- O benefício real só é perceptível em step rates > 50.000 steps/s, fora do escopo deste projeto
- Torna debugging ligeiramente mais complexo (precisa saber em qual core está)

### Decisão Revisada

**v2 (implementação inicial):** Manter pinning **apenas para MotionExecutorTask no Core 1**.
Todas as outras tarefas usam `tskNO_AFFINITY` (equivalente a `xTaskCreate`).

Isso é o equilíbrio correto:
- O Executor (+ ISR do GPTimer) fica no Core 1 — garantia de tempo real
- Demais tarefas: o SMP scheduler do FreeRTOS decide — menos configuração manual

```c
// app_main() v2:
xTaskCreate(uart_task,     "uart",    2048, NULL, 2, NULL);          // qualquer core
xTaskCreate(parser_task,   "parser",  4096, NULL, 3, NULL);          // qualquer core
xTaskCreate(planner_task,  "planner", 4096, NULL, 3, NULL);          // qualquer core
xTaskCreate(monitor_task,  "monitor", 2048, NULL, 1, NULL);          // qualquer core
xTaskCreatePinnedToCore(executor_task, "executor", 4096, NULL, 4, NULL, 1);  // Core 1 fixo
```

**Nota sobre o GPTimer:** O timer deve ser criado e habilitado dentro do MotionExecutorTask
(que corre no Core 1), não no app_main. Isso garante que a ISR corra no Core 1.

---

## Ponto 8: Auditoria Final — Condições de Corrida, Deadlocks e Gargalos

### 8.1 Condições de Corrida Identificadas

#### CR-01: g_isr_ctx sem proteção explícita [RISCO MÉDIO]

**Situação:** O MotionExecutorTask escreve em `g_isr_ctx` (contexto global da ISR)
antes de armar o GPTimer. A ISR lê `g_isr_ctx` a cada callback.

**Risco:** Se o Executor escrever em `g_isr_ctx` enquanto o timer ainda está
disparando de um bloco anterior, a ISR lerá dados inconsistentes.

**Mitigação:** O Executor **para o GPTimer antes de escrever** em g_isr_ctx:
```
gptimer_stop() → portENTER_CRITICAL() → escreve g_isr_ctx → portEXIT_CRITICAL() → gptimer_start()
```
Isso garante exclusão mútua sem overhead de semáforo.

#### CR-02: state_mutex com escritores múltiplos [RISCO BAIXO — RESOLVIDO]

**Escritores de g_state:**
- MotionExecutorTask: atualiza mpos_x, mpos_y, status
- GCodeParserTask: atualiza position_absolute (G90/G91), feedrate

**Leitores:**
- UARTTask: lê mpos e status para resposta ao '?'
- GCodeParserTask: lê mpos para resolver G91 → coordenadas absolutas
- MonitorTask: lê tudo periodicamente

**Mitigação:** Todos acessos via `xSemaphoreTake(state_mutex, 5ms)`. FreeRTOS mutex
implementa priority inheritance — o Executor (Prio 4) promove temporariamente o Parser
(Prio 3) se o Parser estiver segurando o mutex quando o Executor precisar. ✓

#### CR-03: UART TX sem sincronização [RISCO CRÍTICO — IDENTIFICADO NO PONTO 3]

Conforme descrito no Ponto 3. Resolvido via `uart_tx_mutex`.

#### CR-04: planner_queue — escrita pelo Planner, leitura pelo Executor [SEM RISCO]

Mecanismo nativo do FreeRTOS Queue — thread-safe por design. ✓

### 8.2 Análise de Deadlock

Um deadlock exige que dois agentes possuam recursos que o outro precisa.

**Verificação de lock ordering (ordem de aquisição de locks):**

| Tarefa | Locks que pode segurar simultaneamente |
|--------|----------------------------------------|
| UARTTask | uart_tx_mutex |
| GCodeParserTask | state_mutex (brevemente) → uart_tx_mutex (para ok/error) |
| MotionPlannerTask | Nenhum (apenas operações de fila) |
| MotionExecutorTask | state_mutex (brevemente) |
| MonitorTask | state_mutex (brevemente) |

**Problema potencial:** GCodeParserTask pode:
1. Adquirir `state_mutex` para ler mpos (G91 → absoluto)
2. Depois adquirir `uart_tx_mutex` para enviar ok

MotionExecutorTask pode:
1. Adquirir `state_mutex` para atualizar posição (após bloco)
2. Nunca adquire uart_tx_mutex

**Não há lock reverso**: nenhuma tarefa adquire uart_tx_mutex e depois tenta adquirir state_mutex.
**Conclusão: sem deadlock possível.** ✓

### 8.3 Gargalos de Desempenho

| Gargalo | Localização | Severidade | Mitigação |
|---------|------------|-----------|-----------|
| Cópia de 96 bytes por item na cmd_queue | xQueueSend/Receive | Baixa | Aceitável para 10 itens; alternativa seria queue de ponteiros |
| Cálculo trapezoidal com float | MotionPlannerTask | Baixa | ESP32 tem FPU, ~10µs por bloco. 16-slot buffer absorve |
| gpio_matrix latência para STEP pulse | ISR | Baixa | ~125ns extra vs. RTC_IO. Aceitável para >5µs period |
| UART TX com mutex | uart_tx_mutex | Muito Baixa | ok\n = 3 bytes = 260µs @ 115200. Mutex contention desprezível |

### 8.4 Complexidade Desnecessária — Identificada e Removida

| Item removido | Economia |
|---------------|---------|
| ExtruderTask | 1 tarefa, 1 fila, ~1.2KB RAM |
| status_semaphore | 1 primitiva FreeRTOS |
| EVENT_STATUS_REQ no event_group | 1 bit do event group |
| timeout 100ms no motion_queue send | Comportamento incorreto substituído por portMAX_DELAY |
| MonitorTask respondendo '?' | Responsabilidade focada em watchdog |

---

## Resumo das Mudanças v1 → v2

### Tarefas

| Tarefa | v1 | v2 |
|--------|----|----|
| UARTTask | Acumula linhas | Acumula linhas + responde '?' diretamente |
| GCodeParserTask | Trata '?', M3/M5, G-codes | Trata M3/M5 (embedded), M114, G-codes |
| MotionPlannerTask | Sem mudança | Usa portMAX_DELAY; considera extruder_action |
| MotionExecutorTask | Core 1 | Core 1 (mantido) + aplica extruder_action |
| **ExtruderTask** | **Existe (Prio 2)** | **Removida** |
| MonitorTask | Responde '?', watchdog | Apenas watchdog / overflow |

### Primitivas FreeRTOS

| Primitiva | v1 | v2 |
|-----------|----|----|
| cmd_queue | 10 × 128 bytes | 10 × 96 bytes |
| motion_queue | 5 items | 8 items |
| **extruder_queue** | **5 items** | **Removida** |
| block_queue | 3 items | Substituída por planner_queue |
| **planner_queue** | Não existe | **16 items × 80 bytes** |
| state_mutex | Existe | Existe |
| **uart_tx_mutex** | **Não existe** | **Adicionado (crítico)** |
| **status_semaphore** | Existe | **Removido** |
| motion_event_group | 4 bits | 3 bits (STATUS_REQ removido) |

### Consumo de RAM estimado (filas)

| Componente | v1 | v2 | Δ |
|-----------|-----|-----|---|
| cmd_queue | 1.280 bytes | 960 bytes | -320 |
| motion_queue | 160 bytes | 256 bytes | +96 |
| extruder_queue | ~100 bytes | 0 | -100 |
| block/planner_queue | ~272 bytes | ~1.360 bytes | +1.088 |
| Stacks (ExtruderTask removida) | — | -1.024 bytes | -1.024 |
| **Total** | **~1.812** | **~2.576** | **+764** |

O aumento de ~764 bytes é justificado: a planner_queue com 16 slots elimina starvation
e é um investimento correto no desempenho de fluência de movimento.
O ESP32 tem 520KB de SRAM — este delta é irrelevante.

---

## Veredicto Final

A arquitetura v2 está **aprovada para implementação** com as seguintes garantias:

- ✓ Sem deadlocks possíveis (lock ordering verificado)
- ✓ Condições de corrida identificadas e mitigadas
- ✓ UART TX sincronizado (problema crítico corrigido)
- ✓ Sequenciamento extrusor correto (embedding no bloco)
- ✓ Protocolo ok/error correto (back-pressure via portMAX_DELAY)
- ✓ Fluidez de movimento com 16 blocos de lookahead
- ✓ Limites de velocidade documentados com base em hardware real
- ✓ M114 integrado sem complexidade adicional
- ✓ '?' com latência < 500µs (tempo real)

**Próximo passo: Etapa 2 — Implementação dos módulos base.**
