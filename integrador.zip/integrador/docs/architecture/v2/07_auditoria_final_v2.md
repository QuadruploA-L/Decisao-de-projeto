# Auditoria Final — Arquitetura v2

## 1. Diagrama de Estado da Máquina

```
                    ┌──────────────────────────────────────────────────┐
                    │               ESTADOS DA MÁQUINA                 │
                    │                                                  │
                    │          ┌─────────┐                            │
                    │    G28 ──►  HOMING │── concluído ──►            │
                    │          └────┬────┘                            │
                    │               │ EVENT_HOMING_DONE               │
                    │               ▼                                  │
         ligou ────────────────► IDLE ◄─── planner_queue vazia ───   │
                    │              │                                   │
                    │     G0/G1 ───┘ (bloco enfileirado)              │
                    │              │                                   │
                    │              ▼                                   │
                    │            RUN ──── endstop inesperado ──►      │
                    │              │                                   │
                    │     planner  │ fila vazia                       │
                    │     vazia    ▼                                   │
                    │           IDLE                                   │
                    │                                                  │
                    │  qualquer estado ──► ALARM ──── reset ──► IDLE  │
                    └──────────────────────────────────────────────────┘
```

## 2. Condições de Corrida — Status Final

| ID | Descrição | Status v2 | Mitigação |
|----|-----------|-----------|-----------|
| CR-01 | g_isr_ctx escrito enquanto ISR ativa | ✓ Resolvido | gptimer_stop antes de escrever |
| CR-02 | g_state com múltiplos escritores/leitores | ✓ Resolvido | state_mutex (priority inheritance) |
| CR-03 | UART TX sem sincronização | ✓ Resolvido | uart_tx_mutex em grbl_protocol.c |
| CR-04 | planner_queue escrita/leitura concurrent | ✓ Sem risco | FreeRTOS Queue é thread-safe |
| CR-05 | plan_x/y diverge de g_state.mpos | ✓ Intencional | Documentado — comportamento correto |

## 3. Análise de Deadlock — Status Final

**Grafos de dependência de locks (ordem de aquisição):**

```
Tarefa              Sequência de locks possível
─────────────────────────────────────────────────────────────
UARTTask            state_mutex → uart_tx_mutex (em resposta a '?')
GCodeParserTask     state_mutex (breve) → uart_tx_mutex (ok/M114)
                    OU motion_queue (portMAX_DELAY) → uart_tx_mutex
MotionExecutorTask  state_mutex (breve, sempre após liberar outros)
MonitorTask         state_mutex (breve, apenas leitura)
MotionPlannerTask   Nenhum mutex — apenas operações de fila
```

**Verificação circular:**
- Existe alguma tarefa que adquire uart_tx_mutex e depois state_mutex? **Não.**
- Existe alguma tarefa que adquire state_mutex e depois tenta motion_queue + state_mutex? **Não.**
- Existe alguma tarefa que espera duas FreeRTOS queues simultaneamente? **Não.**

**Conclusão: sem possibilidade de deadlock.** ✓

## 4. Análise de Priority Inversion — Status Final

FreeRTOS mutexes criados com `xSemaphoreCreateMutex()` implementam
**priority inheritance** automaticamente.

Cenário de inversion resolvido pelo FreeRTOS:
```
MotionExecutorTask (Prio 4) tenta adquirir state_mutex
GCodeParserTask (Prio 3) está segurando state_mutex

FreeRTOS:
  → Promove temporariamente GCodeParserTask para Prio 4
  → GCodeParserTask completa sua seção crítica mais rapidamente
  → Libera state_mutex
  → MotionExecutorTask adquire, continua
  → GCodeParserTask volta a Prio 3
```

Não é necessário nenhum código adicional — o mecanismo é automático. ✓

## 5. Pontos de Atenção para a Implementação (v2)

### Regras absolutas (devem virar comentários de asserção no código)

1. **IRAM_ATTR obrigatório**: `gptimer_isr_callback()` e todas as funções
   que ele chama: `hal_stepper_step()`, `esp_rom_delay_us()`.
   Falha silenciosa: ISR carregada da flash = latência imprevisível.

2. **Proibido em ISR**: `state_mutex`, `uart_tx_mutex`, `xQueueSend/Receive`,
   qualquer função que possa bloquear. Usar apenas versões `FromISR`.

3. **GPTimer criado no Executor**: O GPTimer deve ser criado e habilitado
   dentro de `task_motion_executor.c` (não no `app_main`), para garantir
   que a ISR seja registrada no Core 1.

4. **gptimer_stop antes de escrever g_isr_ctx**: Nunca atualizar g_isr_ctx
   com o timer rodando. Sequência obrigatória: stop → seção crítica → escreve → start.

5. **plan_x/y vs g_state.mpos**: O Planner atualiza `plan_x/y`. O Executor
   atualiza `g_state.mpos`. São variáveis diferentes com propósitos diferentes.
   Nunca misturar.

6. **uart_tx_mutex via grbl_protocol.c**: Nenhuma tarefa deve chamar
   `uart_write_bytes()` diretamente. Toda saída serial passa pelas funções
   de `grbl_protocol.c` que já gerenciam o mutex.

7. **Homing reseta plan_x/y**: Após G28, o Executor atualiza `g_state.mpos = 0`
   e também deve notificar o Planner para resetar `plan_x/y = 0`. Mecanismo:
   flag protegida por mutex ou campo dedicado em g_state.

### Sequência de inicialização obrigatória

```
1. hal_extruder_init()         ← extrusor desligado (nível inicial seguro)
2. hal_endstop_init()          ← GPIO com pull-up
3. hal_stepper_init()          ← driver desabilitado (EN = HIGH)
4. uart_driver_install()       ← UART configurado antes das tasks
5. Criar TODOS os objetos FreeRTOS (filas, mutexes, event group)
6. Inicializar g_state = {IDLE, 0, 0, DEFAULT_FEEDRATE, false, true}
7. Criar tasks (nunca antes dos passos 1-6)
8. vTaskDelete(NULL)
```

## 6. Avaliação Final da Arquitetura v2

### Robustez
| Critério | Nota | Observação |
|----------|------|------------|
| Sincronização de concorrência | A | Todos os acessos compartilhados protegidos |
| Sequenciamento de comandos | A | Filas garantem ordem; extrusor embedded no bloco |
| Tratamento de alarme | B+ | EVENT_ALARM existe; recovery completo não implementado |
| Limites de segurança | B | Max feedrate por software; sem soft limits de posição |

### Simplicidade
| Critério | Nota | Observação |
|----------|------|------------|
| Número de tarefas | A | 5 tarefas — mínimo funcional para demonstrar FreeRTOS |
| Primitivas FreeRTOS | A | 1 cmd_q, 1 motion_q, 1 planner_q, 2 mutex, 1 event_group |
| Linhas de código estimadas | A | ~1.500–2.000 linhas total (excl. Doxygen) |

### Uso correto do FreeRTOS
| Primitiva | Uso correto? | Observação |
|-----------|-------------|------------|
| Queue | ✓ | Back-pressure via portMAX_DELAY no produtor |
| Mutex | ✓ | Priority inheritance ativo automaticamente |
| Event Group | ✓ | Multi-bit para eventos ortogonais (DONE vs ALARM) |
| TaskNotify | ✓ | ISR→Task: mais leve que semáforo, carrega 32 bits |
| vTaskDelay | ✓ | Apenas no MonitorTask (background, não crítico) |
| Sem polling ativo | ✓ | Todas as tasks bloqueiam em primitiva FreeRTOS |

### Facilidade de Implementação
| Módulo | Complexidade | Dependências |
|--------|-------------|-------------|
| HAL (stepper, endstop, extruder) | Baixa | Apenas ESP-IDF GPIO |
| system_state.c | Baixa | Apenas FreeRTOS |
| grbl_protocol.c | Baixa | uart_tx_mutex |
| task_uart.c | Baixa | cmd_queue, state_mutex, uart_tx_mutex |
| gcode_parser.c | Média | Tokenização de string |
| task_gcode_parser.c | Média | gcode_parser + filas |
| motion_planner.c | Alta | Bresenham + trapezoidal |
| step_generator.c | Alta | IRAM_ATTR, GPTimer API, ISR constraints |
| task_motion_executor.c | Média-Alta | GPTimer + homing + g_isr_ctx |

### Qualidade para Apresentação Acadêmica
| Critério | Avaliação |
|----------|-----------|
| Demonstra FreeRTOS claramente | ✓ 5 tarefas com papéis distintos e comunicação explícita |
| Demonstra sistemas em tempo real | ✓ ISR com GPTimer, sem polling |
| Demonstra HAL | ✓ Troca de driver por #define sem alterar lógica |
| Demonstra pipeline de processamento | ✓ UART → Parser → Planner → Executor → ISR |
| Demonstra concorrência e sincronização | ✓ 3 tipos de primitiva, problema de race condition resolvido |
| Código documentável com Doxygen | ✓ Interfaces bem definidas em .h separados |
| Comparável com sistemas reais (GRBL) | ✓ Mesmo conceito de planner buffer, protocolo serial compatível |

## 7. Decisão Final

**A arquitetura v2 está aprovada para implementação.**

Não há problemas abertos que justifiquem mais revisão antes de gerar código.
Todos os riscos identificados têm mitigação documentada.
A complexidade está calibrada para um projeto acadêmico de demonstração — nem
trivial demais para não demonstrar os conceitos, nem complexa a ponto de ser
inimplementável no escopo do trabalho.

```
APROVADO — Iniciar Etapa 2: Implementação dos módulos base.
```
