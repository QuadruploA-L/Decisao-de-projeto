# Diagrama de Filas e Primitivas FreeRTOS — v2

## 1. Mapa Completo de IPC

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                    PRIMITIVAS FREERTOS v2 — FLUXO COMPLETO                  │
│                                                                             │
│  ╔══════════╗──────'?'─────────────────────────────────────────────────    │
│  ║ UARTTask ║  (detecção direta, bypassa todas as filas)                    │
│  ╚═════╤════╝──────────────────────────────────────────────────────────    │
│        │ cmd_queue (10 × 96 bytes)                                          │
│        ▼                                                                    │
│  ╔═════════════════╗                                                        │
│  ║ GCodeParserTask ║── M114 / ok / error ──► uart_tx_mutex ──► UART TX     │
│  ╚═══════╤═════════╝                                                        │
│          │ motion_queue (8 × motion_cmd_t)                                  │
│          ▼                                                                  │
│  ╔═════════════════════╗                                                    │
│  ║  MotionPlannerTask  ║                                                    │
│  ╚═══════╤═════════════╝                                                    │
│          │ planner_queue (16 × motion_block_t)  ← NOVO — 16 slots          │
│          ▼                                                                  │
│  ╔═════════════════════╗                                                    │
│  ║ MotionExecutorTask  ║──── xTaskNotifyFromISR ──── [GPTimer ISR]          │
│  ╚═════════════════════╝                                                    │
│          │ state_mutex (leitura/escrita de g_state)                         │
│          ├─────────────────────────────────────────────────────────────    │
│          │                                                                  │
│  ╔═══════╧═══════╗                                                          │
│  ║  MonitorTask  ║ (lê filas via uxQueueSpacesAvailable — não consome)      │
│  ╚═══════════════╝                                                          │
│                                                                             │
│  ─────────────────────────────────────────────────────────────────────     │
│  MUTEXES                                                                    │
│                                                                             │
│  state_mutex     ──► protege system_state_t g_state                        │
│                      escritores: MotionExecutor, GCodeParser (G90/G91)     │
│                      leitores: UARTTask ('?'), GCodeParser (M114/G91)      │
│                                                                             │
│  uart_tx_mutex   ──► protege uart_write_bytes() — NOVO (crítico)           │
│                      usuários: UARTTask ('?'), GCodeParser (ok/error/M114) │
│                                                                             │
│  ─────────────────────────────────────────────────────────────────────     │
│  EVENT GROUP: motion_event_group (3 bits ativos)                            │
│                                                                             │
│  BIT0: EVENT_HOMING_DONE  ← MotionExecutor ao concluir G28                 │
│  BIT1: EVENT_BLOCK_DONE   ← GPTimer ISR ao concluir bloco                  │
│  BIT2: EVENT_ALARM        ← MonitorTask ou Executor em erro                │
│  (BIT3 removido: EVENT_STATUS_REQ não existe mais)                          │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

## 2. Especificação Detalhada das Filas

### cmd_queue
| Atributo | v1 | v2 | Justificativa da mudança |
|----------|----|----|--------------------------|
| Tipo de item | `char[128]` | `char[96]` | G-Code real: max ~80 chars. 96 bytes com margem |
| Capacidade | 10 itens | 10 itens | Mantido — buffer razoável para burst do host |
| RAM total | ~1.280 bytes | ~960 bytes | -25% sem impacto funcional |
| Timeout produtor | `0` | `0` | Descarte intencional — host respeita ok/error |
| Timeout consumidor | `portMAX_DELAY` | `portMAX_DELAY` | Parser aguarda |

**Nota:** 96 bytes cobre qualquer linha G-Code válida, incluindo comentários inline.
A linha mais longa possível neste sistema: `G1 X-999.999 Y-999.999 F99999.9 ; comentario\n`
= 52 caracteres. Margem de 44 bytes.

### motion_queue
| Atributo | v1 | v2 | Justificativa da mudança |
|----------|----|----|--------------------------|
| Tipo de item | `motion_cmd_t` (~36 bytes) | `motion_cmd_t` (~40 bytes) | +4 bytes para `extruder_action` |
| Capacidade | 5 itens | 8 itens | Maior buffer entre Parser e Planner — menos stalls |
| RAM total | ~180 bytes | ~320 bytes | +140 bytes — justificado |
| Timeout produtor | `100ms` ❌ | `portMAX_DELAY` ✓ | Back-pressure correto; ok só enviado após aceite |
| Timeout consumidor | `portMAX_DELAY` | `portMAX_DELAY` | Mantido |

**Por que portMAX_DELAY no produtor?**

Com timeout de 100ms na v1, se a fila estivesse cheia por 101ms, o Parser:
1. Tentava enviar por 100ms
2. Desistia
3. Enviava `ok\n` mesmo assim (bug! — o comando foi descartado)

Com `portMAX_DELAY`, o Parser bloqueia até haver espaço. O host não recebe `ok`
até o firmware estar pronto. Isso é exatamente o protocolo GRBL.

### planner_queue (substitui block_queue)
| Atributo | v1 (block_queue) | v2 (planner_queue) | Justificativa |
|----------|------------------|--------------------|---------------|
| Tipo de item | `motion_block_t` (~64 bytes) | `motion_block_t` (~80 bytes) | +16 bytes para extruder_action e padding |
| Capacidade | 3 itens | **16 itens** | Lookahead adequado; anti-starvation |
| RAM total | ~272 bytes | ~1.360 bytes | +1.088 bytes — investimento correto |
| Timeout produtor | `portMAX_DELAY` | `portMAX_DELAY` | Mantido — Planner bloqueia se Executor lento |
| Timeout consumidor | `portMAX_DELAY` | `portMAX_DELAY` | Mantido |

**Análise de starvation com 16 slots:**

Cenário típico de deposição (movimentos curtos de 1–5mm):
```
Tempo de execução de 1mm a 600mm/min: 100ms
Tempo de planejamento de 1 bloco: ~500µs

Buffer = 16 blocos × 100ms = 1.600ms de lookahead

Para starvation acontecer: Parser precisaria parar por > 1.6 segundos
→ Praticamente impossível em condições normais de operação
```

**Mapeamento conceitual Planner Buffer ↔ GRBL:**

| GRBL | Este projeto |
|------|-------------|
| `block_buffer[]` (array circular) | `planner_queue` (FreeRTOS queue) |
| `block_buffer_head` | índice de escrita da queue (interno ao FreeRTOS) |
| `block_buffer_tail` | índice de leitura da queue (interno ao FreeRTOS) |
| `BLOCK_BUFFER_SIZE = 16` | capacidade = 16 |
| `plan_get_current_block()` | `xQueuePeek(planner_queue, ...)` |

A FreeRTOS queue implementa exatamente o buffer circular do GRBL, mas com
thread-safety nativa, sem precisar implementar manualmente os índices.

## 3. Especificação dos Mutexes

### state_mutex
| Atributo | Valor |
|----------|-------|
| Tipo | `xSemaphoreCreateMutex()` (com priority inheritance) |
| Protege | `system_state_t g_state` |
| Escritores | MotionExecutorTask (mpos, status), GCodeParserTask (mode, feedrate) |
| Leitores | UARTTask ('?'), GCodeParserTask (M114, G91), MonitorTask |
| Timeout máximo | 5ms em todos os acessos |
| Uso em ISR | **Proibido** — ISR usa g_isr_ctx isoladamente |

### uart_tx_mutex  ← NOVO
| Atributo | Valor |
|----------|-------|
| Tipo | `xSemaphoreCreateMutex()` |
| Protege | `uart_write_bytes()` — saída serial |
| Usuários | UARTTask ('?'), GCodeParserTask (ok/error/M114) |
| Timeout | `portMAX_DELAY` — nunca descartar resposta |
| Uso em ISR | **Proibido** — nenhuma resposta serial dentro de ISR |

## 4. Especificação do Event Group

### motion_event_group (3 bits)
```
BIT0: EVENT_HOMING_DONE
  Sinalizado por: MotionExecutorTask ao completar sequência G28
  Aguardado por:  GCodeParserTask (para sincronizar resposta 'ok' do G28)

BIT1: EVENT_BLOCK_DONE
  Sinalizado por: GPTimer ISR via xEventGroupSetBitsFromISR()
                  OU via xTaskNotifyFromISR diretamente ao Executor
  Aguardado por:  MotionExecutorTask

BIT2: EVENT_ALARM
  Sinalizado por: MotionExecutorTask (endstop inesperado), MonitorTask
  Aguardado por:  MotionExecutorTask (sai do wait), GCodeParserTask (monitora)
```

**Nota sobre EVENT_BLOCK_DONE:** Preferir `xTaskNotifyFromISR` (comunicação direta
ISR → Executor) ao invés de event group. O event group requer `xHigherPriorityTaskWoken`
e é ligeiramente mais pesado. Usar event group apenas para HOMING_DONE e ALARM
(comunicação entre tasks, não ISR→task).

## 5. Diagrama de Contenção

```
Qual tarefa pode bloquear qual?

UARTTask (Prio 2)
  ├── Bloqueia em uart_read_bytes (hardware, não FreeRTOS)
  ├── Bloqueia em state_mutex (leitura de 5ms max)
  └── Bloqueia em uart_tx_mutex (escrita de ok)

GCodeParserTask (Prio 3)
  ├── Bloqueia em cmd_queue (portMAX_DELAY — aguarda UARTTask)
  ├── Bloqueia em motion_queue send (portMAX_DELAY — aguarda Planner)
  ├── Bloqueia em state_mutex (G90/G91/M114)
  └── Bloqueia em uart_tx_mutex (ok/error/M114)

MotionPlannerTask (Prio 3)
  ├── Bloqueia em motion_queue recv (portMAX_DELAY — aguarda Parser)
  └── Bloqueia em planner_queue send (portMAX_DELAY — aguarda Executor)

MotionExecutorTask (Prio 4 — Core 1)
  ├── Bloqueia em planner_queue recv (portMAX_DELAY)
  ├── Bloqueia em xTaskNotifyWait (portMAX_DELAY — aguarda ISR)
  └── Bloqueia em state_mutex (atualização de posição — 5ms max)

MonitorTask (Prio 1)
  ├── Bloqueia em vTaskDelay(1000ms)
  └── Bloqueia em state_mutex (leitura — 5ms max)

→ Nenhum ciclo de dependência = sem deadlock possível ✓
```

## 6. Fluxo de Back-Pressure (v2 corrigido)

```
Host envia comandos rapidamente (arquivo G-Code longo):

  UART → cmd_queue (10 slots)
              ↓ GCodeParser (rápido — ~100µs/linha)
         motion_queue (8 slots)
              ↓ Planner (médio — ~500µs/bloco)
         planner_queue (16 slots)
              ↓ Executor (lento — tempo real, governa tudo)
           GPTimer ISR

Se Executor está consumindo a 600mm/min (10mm/s):
  Cada bloco de 1mm leva 100ms
  16 blocos = 1.6s de buffer

  O back-pressure natural:
  planner_queue cheia → Planner bloqueia (portMAX_DELAY)
  motion_queue cresce → Parser bloqueia (portMAX_DELAY)
  cmd_queue cresce → UARTTask não pode enfileirar (timeout 0: descarta)
  Host não recebe 'ok' → Para de enviar

  → Sistema auto-regula. Host responsável por não enviar sem 'ok'.
```
