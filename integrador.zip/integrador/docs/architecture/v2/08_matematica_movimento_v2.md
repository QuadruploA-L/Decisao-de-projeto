# Matemática do Planejador de Movimento — v2 (Implementada)

## 1. Algoritmo de Bresenham — Prova e Exemplo

### Formulação completa

Dado um movimento de posição atual → posição alvo, ambas em passos inteiros:

```
delta_x = target_steps_x - pos_steps_x    (com sinal)
delta_y = target_steps_y - pos_steps_y    (com sinal)

dx = |delta_x|    dir_x = sign(delta_x)
dy = |delta_y|    dir_y = sign(delta_y)

dominant    = max(dx, dy)   → eixo com mais passos
subordinate = min(dx, dy)   → eixo com menos passos
dominant_is_x = (dx >= dy)

bresenham_error_init = dominant / 2   (divisão inteira)
```

### Execução na ISR (a cada ciclo)

```
1. Avança eixo dominante: hal_stepper_step(dominant_axis)

2. Acumula erro: error += subordinate

3. Se error >= dominant:
       Avança eixo subordinado: hal_stepper_step(subordinate_axis)
       error -= dominant
```

### Prova de correção

A reta real entre dois pontos tem inclinação `m = subordinate / dominant`.
O algoritmo mantém um acumulador que representa o erro em relação à reta real.
A invariante é: |error| < dominant a qualquer momento.

Após `k` passos do dominante, sem nenhum passo do subordinado:
- Erro acumulado: k × subordinate
- Quando este erro atinge `dominant`, a reta real teria avançado 1 unidade no subordinado
- O algoritmo então avança o subordinado e subtrai `dominant` do acumulador

O erro de aproximação em relação à reta real está sempre dentro de ±0.5 passo
(com o erro inicial em `dominant/2`), que é a melhor aproximação possível
com aritmética inteira.

### Exemplo verificado: movimento (0,0) → (5,3) = diagonal 5×3 passos

```
dx=5, dy=3 → dominante=X, subordinado=Y
error_init = 5/2 = 2

Ciclo | Step X | error + 3 | error ≥ 5? | Step Y | error final
  1   |   ✓    |   2+3=5   |     ✓      |   ✓    |   5-5=0
  2   |   ✓    |   0+3=3   |     ✗      |        |   3
  3   |   ✓    |   3+3=6   |     ✓      |   ✓    |   6-5=1
  4   |   ✓    |   1+3=4   |     ✗      |        |   4
  5   |   ✓    |   4+3=7   |     ✓      |   ✓    |   7-5=2

Resultado: 5 passos em X, 3 passos em Y ✓
Posições geradas: (1,1), (2,1), (3,2), (4,2), (5,3) — linha traçada corretamente.
```

---

## 2. Perfil Trapezoidal — Desenvolvimento Matemático

### 2.1 Conversão feedrate → step rate com correção diagonal

Para movimentos diagonais, o feedrate é expresso ao longo do vetor de movimento,
não ao longo de um único eixo. A distância real percorrida é maior que a projeção:

```
d [mm] = sqrt( (dx / STEPS_PER_MM_X)² + (dy / STEPS_PER_MM_Y)² )

step_rate [steps/s] = v_max [mm/s] × (total_steps / d)
```

**Por que usar total_steps/d e não STEPS_PER_MM diretamente?**

Para um movimento puramente em X: `d = dx/STEPS_MM_X` e `total_steps = dx`
→ `step_rate = v_max × dx / (dx/STEPS_MM_X) = v_max × STEPS_MM_X` ✓

Para movimento diagonal 45° com STEPS_MM_X = STEPS_MM_Y = 80:
- `dx = dy = 80` (1mm em cada eixo)
- `d = sqrt(1² + 1²) = 1.414 mm`
- `total_steps = 80`
- `step_rate = v_max × 80 / 1.414 = v_max × 56.57 steps/mm`

Se usássemos simplesmente `v_max × STEPS_MM_X = v_max × 80`, o motor X correria
√2 vezes mais rápido que o necessário para manter o feedrate correto no vetor.

### 2.2 Aceleração projetada

Da mesma forma, a aceleração em mm/s² é convertida para o espaço de passos:

```
a_steps [steps/s²] = ACCELERATION_MM_S2 × (total_steps / d)
```

### 2.3 Fases do perfil trapezoidal

**Cálculo de accel_steps (partindo do repouso, v_entry = 0):**

Usando cinemática: `v² = v₀² + 2as` → `v_max² = 2 × a_steps × accel_steps`

```
accel_steps = step_rate² / (2 × a_steps)
```

**Verificação numérica** (config padrão: 600mm/min, 80 steps/mm, 500mm/s²):
```
v_max = 600/60 = 10 mm/s
step_rate = 10 × 80 = 800 steps/s
a_steps = 500 × 80 = 40000 steps/s²

accel_steps = 800² / (2 × 40000) = 640000 / 80000 = 8 passos

decel_step_start = total_steps - 8

Para mover 10mm (800 passos totais):
  accel:  8 passos
  cruise: 784 passos
  decel:  8 passos
  Total:  800 passos ✓
```

### 2.4 Perfil triangular (movimentos curtos)

Quando `accel_steps × 2 ≥ total_steps`, a distância é insuficiente para
atingir v_max. O perfil vira um triângulo (sem fase de cruzeiro):

```
accel_steps = total_steps / 2

v_peak = sqrt(2 × a_steps × accel_steps)
```

**Verificação** (mover 1mm = 80 passos com config padrão):
```
accel_steps (tentativa) = 8 passos
8 × 2 = 16 > 80? Não → perfil trapezoidal normal

Para mover 0.1mm = 8 passos:
accel_steps (tentativa) = 8 passos
8 × 2 = 16 ≥ 8 → TRIANGULAR

accel_steps = 8/2 = 4 passos
v_peak = sqrt(2 × 40000 × 4) = sqrt(320000) ≈ 566 steps/s
T_min = 1e6/566 ≈ 1767 µs
```

### 2.5 Período do primeiro passo (partindo do repouso)

Usando cinemática (s = ½at² → t = sqrt(2s/a)):

Para `s = 1 passo` a partir do repouso com aceleração `a_steps`:
```
t₁ = sqrt(2 / a_steps)  [s]
initial_period_us = t₁ × 1e6 = sqrt(2 / a_steps) × 1e6
```

**Verificação** (a_steps = 40000 steps/s² do exemplo acima):
```
t₁ = sqrt(2 / 40000) = sqrt(0.00005) = 0.007071 s
initial_period_us = 7071 µs ≈ 7ms

Velocidade implícita no primeiro passo:
v₁ = 1/t₁ = 141 steps/s → 1.77 mm/s (lento — motor parte suavemente) ✓
```

### 2.6 Incremento de período (rampa linear)

```
accel_increment = (initial_period_us - min_period_us) / accel_steps
```

**Verificação** (config padrão, 10mm movimento):
```
initial_period_us ≈ 7071 µs
min_period_us = 1e6/800 = 1250 µs
accel_steps = 8

accel_increment = (7071 - 1250) / 8 = 5821 / 8 = 727 µs por passo

Sequência de períodos durante aceleração:
  Passo 1: 7071 µs (141 steps/s = 1.77 mm/s)
  Passo 2: 7071 - 727 = 6344 µs (158 steps/s)
  Passo 3: 6344 - 727 = 5617 µs (178 steps/s)
  Passo 4: 5617 - 727 = 4890 µs (205 steps/s)
  Passo 5: 4890 - 727 = 4163 µs (240 steps/s)
  Passo 6: 4163 - 727 = 3436 µs (291 steps/s)
  Passo 7: 3436 - 727 = 2709 µs (369 steps/s)
  Passo 8: 2709 - 727 = 1982 µs (505 steps/s)
  Cruzeiro: 1250 µs (800 steps/s = 10 mm/s) ✓
```

**Nota sobre a ramp linear vs. ramp GRBL:**

A ramp linear no período não é fisicamente idêntica à aceleração constante
(que requereria `period ∝ 1/sqrt(n)`). A aproximação de Olds usada no GRBL
é `period_n = period_{n-1} × (2n-1)/(2n+1)`, que converge para `1/sqrt(n)`.

Para este projeto educacional, a ramp linear é escolhida por:
1. Apenas adição inteira na ISR (zero divisões, zero multiplicações).
2. Erro de velocidade < 15% para os primeiros passos, decaindo rapidamente.
3. Motores de passo têm margem de torque que absorve variações de velocidade.
4. Didaticamente mais clara que a aproximação de Olds.

---

## 3. Diagrama de Temporização (Exemplo 10mm @ 600mm/min)

```
Período
(µs)
7071 ─┐
      │╲  Aceleração
      │ ╲  (8 passos)
      │  ╲
1982 ─┤   ╲___________________________
1250 ─┤                               ╲__ Desaceleração
      │  Cruzeiro (784 passos)         ╲  (8 passos)
      │                                 └───
      └────────────────────────────────────── Passos
      0   8                          792  800

Duração total estimada:
  Aceleração: ~35ms (soma dos 8 períodos ≈ 35,2ms)
  Cruzeiro:   784 × 1,25ms = 980ms ≈ 1s
  Desaceleração: ~35ms
  Total: ~1,05s para 10mm ✓ (10mm @ 10mm/s = 1s teórico, dentro do esperado)
```

---

## 4. Separação plan_pos vs. mpos — Diagrama

```
Tempo →

Parser:   [G1 X10] [G1 X20] [G1 X30]
          plan_x:10 plan_x:20 plan_x:30

Planner:  [bloco1] [bloco2] [bloco3]
          s_pos_steps_x: 800→1600→2400

planner_queue: [bloco1][bloco2][bloco3] (16 slots disponíveis)

Executor: executando bloco1...
          g_state.mpos_x: 0→10 (após bloco1)

M114 neste momento → reporta g_state.mpos_x = 0 (ainda executando bloco1)
? neste momento    → reporta <Run|MPos:0.000,...> (ainda executando)
```

Esta divergência é o comportamento correto: `mpos` reflete onde a ferramenta
FISICAMENTE está; `plan_pos` reflete onde ela ESTARÁ quando a fila esvaziar.
