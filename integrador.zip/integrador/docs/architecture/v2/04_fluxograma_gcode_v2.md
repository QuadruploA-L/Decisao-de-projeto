# Fluxograma de Processamento G-Code — v2

## 1. Pipeline Completo v2

```
                         ┌─────────────────────────┐
                         │   HOST (PC / Software)   │
                         └────────────┬────────────┘
                                      │ USB Serial
                                      ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│ UARTTask                                                                    │
│                                                                             │
│  ┌────────────┐    ┌──────────────────────────────────────────────────┐   │
│  │uart_read() │───►│ Para cada byte recebido:                         │   │
│  │(bloqueante)│    │                                                  │   │
│  └────────────┘    │  if (byte == '?') ──────────────────────────►   │   │
│                    │      state_mutex (5ms)                           │   │
│                    │      snap = g_state                              │   │
│                    │      uart_tx_mutex → grbl_send_status() ──► TX  │   │
│                    │      continue   ← NÃO acumula no buffer         │   │
│                    │                                                  │   │
│                    │  buffer[idx++] = byte                            │   │
│                    │  if (byte == '\n'):                              │   │
│                    │      xQueueSend(cmd_queue, buf, 0)  ← timeout 0 │   │
│                    │      idx = 0                                     │   │
│                    └──────────────────────────────────────────────────┘   │
└───────────────────────────────────────────────┬─────────────────────────────┘
                                                │ cmd_queue
                                                ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│ GCodeParserTask                                                             │
│                                                                             │
│  xQueueReceive(cmd_queue, portMAX_DELAY)                                   │
│          │                                                                  │
│          ▼                                                                  │
│  Linha vazia / comentário ';'? ──Sim──► descarta, sem resposta             │
│          │ Não                                                              │
│          ▼                                                                  │
│  Tokeniza: extrai pares letra+número (G, M, X, Y, F)                       │
│          │                                                                  │
│          ├──── G90 / G91 ──────────────────────────────────────────────►  │
│          │                    state_mutex → atualiza position_absolute     │
│          │                    uart_tx_mutex → "ok\n"                       │
│          │                                                                  │
│          ├──── M114 ───────────────────────────────────────────────────►  │
│          │                    state_mutex → lê mpos_x, mpos_y             │
│          │                    uart_tx_mutex → "X:%.3f Y:%.3f\n" + "ok\n" │
│          │                                                                  │
│          ├──── M3 / M5 ────────────────────────────────────────────────►  │
│          │           Cria motion_cmd_t:                                    │
│          │             type = CMD_EXTRUDER_ONLY                            │
│          │             target = posição atual (sem movimento)              │
│          │             extruder_action = 1 (M3) ou 0 (M5)                 │
│          │           → motion_queue (portMAX_DELAY)                        │
│          │           → uart_tx_mutex "ok\n"                                │
│          │                                                                  │
│          ├──── G0 / G1 ────────────────────────────────────────────────►  │
│          │           Resolve coordenadas:                                  │
│          │             if G90: target = values_parsed                      │
│          │             if G91: target = mpos + values_parsed               │
│          │           Cria motion_cmd_t:                                    │
│          │             type = CMD_MOVE_G0 ou CMD_MOVE_G1                   │
│          │             target_x, target_y, feedrate                        │
│          │             extruder_action = -1 (sem mudança)                  │
│          │           → motion_queue (portMAX_DELAY)                        │
│          │           → uart_tx_mutex "ok\n"                                │
│          │                                                                  │
│          └──── G28 ─────────────────────────────────────────────────────►  │
│                    Cria motion_cmd_t { type = CMD_HOMING }                 │
│                    → motion_queue (portMAX_DELAY)                          │
│                    xEventGroupWaitBits(EVENT_HOMING_DONE, portMAX_DELAY)  │
│                    uart_tx_mutex "ok\n"    ← só após homing concluir      │
│                                                                             │
│          Qualquer token desconhecido → uart_tx_mutex "error\n"             │
└─────────────────────────────────────────────────────────────────────────────┘
                              │
                              │ motion_queue
                              ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│ MotionPlannerTask                                                           │
│                                                                             │
│  xQueueReceive(motion_queue, portMAX_DELAY)                                │
│          │                                                                  │
│          ├── CMD_EXTRUDER_ONLY ──────────────────────────────────────────  │
│          │   Cria motion_block_t:                                          │
│          │     total_steps = 0                                              │
│          │     extruder_action = cmd.extruder_action                        │
│          │   → planner_queue (portMAX_DELAY)                               │
│          │                                                                  │
│          ├── CMD_MOVE_G0 / CMD_MOVE_G1 ──────────────────────────────────  │
│          │   1. Converte coordenadas → passos:                              │
│          │      steps_x = round((target_x - plan_x) * STEPS_PER_MM_X)     │
│          │      steps_y = round((target_y - plan_y) * STEPS_PER_MM_Y)     │
│          │                                                                  │
│          │   2. Parâmetros Bresenham:                                       │
│          │      dx = |steps_x|, dy = |steps_y|                             │
│          │      dominant = max(dx, dy), subordinate = min(dx, dy)          │
│          │      dominant_is_x = (dx >= dy)                                 │
│          │      dir_x = sign(steps_x), dir_y = sign(steps_y)              │
│          │      bresenham_error = dominant / 2  (erro inicial)             │
│          │                                                                  │
│          │   3. Perfil trapezoidal (G0 usa MAX_FEEDRATE):                  │
│          │      v_max = feedrate / 60.0  [mm/s]                            │
│          │      step_rate = v_max × STEPS_PER_MM                           │
│          │      Verifica movimento triangular: accel+decel > total         │
│          │      Calcula initial_period, min_period, increments             │
│          │                                                                  │
│          │   4. Atualiza plan_x, plan_y (posição de planejamento)          │
│          │   5. → planner_queue (portMAX_DELAY)                            │
│          │                                                                  │
│          └── CMD_HOMING ──────────────────────────────────────────────────  │
│              Cria motion_block_t especial { type = BLOCK_HOMING }          │
│              → planner_queue (portMAX_DELAY)                               │
└─────────────────────────────────────────────────────────────────────────────┘
                              │
                              │ planner_queue (16 slots)
                              ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│ MotionExecutorTask (Core 1)                                                 │
│                                                                             │
│  xQueueReceive(planner_queue, portMAX_DELAY)                               │
│          │                                                                  │
│          ├── BLOCK_HOMING ──► executa homing (ver fluxo G28 abaixo)       │
│          │                                                                  │
│          ├── total_steps == 0 (CMD_EXTRUDER_ONLY):                         │
│          │   hal_extruder_on/off(action)                                   │
│          │   state_mutex → g_state.extruder_on = action                   │
│          │   continua loop (sem GPTimer)                                   │
│          │                                                                  │
│          └── total_steps > 0 (movimento real):                             │
│              1. hal_extruder_on/off se extruder_action != -1               │
│              2. hal_stepper_set_dir(X, dir_x)                              │
│              3. hal_stepper_set_dir(Y, dir_y)                              │
│              4. hal_stepper_enable()                                        │
│              5. gptimer_stop() — garante timer parado                      │
│              6. portENTER_CRITICAL()                                        │
│                 g_isr_ctx = { block, step_count=0, ACCEL, initial_period } │
│                 portEXIT_CRITICAL()                                         │
│              7. state_mutex → g_state.status = STATE_RUN                  │
│              8. gptimer_set_alarm(initial_period_us)                       │
│              9. gptimer_start()                                             │
│             10. xTaskNotifyWait(BLOCK_DONE|ALARM, portMAX_DELAY) ← BLOQUEIA│
│             11. state_mutex → g_state.mpos_x/y += delta                   │
│             12. Se planner_queue vazia: g_state.status = STATE_IDLE        │
│             13. Loop                                                        │
└─────────────────────────────────────────────────────────────────────────────┘
```

## 2. Fluxo G28 (Homing) — v2

```
MotionExecutor recebe bloco BLOCK_HOMING:
    │
    ▼
state_mutex → g_state.status = STATE_HOMING

═══ FASE 1: Homing X ════════════════════════════════════════════════════════
    hal_stepper_set_dir(X, DIR_NEGATIVE)
    hal_stepper_enable()
    
    Loop de homing X (velocidade = HOMING_SPEED_STEPS_S):
        gptimer com period = 1e6 / HOMING_SPEED_STEPS_S
        A cada pulso da ISR (modo homing — ISR simplificada):
            hal_stepper_step(X)
            step_count++
            Verifica hal_endstop_read_x():
                true → sinaliza fim X
        Limite de segurança: se step_count > MAX_TRAVEL_STEPS_X: EVENT_ALARM
    
    Endstop X acionado:
        gptimer_stop()
        hal_stepper_disable()
        Recuo X: move +HOMING_PULLOFF_MM (direção oposta, velocidade reduzida)
        state_mutex → g_state.mpos_x = 0.0
        plan_x = 0  (Planner reset — importante!)

═══ FASE 2: Homing Y (mesmo procedimento) ═══════════════════════════════════

    state_mutex → g_state.mpos_y = 0.0
    plan_y = 0

═══ CONCLUSÃO ════════════════════════════════════════════════════════════════
    state_mutex → g_state.status = STATE_IDLE
    xEventGroupSetBits(EVENT_HOMING_DONE)
    
    ← GCodeParserTask estava bloqueado em xEventGroupWaitBits(HOMING_DONE)
    ← Agora desbloqueia e envia "ok\n"
```

## 3. Fluxo da ISR (GPTimer) — v2

```
gptimer_isr_callback() [IRAM_ATTR, Core 1]
    │
    ▼
ctx = &g_isr_ctx  ← leitura do contexto (sem lock — Executor garantiu exclusão)
    │
    ├── MODO NORMAL (movimento) ────────────────────────────────────────────
    │   │
    │   ├── Pulso no eixo dominante:
    │   │   gpio_set_level(STEP_dominant, 1)
    │   │   esp_rom_delay_us(2)          ← STEP pulse width ≥ 2µs
    │   │   gpio_set_level(STEP_dominant, 0)
    │   │
    │   ├── Bresenham eixo subordinado:
    │   │   ctx.error += ctx.subordinate
    │   │   if (ctx.error >= ctx.dominant):
    │   │       gpio_set_level(STEP_subordinate, 1)
    │   │       esp_rom_delay_us(2)
    │   │       gpio_set_level(STEP_subordinate, 0)
    │   │       ctx.error -= ctx.dominant
    │   │
    │   ├── Atualiza período trapezoidal:
    │   │   ACCEL:  ctx.period_us -= ctx.accel_increment
    │   │           clampa em min_period_us
    │   │   CRUISE: nenhuma mudança
    │   │   DECEL:  ctx.period_us += ctx.decel_increment
    │   │
    │   ├── Fase transition:
    │   │   if (step_count == accel_steps):  phase = CRUISE
    │   │   if (step_count == decel_start):  phase = DECEL
    │   │
    │   ├── ctx.step_count++
    │   │
    │   └── Fim de bloco?
    │       if (ctx.step_count >= ctx.total_steps):
    │           gptimer_stop_in_isr_context()
    │           BaseType_t woken = pdFALSE
    │           xTaskNotifyFromISR(executor_handle, BLOCK_DONE, eSetBits, &woken)
    │           portYIELD_FROM_ISR(woken)
    │       else:
    │           gptimer_alarm_config_t alarm = { .alarm_count = ctx.period_us }
    │           gptimer_set_alarm_action(timer, &alarm)  ← re-arma
    │
    └── MODO HOMING (ISR simplificada) ──────────────────────────────────────
        gpio_set_level(STEP_axis, 1)
        esp_rom_delay_us(2)
        gpio_set_level(STEP_axis, 0)
        ctx.homing_step_count++
        re-arma com period fixo (HOMING_SPEED)
        (verificação de endstop: polling no Executor, não na ISR)
```
