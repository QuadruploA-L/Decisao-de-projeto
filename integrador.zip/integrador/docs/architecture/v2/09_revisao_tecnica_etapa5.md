# Revisão Técnica de Engenharia — Subsistema de Movimento (Pré-Etapa 5)

## Resultado: APROVADO COM RESSALVAS (1 bug crítico + 2 pontos de atenção)

---

## 1. Estrutura final `motion_block_t` — Inventário completo

```
typedef struct {
    bool     is_homing;          // [1 byte]  tipo de bloco
    // --- alinhamento ---
    int32_t  steps_x;            // [4 bytes] passos com sinal (inclui direção)
    int32_t  steps_y;            // [4 bytes]
    int8_t   dir_x;              // [1 byte]  +1 ou -1
    int8_t   dir_y;              // [1 byte]
    // --- alinhamento ---
    int32_t  dominant;           // [4 bytes] max(|steps_x|, |steps_y|)
    int32_t  subordinate;        // [4 bytes] min(|steps_x|, |steps_y|)
    int32_t  bresenham_error;    // [4 bytes] erro inicial = dominant / 2
    bool     dominant_is_x;      // [1 byte]  qual eixo é dominante
    // --- alinhamento ---
    uint32_t total_steps;        // [4 bytes] = dominant (loop limit)
    uint32_t accel_steps;        // [4 bytes] passos na fase de aceleração
    uint32_t decel_step_start;   // [4 bytes] = total_steps - accel_steps
    uint32_t initial_period_us;  // [4 bytes] período do 1º passo (maior)
    uint32_t min_period_us;      // [4 bytes] período de cruzeiro (menor)
    uint32_t accel_increment;    // [4 bytes] Δ por passo na aceleração
    uint32_t decel_increment;    // [4 bytes] Δ por passo na desaceleração
    int8_t   extruder_action;    // [1 byte]  -1/0/1
} motion_block_t;                // ~56-64 bytes (com padding de alinhamento)
```

### Classificação de campos por consumidor

| Campo | Quem usa | Como |
|-------|----------|------|
| `is_homing` | Executor (task) | Branch para sequência de homing |
| `steps_x`, `steps_y` | Executor (task) | Atualiza `g_state.mpos` após conclusão |
| `dir_x`, `dir_y` | Executor (task) | Configura GPIO DIR antes de armar timer |
| `dominant`, `subordinate` | **ISR** | Bresenham: denominador e numerador |
| `bresenham_error` | Executor (task) → cópia em `g_isr_ctx` | ISR usa `g_isr_ctx.bresenham_error` |
| `dominant_is_x` | **ISR** | Determina qual eixo recebe o passo |
| `total_steps` | **ISR** | Condição de fim de bloco |
| `accel_steps` | **ISR** | Limiar de transição ACCEL→CRUISE |
| `decel_step_start` | **ISR** | Limiar de transição CRUISE→DECEL |
| `initial_period_us` | Executor (task) | Inicializa `g_isr_ctx.current_period` |
| `min_period_us` | **ISR** | Clamp mínimo do período |
| `accel_increment` | **ISR** | Redução de período por passo |
| `decel_increment` | **ISR** | Aumento de período por passo |
| `extruder_action` | Executor (task) | Chama hal_extruder antes do bloco |

**Resumo:** a ISR precisa de exatamente 7 campos do bloco:
`dominant`, `subordinate`, `dominant_is_x`, `total_steps`, `accel_steps`,
`decel_step_start`, `min_period_us`, `accel_increment`, `decel_increment`.
(São 9, não 7 — todos inteiros, todos imutáveis durante a execução.)

---

## 2. Campos da ISR: read-only vs. mutáveis

```
isr_context_t g_isr_ctx = {
    .block           = <cópia>    // read-only durante ISR
    .step_count      = 0          // MUTÁVEL — incrementa a cada ciclo
    .current_period  = T₀         // MUTÁVEL — varia por fase
    .phase           = ACCEL      // MUTÁVEL — ACCEL/CRUISE/DECEL
    .bresenham_error = dominant/2  // MUTÁVEL — acumula e subtrai
}
```

A separação é essencial: `g_isr_ctx.bresenham_error` é uma CÓPIA mutável de
`block.bresenham_error` (que é read-only). Isso permite que a ISR modifique o
acumulador sem tocar no bloco original — necessário porque o mesmo bloco
pode ser reutilizado para depuração.

**Regra de acesso:**
- Executor escreve `g_isr_ctx` APENAS após `gptimer_stop()`, com spinlock.
- ISR lê e modifica `g_isr_ctx` APENAS enquanto o timer está rodando.
- Os dois domínios são mutuamente exclusivos por design.

---

## 3. Onde o float é usado

### Planner (MotionPlannerTask — Core 0, prioridade 3)

| Operação | Função C | Custo |
|----------|----------|-------|
| `lroundf(target × STEPS_PER_MM)` | conversão mm→steps | leve |
| `sqrtf(dx_mm² + dy_mm²)` | distância euclideana | pesado |
| `step_rate = v × N / d` | taxa de steps | leve |
| `a_steps = A × N / d` | aceleração projetada | leve |
| `step_rate² / (2 × a_steps)` | cálculo accel_steps | leve |
| `sqrtf(2.0f / a_steps) × 1e6f` | período inicial | pesado |
| `(T₀ - T_min) / accel_steps` | incremento (int result) | leve |

**Dois `sqrtf` por bloco.** Cada `sqrtf` no ESP32 (FPU) leva ~8–15 ciclos de
co-processador (aprox. 33–63ns @ 240MHz). Totalmente irrelevante no Planner.

### Executor (MotionExecutorTask — Core 1, APÓS conclusão do bloco)

```c
// Executado em task context, fora da ISR, com mutex
g_state.mpos_x += (float)block.steps_x / STEPS_PER_MM_X;
g_state.mpos_y += (float)block.steps_y / STEPS_PER_MM_Y;
```

Uma divisão float por eixo, uma única vez por bloco concluído. Custo negligível.

### ISR do GPTimer

**Zero operações float.** Toda a aritmética é inteira:
- `+=`, `-=` em `uint32_t` e `int32_t`
- Comparações `<=`, `>=`
- Nenhuma divisão, nenhum ponto flutuante, nenhum `sqrt`

---

## 4. Cálculos fora da ISR — onde e quando

```
PLANNER (task, uma única vez por bloco, antes de enfileirar):
  sqrtf → lroundf → step_rate → a_steps → accel_steps
  → triangular check → initial_period → increment
  → preenche motion_block_t → xQueueSend(planner_queue)

EXECUTOR (task, ANTES de armar o timer):
  hal_extruder_on/off()                  ← GPIO extrusor
  hal_stepper_set_dir(X, dir_x)          ← GPIO DIR
  hal_stepper_set_dir(Y, dir_y)
  hal_stepper_enable()                   ← GPIO EN
  g_state.status = STATE_RUN             ← com state_mutex

EXECUTOR (task, APÓS conclusão do bloco):
  mpos_x += steps_x / STEPS_PER_MM_X    ← float, com state_mutex
  mpos_y += steps_y / STEPS_PER_MM_Y
  g_state.status = IDLE ou RUN           ← depende de planner_queue
```

**Invariante fundamental:** nenhum cálculo que exija tempo indeterminado
(float, sqrt, divisão) ocorre dentro da ISR ou no caminho crítico de tempo real.

---

## 5. Bresenham passo a passo — rastreamento completo

**Exemplo canônico:** movimento (0,0) → (5,3) em passos inteiros.

### Inicialização (Executor, antes de armar timer)

```
block.dominant      = 5  (dx=5, dy=3, X é dominante)
block.subordinate   = 3
block.dominant_is_x = true
block.total_steps   = 5

g_isr_ctx.bresenham_error = 5 / 2 = 2  (erro inicial = dominant/2)
g_isr_ctx.step_count      = 0
```

### Execução na ISR (5 ciclos)

```
Ciclo │ Step Dominant │ error += sub │ error ≥ dom? │ Step Subord │ error final │ step_count
──────┼───────────────┼──────────────┼──────────────┼─────────────┼─────────────┼───────────
  1   │ step(X)       │  2 + 3 = 5   │  5 ≥ 5  ✓   │  step(Y)    │   5 - 5 = 0 │     1
  2   │ step(X)       │  0 + 3 = 3   │  3 ≥ 5  ✗   │             │   3         │     2
  3   │ step(X)       │  3 + 3 = 6   │  6 ≥ 5  ✓   │  step(Y)    │   6 - 5 = 1 │     3
  4   │ step(X)       │  1 + 3 = 4   │  4 ≥ 5  ✗   │             │   4         │     4
  5   │ step(X)       │  4 + 3 = 7   │  7 ≥ 5  ✓   │  step(Y)    │   7 - 5 = 2 │     5
```

No ciclo 5: `step_count (5) >= total_steps (5)` → `xTaskNotifyFromISR` e não re-arma.

### Posições geradas

```
Ciclo 1: (1, 1)   Ciclo 2: (2, 1)   Ciclo 3: (3, 2)
Ciclo 4: (4, 2)   Ciclo 5: (5, 3)   ← posição final ✓
```

### Comparação com a reta real

A reta real de (0,0) a (5,3) tem equação y = 0.6x.
Posições reais: x=1→0.6, x=2→1.2, x=3→1.8, x=4→2.4, x=5→3.0
Arredondadas: (1,1), (2,1), (3,2), (4,2), (5,3) — idêntico ao Bresenham ✓

### Invariante do algoritmo

Em qualquer passo k, o erro acumulado satisfaz:
```
0 ≤ bresenham_error < dominant
```
O erro nunca ultrapassa o valor `dominant - 1` após cada redução,
o que garante que o acumulador não transborda (sempre dentro do range de int32_t).
Para dominant ≤ 400.000 passos (500mm × 800 steps/mm) e int32_t (max ~2.1 bilhões),
não há risco de overflow.

---

## 6. Atualização da posição atual da máquina

### Fluxo após conclusão do bloco

```
ISR detecta step_count == total_steps
    → xTaskNotifyFromISR(executor_handle, EVENT_BLOCK_DONE, eSetBits)
    → retorna true (higher_prio_woken) → CPU yield para Executor

Executor acorda do xTaskNotifyWait()
    → verifica notify_val & EVENT_BLOCK_DONE

    xSemaphoreTake(g_state_mutex, 5ms)
        g_state.mpos_x += (float)block.steps_x / STEPS_PER_MM_X
        g_state.mpos_y += (float)block.steps_y / STEPS_PER_MM_Y

        // steps_x tem sinal: movimento negativo subtrai corretamente
        // Exemplo: steps_x = -400, STEPS_PER_MM_X = 80
        //          mpos_x += -400/80 = -5.0 mm ✓

        g_state.status = (uxQueueMessagesWaiting(g_planner_queue) == 0)
                         ? STATE_IDLE : STATE_RUN
    xSemaphoreGive(g_state_mutex)
```

### Por que `steps_x` com sinal funciona para posição

O planner calcula `steps_x = target_steps_x - s_pos_steps_x`.
Para um movimento de 10mm → 5mm (retorno), `steps_x = 400 - 800 = -400`.
O Executor usa `dir_x = block.dir_x = -1` para configurar o GPIO DIR antes do bloco.
Após o bloco: `mpos_x += -400/80 = -5.0` → `mpos_x` vai de 10.0 para 5.0 ✓

---

## 7. Como M114 obtém posição durante movimento em andamento

### Comportamento atual (posição de último bloco concluído)

```
Executor executa bloco 1 (X:0→10mm)
  → bloco 1 completa
  → g_state.mpos_x = 10.0
Executor começa bloco 2 (X:10→20mm)
  → ISR gerando passos...
  → g_state.mpos_x ainda = 10.0 (não atualizado durante execução)

Host envia M114 (processado pelo GCodeParserTask):
  xSemaphoreTake(state_mutex)
  px = g_state.mpos_x  →  10.0 mm  (posição do último bloco completo)
  xSemaphoreGive(state_mutex)
  grbl_send_position(10.0, ...)
```

### Por que não atualizar em tempo real

A ISR NÃO pode escrever em `g_state.mpos` porque:
1. `g_state.mpos` é protegido por `state_mutex` (mutex FreeRTOS).
2. Adquirir mutex dentro de ISR causa deadlock (espinlock do FreeRTOS).
3. Alternativa segura (contador atômico em IRAM) adicionaria complexidade desnecessária.

### Limitação documentada

M114 reporta a posição física no início do bloco corrente, não a posição
instantânea da ferramenta. Para o caso de uso de deposição de material (este
projeto), isso é aceitável: o host envia a sequência e recebe a posição
correta entre blocos. Esta é exatamente a semântica do M114 no GRBL.

### Posição estimada durante movimento (opcional, não implementado)

Para obter posição aproximada durante execução, seria possível:
```c
// (sem mutex — leitura de volatile, best-effort)
uint32_t sc = g_isr_ctx.step_count;
float est_x = g_state.mpos_x + (float)(sc * block.dir_x) / STEPS_PER_MM_X;
```
Não é implementado pois a leitura de `g_isr_ctx` fora do Executor é unsafe
(potencial tearing de campos de 32 bits em plataforma SMP se lido do Core 0).

---

## 8. Implementação das transições ACCEL / CRUISE / DECEL

### Lógica de detecção (pseudocódigo da ISR)

```c
g_isr_ctx.step_count++;

if (step_count <= accel_steps) {
    // FASE ACCEL
} else if (step_count >= decel_step_start) {
    // FASE DECEL
}
// else: FASE CRUISE (sem ação no período)
```

### Análise de limites para perfil trapezoidal (total=100, accel=20)

```
decel_step_start = 100 - 20 = 80

step_count  1 ..  20 : ACCEL  (condição: ≤ 20) → 20 passos
step_count 21 ..  79 : CRUISE (nenhuma condição satisfeita) → 59 passos
step_count 80 .. 100 : DECEL  (condição: ≥ 80) → 21 passos
```

**Assimetria identificada:** ACCEL tem 20 passos, DECEL tem 21 passos (step 100 é DECEL e fim de bloco).

Origem: o step_count=100 satisfaz `>= decel_step_start (80)` ANTES da checagem de fim de bloco.
O último step recebe um incremento de período que é imediatamente descartado (não re-arma).

**Impacto prático:** desprezível. A fase DECEL tem exatamente 1 passo extra. Para 20 passos
de desaceleração, isso representa 5% de erro na simetria, que é imperceptível no motor.

**Caso triangular perfeito** (total=100, accel=50, decel_step_start=50):
```
step_count  1 ..  50 : ACCEL (≤ 50) → 50 passos
step_count 51 .. 100 : DECEL (≥ 50, mas step 50 já foi para ACCEL) → 50 passos
                                                                      ↑ simétrico ✓
```
O perfil triangular é perfeitamente simétrico com esta lógica. ✓

### Transições de período

**ACCEL:**
```c
if (current_period > min_period_us + accel_increment) {
    current_period -= accel_increment;
} else {
    current_period = min_period_us;  // clamp: nunca abaixo do mínimo
}
```
Sem underflow: o clamp previne que `current_period` vá abaixo de `min_period_us`.

**DECEL:**
```c
current_period += decel_increment;
if (current_period > MAX_STEP_PERIOD_US) {
    current_period = MAX_STEP_PERIOD_US;  // clamp: nunca acima do máximo
}
```
Sem overflow: `MAX_STEP_PERIOD_US = 100000` cabe em uint32_t. O incremento
máximo por passo é `(T₀ - T_min) / accel_steps`. Para T₀ = 100000, T_min = 10,
accel_steps = 1 (caso extremo): incremento = 99990/step. Após 1 step de DECEL,
current_period = 99990 + 99990 = 199980 → clampado para 100000 ✓.

---

## 9. Justificativa matemática: rampa linear de período ≠ aceleração constante

### O que seria aceleração constante

Para aceleração física constante `a_steps` [steps/s²], a posição após `n` passos é:
```
t(n) = sqrt(2n / a_steps)  [s — tempo para completar n passos desde o repouso]
```

O INTERVALO entre o passo n-1 e o passo n (o que o timer mede):
```
T_const(n) = t(n) - t(n-1)
           = sqrt(2/a_steps) × (sqrt(n) - sqrt(n-1))
           = T₀ × (sqrt(n) - sqrt(n-1))
```

**Sequência para a_steps=40000 (T₀=7071µs, accel_steps=8, T_min=1250µs):**

```
n  │ T_const(n) [µs]  │ T_linear(n) [µs]  │ Erro relativo
───┼───────────────────┼────────────────────┼──────────────
1  │ 7071              │ 7071               │ 0%
2  │ 2929              │ 6344               │ +117%
3  │ 2247              │ 5617               │ +150%
4  │ 1894              │ 4890               │ +158%
5  │ 1670              │ 4163               │ +149%
6  │ 1508              │ 3436               │ +128%
7  │ 1382              │ 2709               │ +96%
8  │ 1287              │ 1982               │ +54%
```

**(Os valores de T_const corretos acima usam T_const(n) = T₀ × (√n - √(n-1)))**

### O que a rampa linear implementa

Com rampa linear: `T_linear(n) = T₀ - n × Δ`, onde `Δ = (T₀ - T_min) / accel_steps`.

A velocidade instantânea no passo n (aproximação: v ≈ 1/T):
```
v(n) = 1 / T_linear(n) = 1 / (T₀ - n×Δ)
```

A aceleração entre passos n e n+1:
```
a_eff(n) ≈ (v(n+1) - v(n)) / T_linear(n)
          = [1/(T₀-(n+1)Δ) - 1/(T₀-nΔ)] / (T₀-nΔ)
          = Δ / [(T₀-nΔ)² × (T₀-(n+1)Δ)]
```

Esta aceleração é **crescente com n** (o denominador diminui à medida que o período
encurta). Em outras palavras:
- Nos primeiros passos: aceleração baixa (período longo, mudança pequena)
- Nos últimos passos: aceleração alta (período curto, mudança proporcionalmente grande)

**Isso inverte o esperado para controle de torque:** a aceleração maior acontece
quando o motor já está em alta velocidade (torque menor), que é justamente quando
o motor tem menos capacidade de suportar aceleração extra.

### Por que é aceitável apesar disso

1. **Para motores de passo, torque é quase constante até ~30% da velocidade máxima.**
   A aceleração no início da faixa de operação (períodos longos) é pequena na rampa linear,
   e no final (próximo ao cruzeiro) é maior — mas o motor já atingiu velocidade e o
   torque necessário para manter aceleração é menor.

2. **O total de energia investida na aceleração é similar.**
   A área sob a curva v(n) × n define a distância total de aceleração, que é conservada.

3. **Fins educacionais:** a rampa linear é explicitamente escolhida por ser implementável
   com uma única subtração inteira na ISR, sem multiplicações ou raízes. Isso demonstra
   o tradeoff entre precisão física e simplicidade de implementação — objetivo central
   do projeto.

4. **Limite real é o torque de puxada do motor**, não a perfeiçoamento matemático da curva.
   Para o NEMA17 com alimentação 12V, a velocidade de puxada a qualquer feedrate dentro
   da faixa recomendada (≤ 3000mm/min) deixa margem de torque suficiente para tolerar
   variações de aceleração.

### Resumo

| Implementação | Aceleração | Custo na ISR | Precisão |
|---------------|-----------|--------------|---------|
| Rampa linear (este projeto) | Crescente (não constante) | 1 adição/subtração | Baixa — adequada |
| Aproximação de Olds (GRBL) | Aproxima constante | 1 mult inteira | Média — excelente |
| T(n) = T₀×(√n - √(n-1)) | Exata e constante | sqrtf por passo | Alta — proibida na ISR |

---

## 10. Estimativa de WCET da ISR e verificação de proibições

### Análise de instruções (ESP32 @ 240MHz, ciclo = 4.17ns)

**Pior caso: passo nos DOIS eixos no mesmo ciclo (diagonal 45°)**

```
Operação                                     Ciclos  Tempo (ns)
─────────────────────────────────────────────────────────────────
Entrada da ISR (context save, FreeRTOS)        ~50      ~208
Carga de g_isr_ctx (L1 cache hit)              ~4        ~17
Branch para eixo dominante                     ~3        ~13
gpio_set_level(STEP_dominant, 1)              ~30       ~125
esp_rom_delay_us(2)                           480     2.000
gpio_set_level(STEP_dominant, 0)              ~30       ~125
Bresenham: error += subordinate                ~3        ~13
Comparação error >= dominant                   ~2         ~8
Branch for subordinate step                    ~3        ~13
gpio_set_level(STEP_subordinate, 1)           ~30       ~125
esp_rom_delay_us(2)                           480     2.000
gpio_set_level(STEP_subordinate, 0)           ~30       ~125
step_count++                                   ~3        ~13
Checagem de fase (if/else if)                  ~5        ~21
Atualização de current_period (sub/add)        ~4        ~17
Checagem de fim de bloco                       ~5        ~21
─────────────────────────────────────────────────────────────────
Se fim de bloco:
  xTaskNotifyFromISR (FreeRTOS)              ~100       ~417
  portYIELD_FROM_ISR                         ~50       ~208
─────────────────────────────────────────────────────────────────
Se não fim (re-arme):
  gptimer_set_alarm_action (reg write)        ~30       ~125
─────────────────────────────────────────────────────────────────
Saída da ISR (context restore)               ~50       ~208

WCET (pior caso, passo XY + fim de bloco):  ~1.357  ~5.658 ns ≈ 6 µs
WCET (pior caso, passo XY + re-arme):      ~1.258  ~5.241 ns ≈ 6 µs
```

**Dominante:** `esp_rom_delay_us(2)` corresponde a 4000ns dos ~5658ns totais (≈71%).
Essa latência é OBRIGATÓRIA por requisito de hardware (A4988: pulso mínimo 1µs, DRV8825: 1.9µs).

**Margem de segurança:**
```
MIN_STEP_PERIOD_US = 10 µs  (configurado em config.h)
WCET = 6 µs
Margem = 10 / 6 = 1,67× — conservador mas adequado.

Feedrate máximo recomendado (3000mm/min = 50mm/s):
  period = 1e6 / (50 × 80) = 250 µs
  Margem = 250 / 6 = 41× — amplamente seguro ✓
```

### Verificação das proibições

| Proibição | Status | Evidência |
|-----------|--------|-----------|
| `malloc` / heap | ✓ Ausente | Toda memória é estática/stack |
| `printf` / `ESP_LOG*` | ✓ Ausente | Logs só no Executor (task context) |
| `xQueueSend` / `xQueueReceive` | ✓ Ausente | Somente `xTaskNotifyFromISR` |
| `xSemaphoreTake` / mutex | ✓ Ausente | ISR nunca adquire mutex |
| Ponto flutuante pesado | ✓ Ausente | Zero float; só int32/uint32 |
| Funções em Flash | ✓ Ausente | `IRAM_ATTR` + `CONFIG_GPIO_CTRL_FUNC_IN_IRAM=y` |
| `gptimer_stop()` da ISR | ✓ Removido | Bloco v2: simplesmente não re-arma |

---

## BUG CRÍTICO IDENTIFICADO: Contador do GPTimer não resetado antes de start_block

### Problema

Em `step_generator_start_block()`, a sequência atual é:

```c
gptimer_stop(g_gptimer);
// ... escreve g_isr_ctx ...
gptimer_alarm_config_t alarm = {
    .alarm_count = block->initial_period_us,  // valor ABSOLUTO
    ...
};
gptimer_set_alarm_action(g_gptimer, &alarm);
gptimer_start(g_gptimer);
```

No ESP-IDF v5, `gptimer_start()` NÃO reseta o contador. O contador continua
do valor em que estava quando `gptimer_stop()` foi chamado.

**Cenário de falha:**
```
Bloco anterior concluiu com counter = 850.000 µs (timer não re-armou)
Próximo bloco: initial_period_us = 7071
alarm_count = 7071

Timer retoma do counter = 850.000
Próximo alarme dispara quando counter = 7071 → JÁ PASSOU
→ Timer dispara imediatamente (ou nunca, dependendo do overflow de 64 bits)
→ Primeiro passo acontece em t ≈ 0, não em t = 7071µs
→ Motor tenta arrancar na velocidade máxima sem aceleração → perde passos
```

### Correção obrigatória para Etapa 5

Adicionar `gptimer_set_raw_count(g_gptimer, 0)` após `gptimer_stop()`:

```c
void step_generator_start_block(const motion_block_t *block) {
    gptimer_stop(g_gptimer);
    gptimer_set_raw_count(g_gptimer, 0);   // ← CORREÇÃO
    // ... spinlock, escreve g_isr_ctx ...
    gptimer_alarm_config_t alarm = {
        .alarm_count = block->initial_period_us,
        ...
    };
    gptimer_set_alarm_action(g_gptimer, &alarm);
    gptimer_start(g_gptimer);
}
```

Após reset, o contador começa em 0 e o primeiro alarme em `initial_period_us` é correto.

O re-arme na ISR usa:
```c
next_alarm.alarm_count = edata->count_value + g_isr_ctx.current_period;
```
`edata->count_value` é o valor do contador no momento do alarme, então o próximo
alarme é sempre `current_period` ticks após o atual — correto independentemente do
valor absoluto do contador. ✓

---

## PONTO DE ATENÇÃO 1: `portENTER_CRITICAL` no Executor — single-core vs. SMP

A sequência em `step_generator_start_block()` usa `portENTER_CRITICAL(&s_isr_mux)`.

No ESP-IDF, `portENTER_CRITICAL` com spinlock funciona corretamente em SMP:
- No Core 1 (Executor): adquire o spinlock E desabilita interrupções locais do Core 1.
- Impede que a ISR do GPTimer (também no Core 1) interrompa a escrita de g_isr_ctx.

Isso é correto. A proteção via spinlock é necessária em ambiente SMP porque:
1. A ISR pode ser disparada pelo Core 1 enquanto o Executor (também Core 1) está escrevendo.
2. O spinlock garante que ambos nunca rodam simultaneamente.

**Verificação de segurança:** `gptimer_stop()` é chamado ANTES do `portENTER_CRITICAL`.
Após `gptimer_stop()`, o hardware de timer para de disparar interrupções.
O `portENTER_CRITICAL` é então uma garantia adicional (belt-and-suspenders approach).

---

## PONTO DE ATENÇÃO 2: Homing usa polling de GPIO na task — não usa ISR

O stub do homing usa:
```c
while (!hal_endstop_read_x() && steps < HOMING_MAX_TRAVEL_STEPS) {
    hal_stepper_step(AXIS_X);
    esp_rom_delay_us(period_homing);
    steps++;
}
```

Isso roda inteiramente no Executor task (blocking loop), sem usar GPTimer.
Implicações:
1. Durante o homing, a MotionExecutorTask NÃO está bloqueada em `xTaskNotifyWait`.
   Ela está em um while loop — o scheduler não pode preemptá-la se a prioridade 4
   for a mais alta em Core 1. Isso é correto: queremos exclusividade durante homing.
2. `hal_stepper_step()` é IRAM_ATTR, mas aqui está sendo chamada de task context — OK.
3. `esp_rom_delay_us()` em task context consome CPU (spinning) — aceitável para homing
   que ocorre raramente e em velocidade baixa.
4. O endstop é verificado por polling — suficiente para a velocidade de homing (300mm/min).

---

## Checklist final pré-implementação

| Item | Status |
|------|--------|
| motion_block_t completa e consistente | ✓ |
| Campos ISR-only identificados | ✓ |
| Zero float na ISR | ✓ |
| Bresenham verificado com exemplo | ✓ |
| Transições de fase sem deadband/overlap problemático | ✓ |
| Atualização de mpos após bloco (não durante) | ✓ |
| M114 comportamento documentado como limitação aceita | ✓ |
| WCET da ISR calculado: ~6µs vs MIN_PERIOD=10µs (margem 1,67×) | ✓ |
| Zero proibições na ISR | ✓ |
| **BUG CRÍTICO: gptimer_set_raw_count(0) ausente** | ⚠️ CORRIGIR |
| Rampa linear ≠ aceleração constante — documentado e aceito | ✓ |
| Assimetria de 1 passo em DECEL — documentado e negligível | ✓ |

---

## Decisão

**Aprovado para Etapa 5.** O único item obrigatório antes de codificar é incorporar
`gptimer_set_raw_count(g_gptimer, 0)` em `step_generator_start_block()`. Os demais
pontos são documentados e aceitos para o escopo educacional do projeto.
