# Diagrama de Tarefas FreeRTOS — v2

## 1. Mapa de Tarefas

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                     TAREFAS FREERTOS — v2 (5 tarefas)                       │
│                                                                             │
│  ─── CORE 0 (tskNO_AFFINITY — SMP scheduler decide) ────────────────────   │
│                                                                             │
│  Prioridade 1 (background)                                                  │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │  MonitorTask                                                        │   │
│  │  Stack: 2048  |  Período: ~1000ms                                   │   │
│  │  • Verifica uxQueueSpacesAvailable(planner_queue) — alerta overflow │   │
│  │  • Detecta starvation: Executor parado > timeout com fila não vazia │   │
│  │  • Sinaliza EVENT_ALARM se detectar anomalia                        │   │
│  │  • NÃO responde ao '?' (removido da v1)                             │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                             │
│  Prioridade 2                                                               │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │  UARTTask                                                           │   │
│  │  Stack: 2048                                                        │   │
│  │  • Lê UART byte a byte (bloqueante)                                 │   │
│  │  • Para cada byte: verifica se é '?' ANTES de acumular no buffer   │   │
│  │    → '?' : adquire state_mutex (5ms), formata status, envia via     │   │
│  │             uart_tx_mutex. NÃO enfileira. Continua lendo.          │   │
│  │  • Acumula bytes até '\n' → envia string para cmd_queue            │   │
│  │  • xQueueSend com timeout 0: se cmd_queue cheia, descarta linha    │   │
│  │    (comportamento correto: host não deveria enviar sem 'ok')        │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                             │
│  Prioridade 3                                                               │
│  ┌──────────────────────────┐   ┌──────────────────────────────────────┐   │
│  │  GCodeParserTask         │   │  MotionPlannerTask                   │   │
│  │  Stack: 4096             │   │  Stack: 4096                         │   │
│  │                          │   │                                      │   │
│  │  Consome: cmd_queue      │   │  Consome: motion_queue               │   │
│  │  Produz:                 │   │  Produz:  planner_queue              │   │
│  │  • motion_queue          │   │                                      │   │
│  │    (G0/G1/G28/M3/M5)     │   │  • Converte mm → passos             │   │
│  │  • UART TX direto        │   │  • Calcula Bresenham                 │   │
│  │    (ok/error/M114)       │   │  • Calcula trapezoidal               │   │
│  │                          │   │  • Preenche extruder_action          │   │
│  │  Bloqueia:               │   │  • Envia via portMAX_DELAY           │   │
│  │  cmd_queue portMAX_DELAY │   │                                      │   │
│  │                          │   │  Bloqueia:                           │   │
│  │  M3/M5: cria motion_cmd  │   │  motion_queue portMAX_DELAY          │   │
│  │  com extruder_action     │   │  planner_queue portMAX_DELAY         │   │
│  │  type=CMD_EXTRUDER_ONLY  │   │                                      │   │
│  └──────────────────────────┘   └──────────────────────────────────────┘   │
│                                                                             │
│  ─── CORE 1 (xTaskCreatePinnedToCore, core=1) ──────────────────────────   │
│                                                                             │
│  Prioridade 4 (máxima userspace — tempo real)                               │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │  MotionExecutorTask  (Core 1 fixo)                                  │   │
│  │  Stack: 4096                                                        │   │
│  │                                                                     │   │
│  │  Consome: planner_queue                                             │   │
│  │                                                                     │   │
│  │  Para cada bloco:                                                   │   │
│  │  1. Aplica extruder_action → hal_extruder_on/off() + state         │   │
│  │  2. Configura GPIO DIR X e Y                                        │   │
│  │  3. Habilita driver (EN_PIN)                                        │   │
│  │  4. gptimer_stop() → seção crítica: escreve g_isr_ctx               │   │
│  │  5. gptimer_start() com initial_period_us                           │   │
│  │  6. xTaskNotifyWait(BLOCK_DONE | ALARM, portMAX_DELAY)  ← BLOQUEIA │   │
│  │  7. Atualiza g_state.mpos via state_mutex                           │   │
│  │  8. Se planner_queue vazia: g_state.status = IDLE                  │   │
│  │  9. Loop                                                            │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                             │
│  ISR (IRAM_ATTR — associada ao Core 1 via GPTimer)                          │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │  gptimer_isr_callback                                               │   │
│  │  • Lê g_isr_ctx (sem lock — Executor garante exclusão via stop/start)│  │
│  │  • Bresenham: avança eixo dominante, condicionalmente subordinado   │   │
│  │  • GPIO: set STEP → esp_rom_delay_us(2) → clear STEP               │   │
│  │  • Trapezoidal: atualiza current_period_us por fase                 │   │
│  │  • step_count++                                                     │   │
│  │  • Se step_count == total_steps:                                    │   │
│  │    → gptimer_stop() (dentro da própria ISR — suportado no ESP-IDF) │   │
│  │    → xTaskNotifyFromISR(executor_handle, BLOCK_DONE, ...)           │   │
│  │  • Senão: gptimer_alarm_config_t com new_period → re-arma           │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────────────────────┘
```

## 2. Ciclo de Vida v2

```
app_main() [Core 0]
    │
    ├── hal_stepper_init()
    ├── hal_endstop_init()
    ├── hal_extruder_init()
    ├── uart_driver_install(...)
    │
    ├── Cria primitivas FreeRTOS:
    │   ├── cmd_queue      = xQueueCreate(10, 96)
    │   ├── motion_queue   = xQueueCreate(8,  sizeof(motion_cmd_t))
    │   ├── planner_queue  = xQueueCreate(16, sizeof(motion_block_t))
    │   ├── state_mutex    = xSemaphoreCreateMutex()
    │   ├── uart_tx_mutex  = xSemaphoreCreateMutex()
    │   └── motion_event_group = xEventGroupCreate()
    │
    ├── Inicializa g_state: { IDLE, 0.0, 0.0, DEFAULT_FEEDRATE, false, true }
    │
    ├── xTaskCreate(uart_task,    2048, Prio 2)
    ├── xTaskCreate(parser_task,  4096, Prio 3)
    ├── xTaskCreate(planner_task, 4096, Prio 3)
    ├── xTaskCreate(monitor_task, 2048, Prio 1)
    └── xTaskCreatePinnedToCore(executor_task, 4096, Prio 4, core=1)
        │
        └── [dentro do executor_task, após iniciar]:
            gptimer_new_timer() → gptimer_register_event_callbacks()
            → gptimer_enable() → (timer pronto, aguarda blocos)

    app_main → vTaskDelete(NULL)
    [FreeRTOS scheduler toma controle]
```

## 3. Responsabilidades Detalhadas por Tarefa

### UARTTask
| Aspecto | Detalhe |
|---------|---------|
| Produz | `char[96]` em `cmd_queue` |
| Consome | Bytes do UART ring buffer |
| Resposta ao '?' | Imediata — não vai para cmd_queue |
| Timeout send | 0 (não bloqueia — descarta se fila cheia) |
| Bloqueia em | `uart_read_bytes(..., portMAX_DELAY)` |

### GCodeParserTask
| Aspecto | Detalhe |
|---------|---------|
| Produz | `motion_cmd_t` em `motion_queue` |
| Consome | `char[96]` de `cmd_queue` |
| Comandos tratados | G0, G1, G28, G90, G91, M3, M5, M114, F |
| ok/error | Enviados via `uart_tx_mutex` após enfileirar |
| Timeout send | `portMAX_DELAY` — back-pressure correto |
| M3/M5 sem XY | `CMD_EXTRUDER_ONLY` com posição atual |

### MotionPlannerTask
| Aspecto | Detalhe |
|---------|---------|
| Produz | `motion_block_t` em `planner_queue` |
| Consome | `motion_cmd_t` de `motion_queue` |
| Cálculos | Bresenham, trapezoidal, conversão mm→steps |
| Bloco extrusor | `total_steps=0`, `extruder_action` preenchido |
| Timeout send | `portMAX_DELAY` — bloqueia se planner cheio |

### MotionExecutorTask (Core 1)
| Aspecto | Detalhe |
|---------|---------|
| Produz | Sinais de evento em `motion_event_group` |
| Consome | `motion_block_t` de `planner_queue` |
| Cria GPTimer | Dentro da própria task (garante ISR no Core 1) |
| Extrusor | `hal_extruder_on/off()` antes de cada bloco |
| Bloqueia em | `xTaskNotifyWait(portMAX_DELAY)` |

### MonitorTask
| Aspecto | Detalhe |
|---------|---------|
| Produz | `EVENT_ALARM` se detectar anomalia |
| Consome | Estado das filas (polling), `state_mutex` |
| Período | `vTaskDelay(pdMS_TO_TICKS(1000))` |
| Responsabilidade | Watchdog de saúde — não interfere no fluxo |
