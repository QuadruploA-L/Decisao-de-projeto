# Arquitetura Geral — Firmware XY G-Code (ESP32 + FreeRTOS)

## 1. Visão Sistêmica

O firmware implementa um pipeline de processamento de G-Code em camadas, onde cada camada se comunica
com a próxima exclusivamente por primitivas FreeRTOS (queues, semáforos, event groups).
Nenhuma tarefa acessa diretamente o hardware; toda interação com periféricos passa pela HAL.

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                          FIRMWARE XY G-CODE ESP32                           │
│                                                                             │
│   ┌─────────────────────────────────────────────────────────────────────┐   │
│   │                        CAMADA DE APLICAÇÃO                          │   │
│   │                                                                     │   │
│   │  ┌──────────┐  ┌──────────────┐  ┌──────────────┐  ┌───────────┐  │   │
│   │  │ UARTTask │  │GCodeParser   │  │MotionPlanner │  │ Monitor   │  │   │
│   │  │          │  │Task          │  │Task          │  │Task       │  │   │
│   │  └────┬─────┘  └──────┬───────┘  └──────┬───────┘  └───────────┘  │   │
│   │       │               │                  │                          │   │
│   │  ┌────▼───────────────▼──────────────────▼──────────────────────┐  │   │
│   │  │              CAMADA DE COMUNICAÇÃO (FreeRTOS IPC)             │  │   │
│   │  │   cmd_queue    motion_queue    status_semaphore   event_group  │  │   │
│   │  └────────────────────────┬──────────────────────────────────────┘  │   │
│   │                           │                                          │   │
│   │  ┌────────────────────────▼──────────────────────────────────────┐  │   │
│   │  │                     CAMADA DE EXECUÇÃO                        │  │   │
│   │  │                                                               │  │   │
│   │  │  ┌──────────────────┐          ┌──────────────────────────┐  │  │   │
│   │  │  │ MotionExecutor   │          │      ExtruderTask        │  │  │   │
│   │  │  │ Task             │          │                          │  │  │   │
│   │  │  └────────┬─────────┘          └───────────┬──────────────┘  │  │   │
│   │  └───────────┼────────────────────────────────┼─────────────────┘  │   │
│   └─────────────────────────────────────────────────────────────────────┘  │
│               │                                    │                        │
│   ┌───────────▼────────────────────────────────────▼───────────────────┐   │
│   │                        CAMADA HAL                                   │   │
│   │                                                                     │   │
│   │  ┌───────────────────┐   ┌──────────────────┐  ┌───────────────┐  │   │
│   │  │  hal_stepper.h    │   │  hal_endstop.h   │  │hal_extruder.h │  │   │
│   │  │  (A4988 / DRV8825)│   │  (GPIO input)    │  │(GPIO output)  │  │   │
│   │  └───────────────────┘   └──────────────────┘  └───────────────┘  │   │
│   └─────────────────────────────────────────────────────────────────────┘   │
│               │                                                              │
│   ┌───────────▼─────────────────────────────────────────────────────────┐   │
│   │                      HARDWARE ESP32                                  │   │
│   │  GPTimer(ISR)  GPIO(STEP/DIR/EN)  GPIO(Endstop)  UART0(USB-Serial)  │   │
│   └─────────────────────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────────────────────┘
```

## 2. Princípios de Design

| Princípio | Decisão | Justificativa |
|-----------|---------|---------------|
| Isolamento de hardware | HAL obrigatória | Troca de driver (A4988↔DRV8825) sem alterar lógica |
| Comunicação assíncrona | Apenas FreeRTOS IPC | Elimina dependências temporais entre tarefas |
| Sem polling em ISR | GPTimer para passos | `vTaskDelay` bloquearia o scheduler |
| Planejamento separado da execução | Planner ≠ Executor | Matemática pesada não interfere no tempo real |
| Estado centralizado | `system_state_t` global protegido por mutex | Monitoramento e resposta GRBL consistentes |

## 3. Fluxo de Dados Principal

```
Serial IN  →  [cmd_queue]  →  GCodeParser  →  [motion_queue]  →  MotionPlanner
                                           →  [extruder_queue] →  ExtruderTask
                                                                        ↓
                          MotionPlanner  →  [block_queue]  →  MotionExecutor
                                                                        ↓
                                                              GPTimer ISR
                                                                        ↓
                                                           HAL_Stepper (STEP/DIR)
```

## 4. Núcleo de Execução: GPTimer ISR

O ponto mais crítico do sistema é a ISR do GPTimer. Ela:
1. Lê o bloco de movimento atual do MotionExecutor
2. Aplica o algoritmo de Bresenham para decidir qual eixo avança
3. Atualiza o acumulador de aceleração trapezoidal
4. Reprograma o próximo alarme do GPTimer com o novo `step_period`
5. Gera os pulsos STEP via GPIO

Toda essa lógica deve ser executada em IRAM (`IRAM_ATTR`) para zero latência de cache.
