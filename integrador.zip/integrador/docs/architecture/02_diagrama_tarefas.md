# Diagrama de Tarefas FreeRTOS

## 1. Mapa de Tarefas

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                        TAREFAS FREERTOS                                     │
│                                                                             │
│  Prioridade 1 (mais baixa)                                                  │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │  MonitorTask                                                        │   │
│  │  Core: 0  |  Stack: 2048  |  Período: 500ms                        │   │
│  │  • Lê system_state (mutex)                                          │   │
│  │  • Reporta via Serial se solicitado (comando '?')                   │   │
│  │  • Checa overflow de filas                                          │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                             │
│  Prioridade 2                                                               │
│  ┌──────────────────────────┐   ┌──────────────────────────────────────┐   │
│  │  UARTTask                │   │  ExtruderTask                        │   │
│  │  Core: 0  |  Stack: 2048 │   │  Core: 0  |  Stack: 1024            │   │
│  │  • Lê UART byte a byte   │   │  • Aguarda extruder_queue            │   │
│  │  • Acumula linha         │   │  • Liga/desliga GPIO extrusor        │   │
│  │  • Envia cmd_queue       │   │  • Atualiza extruder_state           │   │
│  └──────────────────────────┘   └──────────────────────────────────────┘   │
│                                                                             │
│  Prioridade 3                                                               │
│  ┌──────────────────────────┐   ┌──────────────────────────────────────┐   │
│  │  GCodeParserTask         │   │  MotionPlannerTask                   │   │
│  │  Core: 0  |  Stack: 4096 │   │  Core: 0  |  Stack: 4096            │   │
│  │  • Consome cmd_queue     │   │  • Consome motion_queue              │   │
│  │  • Parseia G-Code        │   │  • Calcula bloco trapezoidal         │   │
│  │  • Emite motion_queue    │   │  • Calcula Bresenham parameters      │   │
│  │  • Emite extruder_queue  │   │  • Emite block_queue                 │   │
│  │  • Responde ok/error     │   │                                      │   │
│  └──────────────────────────┘   └──────────────────────────────────────┘   │
│                                                                             │
│  Prioridade 4 (mais alta — tempo real)                                      │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │  MotionExecutorTask                                                 │   │
│  │  Core: 1  |  Stack: 4096  |  Prioridade máxima userspace           │   │
│  │  • Consome block_queue                                              │   │
│  │  • Inicializa GPTimer com primeiro step_period                      │   │
│  │  • Aguarda EVENT_BLOCK_DONE do event_group                          │   │
│  │  • Atualiza system_state (posição, estado)                          │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                             │
│  ISR (fora do scheduler — IRAM)                                             │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │  gptimer_isr_callback (IRAM_ATTR)                                   │   │
│  │  • Bresenham step de um ciclo                                       │   │
│  │  • Atualiza acumulador de aceleração                                │   │
│  │  • Reprograma alarme GPTimer                                        │   │
│  │  • GPIO: pulso STEP (set → clear)                                   │   │
│  │  • Ao fim do bloco: notifica MotionExecutor via xTaskNotifyFromISR  │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────────────────────┘
```

## 2. Afinidade de Núcleo (Dual-Core ESP32)

| Tarefa | Núcleo | Razão |
|--------|--------|-------|
| UARTTask | Core 0 | I/O não crítico, compartilha com WiFi stack (se usado) |
| GCodeParserTask | Core 0 | CPU-bound leve, sem requisito de tempo real |
| MotionPlannerTask | Core 0 | Matemática pesada que não interfere no executor |
| ExtruderTask | Core 0 | Controle simples, baixa frequência |
| MonitorTask | Core 0 | Background, baixa prioridade |
| MotionExecutorTask | Core 1 | **Isolado** — sem concorrência com tarefas de Core 0 |
| GPTimer ISR | Core 1 | Mesma afinidade que o Executor para coerência de cache |

## 3. Ciclo de Vida das Tarefas

```
app_main()
    │
    ├── Inicializa HAL (GPIO, UART, GPTimer)
    ├── Cria todas as filas e semáforos
    ├── Cria event_group
    ├── Inicializa system_state (IDLE)
    │
    ├── xTaskCreatePinnedToCore(UARTTask,         Core 0, Prio 2)
    ├── xTaskCreatePinnedToCore(GCodeParserTask,  Core 0, Prio 3)
    ├── xTaskCreatePinnedToCore(MotionPlannerTask,Core 0, Prio 3)
    ├── xTaskCreatePinnedToCore(MotionExecutorTask,Core 1, Prio 4)
    ├── xTaskCreatePinnedToCore(ExtruderTask,     Core 0, Prio 2)
    ├── xTaskCreatePinnedToCore(MonitorTask,      Core 0, Prio 1)
    │
    └── vTaskDelete(NULL)  ← app_main encerra, scheduler toma controle
```

## 4. Descrição Detalhada de Cada Tarefa

### UARTTask
- **Produz**: strings de comando em `cmd_queue`
- **Consome**: bytes do buffer UART (via `uart_read_bytes`)
- **Comportamento**: acumula bytes até `\n`, envia string completa para `cmd_queue`
- **Bloqueia em**: `uart_read_bytes` com timeout `portMAX_DELAY`

### GCodeParserTask
- **Produz**: `motion_cmd_t` em `motion_queue`, `extruder_cmd_t` em `extruder_queue`
- **Consome**: strings de `cmd_queue`
- **Comportamento**: tokeniza linha, identifica letra+número (G0/G1/G28/M3/M5/F/?), preenche struct
- **Bloqueia em**: `xQueueReceive(cmd_queue, ..., portMAX_DELAY)`
- **Responde**: `ok\n` ou `error\n` via UART diretamente

### MotionPlannerTask
- **Produz**: `motion_block_t` em `block_queue`
- **Consome**: `motion_cmd_t` de `motion_queue`
- **Comportamento**: converte coordenadas → passos, calcula perfil trapezoidal, parâmetros Bresenham
- **Bloqueia em**: `xQueueReceive(motion_queue, ..., portMAX_DELAY)`

### MotionExecutorTask
- **Produz**: notificações de evento `EVENT_BLOCK_DONE`
- **Consome**: `motion_block_t` de `block_queue`
- **Comportamento**: inicializa ISR com parâmetros do bloco, aguarda conclusão, atualiza posição
- **Bloqueia em**: `xTaskNotifyWait` aguardando ISR completar o bloco

### ExtruderTask
- **Produz**: nada (efeito colateral no GPIO)
- **Consome**: `extruder_cmd_t` de `extruder_queue`
- **Comportamento**: liga ou desliga GPIO do extrusor, atualiza estado

### MonitorTask
- **Produz**: respostas GRBL `<State|MPos:x,y>` via UART
- **Consome**: `status_request_flag` (semáforo binário), lê `system_state` via mutex
- **Comportamento**: ativado pelo comando `?` parseado pelo GCodeParser
