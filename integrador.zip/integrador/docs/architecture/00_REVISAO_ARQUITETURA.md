# Revisão da Arquitetura — Checklist pré-implementação

## Resultado: APROVADA ✓

Este documento registra a revisão da arquitetura antes de iniciar qualquer implementação.

---

## 1. Checklist de Requisitos do Projeto

| Requisito | Abordado | Onde |
|-----------|----------|------|
| ESP32 + ESP-IDF | ✓ | config.h, CMakeLists.txt raiz |
| Motores X e Y (A4988/DRV8825) | ✓ | hal/hal_stepper.h, config.h STEPPER_DRIVER |
| Camada HAL trocável por config | ✓ | #ifdef em hal_stepper.c |
| Extrusor ON/OFF (M3/M5) | ✓ | hal_extruder, ExtruderTask, extruder_queue |
| Fim de curso X e Y | ✓ | hal_endstop.h, MotionExecutor (homing) |
| USB Serial (UART) | ✓ | UARTTask + grbl_protocol |
| G0, G1 | ✓ | GCodeParser → motion_cmd_t CMD_MOVE_G0/G1 |
| G28 (homing) | ✓ | GCodeParser → CMD_HOMING → MotionExecutor |
| M3, M5 | ✓ | GCodeParser → extruder_queue |
| F (feedrate) | ✓ | motion_cmd_t.feedrate |
| G90/G91 | ✓ | system_state.position_absolute |
| Resposta GRBL '?' | ✓ | MonitorTask + status_semaphore |
| Estados Idle/Run/Alarm/Homing | ✓ | machine_state_t enum |
| ok / error | ✓ | grbl_protocol.c |
| FreeRTOS — 6 tarefas | ✓ | tasks/ (UART, Parser, Planner, Executor, Extruder, Monitor) |
| Queues | ✓ | cmd_q, motion_q, extruder_q, block_q |
| Semáforos | ✓ | status_semaphore (binário) |
| Event Groups | ✓ | motion_event_group (4 bits) |
| Mutex | ✓ | state_mutex |
| Sem vTaskDelay para passos | ✓ | GPTimer ISR justificada |
| GPTimer ou RMT | ✓ | GPTimer escolhido + justificativa |
| Interpolação linear XY | ✓ | Bresenham documentado com exemplo numérico |
| Bresenham ou equivalente | ✓ | Implementação completa em 05_matematica |
| Aceleração trapezoidal | ✓ | Equações + aproximação de Olds |
| Estrutura de diretórios | ✓ | 06_estrutura_diretorios.md |
| Comentários Doxygen | ✓ | (planejados para Etapa 7) |
| Dual-core ESP32 | ✓ | Executor no Core 1, demais no Core 0 |

---

## 2. Decisões Arquiteturais Críticas — Revisão

### 2.1 GPTimer (não RMT) — CORRETO
**Motivo validado**: O período de step muda a cada ciclo durante aceleração/desaceleração.
O RMT exigiria reconstruir o buffer inteiro a cada mudança, adicionando latência imprevisível.
O GPTimer re-arma o alarme na própria ISR com o novo período — O(1) por ciclo.

**Risco identificado**: A ISR do GPTimer roda no Core onde o timer foi criado.
O GPTimer deve ser criado pela MotionExecutorTask (Core 1) para garantir afinidade.
**Mitigação**: Documentado no task_motion_executor.c.

### 2.2 Bresenham inteiro — CORRETO
**Motivo validado**: Sem `float` na ISR. O ESP32 tem FPU, mas operações float na ISR
aumentam o tempo de serviço e risco de preemção. Aritmética inteira é determinística.

**Limitação conhecida**: O Bresenham puro não faz arcos (G2/G3). Este projeto não requer.

### 2.3 Planner separado do Executor — CORRETO
**Motivo validado**: Bresenham + trapezoidal envolve divisões e sqrt.
Rodar isso no Planner (Core 0, prioridade 3) não afeta o tempo real do Executor (Core 1, prio 4).

**Risco identificado**: block_queue tem capacidade 3.
Se o Planner for mais lento que o Executor (movimento muito curto com baixa aceleração),
o Executor ficará aguardando. Isso é correto — é back-pressure.

### 2.4 Notificação ISR → Task (xTaskNotifyFromISR) — CORRETO
**Motivo validado**: Mais leve que semáforo. A notificação carrega um valor de 32 bits,
permitindo passar o motivo (BLOCK_DONE vs ALARM) em um único mecanismo.

### 2.5 Mutex para system_state — CORRETO
**Risco identificado**: MonitorTask lê state com `state_mutex` — OK.
MotionExecutor escreve posição após bloco concluir — OK.
**Cuidado**: NUNCA tentar adquirir state_mutex dentro da ISR.
A ISR usa um ponteiro para o bloco atual (`g_isr_ctx`) que é atualizado com seção crítica
(`portENTER_CRITICAL_ISR`) antes de iniciar o GPTimer — padrão seguro.

---

## 3. Análise de Pior Caso (WCET)

### ISR do GPTimer
Operações por ciclo:
1. Bresenham: 3 comparações + 2 adições = ~10 ciclos de CPU
2. Atualização trapezoidal: 1 comparação + 1 adição = ~5 ciclos
3. GPIO set/clear: 2 `gpio_set_level` = ~20 ciclos (via GPIO matrix)
4. GPTimer re-arm: 1 chamada = ~30 ciclos
5. Verificação de fim de bloco: 1 comparação = ~3 ciclos
6. Total estimado: ~70 ciclos @ 240MHz = ~300ns

Período mínimo do timer: 333µs (3000 steps/s) >> 300ns → margem de 1000x. ✓

### Latência de resposta ao comando '?'
1. UARTTask recebe '?' → cmd_queue: ~1ms (UART + fila)
2. GCodeParser processa: ~100µs
3. MonitorTask acorda: ~1ms (contexto switch)
4. UART TX: ~200µs (20 bytes @ 115200 bps)
Total: ~2-3ms — aceitável para polling de status.

---

## 4. Pontos de Atenção para a Implementação

1. **IRAM_ATTR obrigatório** em `gptimer_isr_callback` e em todas as funções
   chamadas por ela (hal_stepper_step, etc.)

2. **Seção crítica vs portENTER_CRITICAL_ISR**: dentro da ISR usar `portENTER_CRITICAL_ISR`;
   nas tasks usar `portENTER_CRITICAL` (taskENTER_CRITICAL).

3. **GPIO pulse width**: A4988 exige mínimo 1µs de HIGH no STEP.
   DRV8825 exige 1.9µs. Usar `esp_rom_delay_us(2)` entre set e clear (IRAM-safe).

4. **Homing sem interrupção de GPIO**: Para simplificar, usar polling de endstop
   dentro da MotionExecutorTask durante a fase de homing (movimento lento).
   Velocidade de homing: 10% do feedrate máximo.

5. **Re-entrância do parser**: GCodeParserTask processa uma linha por vez;
   não há re-entrância. Estado de posição absoluta/relativa é protegido pelo mutex.

6. **Inicialização de ordem**: app_main() deve criar filas e semáforos ANTES
   das tarefas. Tasks não devem iniciar antes de todos os objetos existirem.

---

## 5. O que NÃO é implementado (escopo reduzido intencional)

| Funcionalidade | Motivo da omissão |
|----------------|-------------------|
| G2/G3 (arcos) | Requer interpolação circular — fora do escopo |
| G4 (dwell/pausa) | Não solicitado |
| G17/18/19 (plano de trabalho) | Sistema 2D apenas |
| Buffer lookahead (como GRBL) | Simplificado — block_queue com 3 blocos |
| Jerk/junction velocity | Perfil trapezoidal simples (v_entry=0) |
| Soft limits | Não solicitado |
| WiFi / BLE | Não solicitado |
| SD Card | Não solicitado |

---

## Conclusão

A arquitetura cobre todos os requisitos do projeto.
As decisões de design são justificadas e os riscos identificados têm mitigações documentadas.

**Próximo passo: Etapa 2 — Implementação dos módulos base (HAL, Tasks, Filas).**
