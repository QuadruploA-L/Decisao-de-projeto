# Estrutura de Diretórios do Projeto

## 1. Árvore Completa

```
xy_gcode_firmware/
│
├── CMakeLists.txt                   ← Raiz do projeto ESP-IDF
├── sdkconfig.defaults               ← Configurações padrão do menuconfig
├── partitions.csv                   ← Tabela de partições (opcional)
│
├── main/
│   ├── CMakeLists.txt
│   └── main.c                       ← Ponto de entrada: app_main()
│                                       Inicializa HAL, cria filas/semáforos,
│                                       cria tarefas, deleta a si mesmo
│
├── components/
│   │
│   ├── config/
│   │   ├── CMakeLists.txt
│   │   └── include/
│   │       └── config.h             ← Todas as constantes configuráveis:
│   │                                   STEPS_PER_MM_X/Y, ACCELERATION,
│   │                                   MAX_FEEDRATE, GPIO pins, UART port,
│   │                                   tamanhos de filas, stack sizes
│   │
│   ├── hal/
│   │   ├── CMakeLists.txt
│   │   ├── include/
│   │   │   ├── hal_stepper.h        ← Interface da HAL de motores de passo
│   │   │   ├── hal_endstop.h        ← Interface da HAL de fim de curso
│   │   │   └── hal_extruder.h       ← Interface da HAL do extrusor
│   │   └── src/
│   │       ├── hal_stepper.c        ← Implementação: init/step/dir/enable
│   │       │                           Seleção A4988 vs DRV8825 via #ifdef
│   │       ├── hal_endstop.c        ← Leitura de GPIO com debounce
│   │       └── hal_extruder.c       ← Set/clear GPIO extrusor
│   │
│   ├── gcode/
│   │   ├── CMakeLists.txt
│   │   ├── include/
│   │   │   ├── gcode_parser.h       ← Interface do parser
│   │   │   └── gcode_types.h        ← Tipos: motion_cmd_t, extruder_cmd_t,
│   │   │                               gcode_word_t, position_mode_t
│   │   └── src/
│   │       └── gcode_parser.c       ← Tokenização, extração de palavras G-Code
│   │
│   ├── planner/
│   │   ├── CMakeLists.txt
│   │   ├── include/
│   │   │   ├── motion_planner.h     ← Interface do planejador
│   │   │   └── motion_block.h       ← Tipo motion_block_t
│   │   └── src/
│   │       └── motion_planner.c     ← Cálculo Bresenham + trapezoidal
│   │
│   ├── executor/
│   │   ├── CMakeLists.txt
│   │   ├── include/
│   │   │   └── motion_executor.h    ← Interface do executor
│   │   └── src/
│   │       ├── motion_executor.c    ← Lógica da MotionExecutorTask
│   │       └── step_generator.c     ← ISR do GPTimer (IRAM_ATTR)
│   │                                   Contexto global da ISR
│   │
│   ├── protocol/
│   │   ├── CMakeLists.txt
│   │   ├── include/
│   │   │   └── grbl_protocol.h      ← Interface: respostas ok/error/status
│   │   └── src/
│   │       └── grbl_protocol.c      ← Formata e envia strings GRBL via UART
│   │
│   ├── system/
│   │   ├── CMakeLists.txt
│   │   ├── include/
│   │   │   └── system_state.h       ← system_state_t, mutex, event group
│   │   │                               handles globais das filas
│   │   └── src/
│   │       └── system_state.c       ← Inicialização do estado global
│   │
│   └── tasks/
│       ├── CMakeLists.txt
│       ├── include/
│       │   ├── task_uart.h
│       │   ├── task_gcode_parser.h
│       │   ├── task_motion_planner.h
│       │   ├── task_motion_executor.h
│       │   ├── task_extruder.h
│       │   └── task_monitor.h
│       └── src/
│           ├── task_uart.c          ← UARTTask
│           ├── task_gcode_parser.c  ← GCodeParserTask
│           ├── task_motion_planner.c← MotionPlannerTask
│           ├── task_motion_executor.c← MotionExecutorTask
│           ├── task_extruder.c      ← ExtruderTask
│           └── task_monitor.c       ← MonitorTask
│
└── docs/
    ├── architecture/                ← Documentos desta etapa (você está aqui)
    │   ├── 01_visao_geral.md
    │   ├── 02_diagrama_tarefas.md
    │   ├── 03_diagrama_filas.md
    │   ├── 04_fluxograma_gcode.md
    │   ├── 05_matematica_movimento.md
    │   └── 06_estrutura_diretorios.md
    ├── manual_tecnico.md            ← Gerado na Etapa 7
    ├── manual_usuario.md            ← Gerado na Etapa 7
    └── freertos_usage.md            ← Gerado na Etapa 7
```

## 2. Justificativa de Cada Módulo

| Módulo | Responsabilidade | Não faz |
|--------|-----------------|---------|
| `config/` | Centraliza todos os `#define` configuráveis | Nenhuma lógica |
| `hal/` | Abstrai o hardware específico | Não conhece G-Code nem FreeRTOS |
| `gcode/` | Parseia strings em structs | Não planeja movimento nem acessa hardware |
| `planner/` | Matemática de trajetória | Não acessa hardware, não conhece UART |
| `executor/` | Execução em tempo real via GPTimer ISR | Não parseia G-Code |
| `protocol/` | Formata respostas GRBL | Não toma decisões de estado |
| `system/` | Estado compartilhado protegido | Nenhuma lógica de negócio |
| `tasks/` | Glue code FreeRTOS | Apenas coordena módulos acima |
| `main/` | Bootstrap | Apenas cria tasks e deleta a si mesmo |

## 3. Diagrama de Dependências entre Módulos

```
main
 └── tasks
      ├── task_uart          → protocol, system
      ├── task_gcode_parser  → gcode, protocol, system
      ├── task_motion_planner→ planner, system
      ├── task_motion_executor→executor, hal, system
      ├── task_extruder      → hal, system
      └── task_monitor       → protocol, system

executor
 └── step_generator (ISR)   → hal (stepper), system (ISR-safe reads only)

planner   → config, gcode_types
gcode     → config, gcode_types
hal       → config (GPIO pins, driver selection)
protocol  → system (state para resposta '?')
system    → (sem dependências internas — apenas ESP-IDF + FreeRTOS)
config    → (sem dependências — apenas #defines)
```

## 4. Regras de Acesso ao Hardware

```
Regra: SOMENTE a HAL toca registradores de hardware diretamente.
       SOMENTE o step_generator.c (ISR) chama hal_stepper_step() diretamente.
       Todas as outras chamadas de hardware passam pela fila ou pelo executor.

Exceção permitida: grbl_protocol.c chama uart_write_bytes() diretamente
                   (UART TX é não-bloqueante e thread-safe no ESP-IDF).
```
