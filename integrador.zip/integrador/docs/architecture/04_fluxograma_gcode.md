# Fluxograma de Processamento G-Code

## 1. Pipeline Completo

```
                         ┌─────────────────────────┐
                         │   HOST (PC / Software)   │
                         │   Envia linha G-Code      │
                         │   ex: "G1 X50 Y30 F600\n"│
                         └────────────┬────────────┘
                                      │ USB Serial
                                      ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│ UARTTask                                                                    │
│                                                                             │
│  ┌─────────────┐    ┌──────────────────┐    ┌─────────────────────────┐   │
│  │ uart_read() │───►│ Acumula buffer   │───►│ '\n' encontrado?        │   │
│  │ (bloqueante)│    │ char por char    │    │  Sim → envia cmd_queue  │   │
│  └─────────────┘    └──────────────────┘    │  Não → continua lendo   │   │
│                                             └─────────────────────────┘   │
└───────────────────────────────────────────────┬─────────────────────────────┘
                                                │ cmd_queue
                                                ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│ GCodeParserTask                                                             │
│                                                                             │
│  ┌──────────────────┐                                                      │
│  │ Recebe string    │                                                      │
│  │ da cmd_queue     │                                                      │
│  └────────┬─────────┘                                                      │
│           │                                                                 │
│           ▼                                                                 │
│  ┌──────────────────┐    Não    ┌─────────────────────────────────────┐   │
│  │ Linha vazia ou   ├──────────►│              Tokeniza               │   │
│  │ comentário ';'?  │           │  extrai pares letra+número          │   │
│  └──────────────────┘           └──────────────┬────────────────────┘   │
│                                                 │                          │
│           ┌─────────────────────────────────────┤                          │
│           │                                     │                          │
│    ┌──────▼──────┐   ┌──────────────┐   ┌──────▼──────┐                  │
│    │ '?' (status)│   │ M3 / M5      │   │ G0/G1/G28   │                  │
│    │             │   │ (extrusor)   │   │ (movimento) │                  │
│    └──────┬──────┘   └──────┬───────┘   └──────┬──────┘                  │
│           │                 │                   │                          │
│           ▼                 ▼                   ▼                          │
│  Sinaliza          extruder_queue        motion_queue                     │
│  status_semaphore  (ON ou OFF)           (motion_cmd_t)                   │
│           │                 │                   │                          │
│           └────────┬────────┘                   │                          │
│                    ▼                             ▼                          │
│              Envia "ok\n"                  Envia "ok\n"                    │
│              via UART                      via UART                        │
└─────────────────────────────────────────────────────────────────────────────┘
                              │                   │
                              ▼                   ▼
                       ExtruderTask       MotionPlannerTask
                       (GPIO direto)           (ver abaixo)
```

## 2. Fluxo do MotionPlannerTask

```
┌─────────────────────────────────────────────────────────────────────────────┐
│ MotionPlannerTask                                                           │
│                                                                             │
│  ┌────────────────────────────────────────────────────────────────────┐    │
│  │ Recebe motion_cmd_t da motion_queue                                │    │
│  │   { type: G0/G1/G28, x, y, feedrate, mode: ABS/REL }              │    │
│  └──────────────────────────────┬─────────────────────────────────────┘    │
│                                 │                                           │
│                                 ▼                                           │
│  ┌──────────────────────────────────────────────────────────────────────┐  │
│  │ Converte coordenadas para passos                                     │  │
│  │   steps_x = (target_x - current_x) * STEPS_PER_MM_X                │  │
│  │   steps_y = (target_y - current_y) * STEPS_PER_MM_Y                │  │
│  └──────────────────────────────┬───────────────────────────────────────┘  │
│                                 │                                           │
│                                 ▼                                           │
│  ┌──────────────────────────────────────────────────────────────────────┐  │
│  │ Calcula parâmetros Bresenham                                         │  │
│  │   dx = |steps_x|,  dy = |steps_y|                                   │  │
│  │   dominant = max(dx, dy)  → eixo principal                          │  │
│  │   error_init = dominant / 2                                          │  │
│  │   dir_x, dir_y = sinais dos deltas                                  │  │
│  └──────────────────────────────┬───────────────────────────────────────┘  │
│                                 │                                           │
│                                 ▼                                           │
│  ┌──────────────────────────────────────────────────────────────────────┐  │
│  │ Calcula perfil trapezoidal                                           │  │
│  │   v_entry = 0 (simplificado — pode ser melhorado)                   │  │
│  │   v_exit  = 0                                                        │  │
│  │   v_max   = feedrate / 60.0 (mm/s)                                  │  │
│  │   step_rate_max = v_max * STEPS_PER_MM                              │  │
│  │   accel_steps = (v_max² - v_entry²) / (2 * ACCEL_MM_S2)            │  │
│  │   decel_steps = (v_max² - v_exit²)  / (2 * ACCEL_MM_S2)            │  │
│  │   cruise_steps = total_steps - accel_steps - decel_steps            │  │
│  └──────────────────────────────┬───────────────────────────────────────┘  │
│                                 │                                           │
│                                 ▼                                           │
│  ┌──────────────────────────────────────────────────────────────────────┐  │
│  │ Preenche motion_block_t e envia para block_queue                     │  │
│  │   { steps_x, steps_y, dir_x, dir_y, dx, dy, error,                  │  │
│  │     accel_steps, cruise_steps, decel_steps,                          │  │
│  │     initial_rate, max_rate, final_rate }                             │  │
│  └──────────────────────────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────────────────────────┘
```

## 3. Fluxo do MotionExecutorTask + ISR

```
┌─────────────────────────────────────────────────────────────────────────────┐
│ MotionExecutorTask                                                          │
│                                                                             │
│  ┌────────────────────────────┐                                            │
│  │ Recebe motion_block_t      │                                            │
│  │ da block_queue             │                                            │
│  └────────────────┬───────────┘                                            │
│                   │                                                         │
│                   ▼                                                         │
│  ┌────────────────────────────────────────────────────────────────────┐    │
│  │ Configura variáveis globais da ISR (em seção crítica)              │    │
│  │   g_isr_ctx.block  = &current_block                                │    │
│  │   g_isr_ctx.step_count = 0                                         │    │
│  │   g_isr_ctx.phase = ACCEL                                          │    │
│  │   g_isr_ctx.current_rate = block.initial_rate                      │    │
│  └────────────────┬───────────────────────────────────────────────────┘    │
│                   │                                                         │
│                   ▼                                                         │
│  ┌────────────────────────────────────────────────────────────────────┐    │
│  │ Configura GPIO DIR para X e Y                                       │    │
│  │ Habilita stepper (EN_PIN = LOW)                                     │    │
│  │ Arma GPTimer com initial_period_us                                  │    │
│  └────────────────┬───────────────────────────────────────────────────┘    │
│                   │                                                         │
│                   ▼                                                         │
│  ┌────────────────────────────────────────────────────────────────────┐    │
│  │ xTaskNotifyWait(EVENT_BLOCK_DONE | EVENT_ALARM, portMAX_DELAY)     │    │
│  │ (BLOQUEIA — ISR controla o hardware)                               │    │
│  └────────────────┬───────────────────────────────────────────────────┘    │
│                   │ (ISR completa o bloco e notifica)                       │
│                   ▼                                                         │
│  ┌────────────────────────────────────────────────────────────────────┐    │
│  │ Atualiza g_state.mpos_x += block.steps_x / STEPS_PER_MM_X         │    │
│  │ Atualiza g_state.mpos_y += block.steps_y / STEPS_PER_MM_Y         │    │
│  │ Se fila vazia: g_state.status = IDLE                               │    │
│  └────────────────────────────────────────────────────────────────────┘    │
└─────────────────────────────────────────────────────────────────────────────┘
                   │
                   │ (GPTimer ISR — IRAM_ATTR, Core 1)
                   ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│ gptimer_isr_callback()                                                      │
│                                                                             │
│  ┌────────────────────────────────────────────────────────────────────┐    │
│  │ Bresenham — eixo X (dominante neste exemplo):                      │    │
│  │   Sempre: pulso STEP no eixo X                                     │    │
│  │   error += dy                                                      │    │
│  │   if (error >= dx):                                                │    │
│  │       pulso STEP no eixo Y                                         │    │
│  │       error -= dx                                                  │    │
│  └────────────────┬───────────────────────────────────────────────────┘    │
│                   │                                                         │
│                   ▼                                                         │
│  ┌────────────────────────────────────────────────────────────────────┐    │
│  │ Atualiza fase trapezoidal:                                         │    │
│  │   ACCEL:  step_count < accel_steps → diminui period               │    │
│  │   CRUISE: step_count < accel+cruise → mantém period               │    │
│  │   DECEL:  step_count < total       → aumenta period               │    │
│  └────────────────┬───────────────────────────────────────────────────┘    │
│                   │                                                         │
│                   ▼                                                         │
│  ┌────────────────────────────────────────────────────────────────────┐    │
│  │ step_count++                                                       │    │
│  │ Se step_count >= total_steps:                                      │    │
│  │   Para GPTimer                                                     │    │
│  │   xTaskNotifyFromISR(executor_task, EVENT_BLOCK_DONE, ...)         │    │
│  │ Senão:                                                             │    │
│  │   gptimer_set_alarm(new_period)  ← re-arma com period atualizado  │    │
│  └────────────────────────────────────────────────────────────────────┘    │
└─────────────────────────────────────────────────────────────────────────────┘
```

## 4. Fluxo de Homing (G28)

```
GCodeParser recebe "G28"
    │
    ▼
Envia motion_cmd_t { type: HOMING } para motion_queue
    │
    ▼
MotionPlanner recebe → cria bloco especial HOMING → block_queue
    │
    ▼
MotionExecutor detecta bloco HOMING:
    1. Move X em direção negativa (baixa velocidade)
    2. Monitora endstop X (polling GPIO ou ISR de GPIO)
    3. Endstop X acionado → para, zera posição X
    4. Recua X alguns passos (de-bounce mechanical)
    5. Repete para Y
    6. g_state.mpos = {0, 0}
    7. Sinaliza EVENT_HOMING_DONE
    │
    ▼
GCodeParser responde "ok\n"
```
