# Diagrama de Componentes

## 1. Componentes de Software e suas Interfaces

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                        DIAGRAMA DE COMPONENTES                              │
│                                                                             │
│  ┌────────────────────────────────────────────────────────────────────┐    │
│  │                         «component»                                │    │
│  │                           tasks/                                   │    │
│  │                                                                    │    │
│  │  ┌─────────────┐  ┌──────────────┐  ┌─────────────────────────┐  │    │
│  │  │  UARTTask   │  │GCodeParser   │  │   MotionPlannerTask     │  │    │
│  │  │             │  │Task          │  │                         │  │    │
│  │  └──────┬──────┘  └──────┬───────┘  └────────────┬────────────┘  │    │
│  │         │[cmd_q]         │[motion_q] [extruder_q] │[block_q]      │    │
│  │  ┌──────┴──────────┐     │           │            │              │    │
│  │  │  MonitorTask    │     │           │            │              │    │
│  │  │  [state_mutex]  │     │           │            │              │    │
│  │  └─────────────────┘     │           │            │              │    │
│  │                    ┌─────┘           │     ┌──────┘              │    │
│  │                    │                 │     │                     │    │
│  │  ┌─────────────────┴────┐   ┌────────┴─────┴──────────────────┐  │    │
│  │  │   ExtruderTask       │   │      MotionExecutorTask         │  │    │
│  │  │                      │   │      + step_generator ISR       │  │    │
│  │  └──────────┬───────────┘   └──────────────┬──────────────────┘  │    │
│  └─────────────┼────────────────────────────────┼───────────────────┘    │
│                │                                │                          │
│                ▼ «uses»                         ▼ «uses»                   │
│  ┌─────────────────────────────────────────────────────────────────────┐  │
│  │                         «component»                                 │  │
│  │                           hal/                                      │  │
│  │                                                                     │  │
│  │  ┌───────────────────────┐  ┌────────────────┐  ┌───────────────┐  │  │
│  │  │   hal_stepper         │  │  hal_endstop   │  │hal_extruder   │  │  │
│  │  │                       │  │                │  │               │  │  │
│  │  │ +init()               │  │ +init()        │  │ +init()       │  │  │
│  │  │ +set_dir(axis, dir)   │  │ +read_x(): bool│  │ +on()         │  │  │
│  │  │ +step(axis)           │  │ +read_y(): bool│  │ +off()        │  │  │
│  │  │ +enable(axis)         │  │                │  │ +is_on(): bool│  │  │
│  │  │ +disable(axis)        │  └────────────────┘  └───────────────┘  │  │
│  │  └───────────────────────┘                                          │  │
│  └─────────────────────────────────────────────────────────────────────┘  │
│                                │                                            │
│                                ▼ «uses»                                    │
│  ┌─────────────────────────────────────────────────────────────────────┐  │
│  │                         «component»                                 │  │
│  │                           config/                                   │  │
│  │                                                                     │  │
│  │  #define STEPS_PER_MM_X    80                                       │  │
│  │  #define STEPS_PER_MM_Y    80                                       │  │
│  │  #define ACCELERATION      500   // mm/s²                           │  │
│  │  #define MAX_FEEDRATE      3000  // mm/min                          │  │
│  │  #define DRIVER_A4988             // ou DRIVER_DRV8825              │  │
│  │  #define GPIO_STEP_X       18                                       │  │
│  │  #define GPIO_DIR_X        19                                       │  │
│  │  ... (todos os demais defines)                                      │  │
│  └─────────────────────────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────────────────────────┘
```

## 2. Interfaces das Structs Principais

### motion_cmd_t (saída do GCodeParser → entrada do Planner)
```c
typedef struct {
    enum { CMD_MOVE_G0, CMD_MOVE_G1, CMD_HOMING } type;
    float target_x;         // mm (coordenada absoluta já resolvida)
    float target_y;         // mm
    float feedrate;         // mm/min
} motion_cmd_t;
```

### motion_block_t (saída do Planner → entrada do Executor)
```c
typedef struct {
    // Bresenham
    int32_t steps_x;        // total de passos em X (com sinal = direção)
    int32_t steps_y;        // total de passos em Y
    int32_t dominant;       // max(|steps_x|, |steps_y|)
    int32_t subordinate;    // min(|steps_x|, |steps_y|)
    int32_t bresenham_error;// erro inicial = dominant/2
    bool    dominant_is_x;  // true se X é dominante
    int8_t  dir_x;          // +1 ou -1
    int8_t  dir_y;          // +1 ou -1

    // Perfil trapezoidal
    uint32_t total_steps;       // = dominant
    uint32_t accel_steps;
    uint32_t decel_step_start;  // = total_steps - decel_steps
    uint32_t initial_period_us; // período do 1º passo
    uint32_t min_period_us;     // período no cruzeiro
    uint32_t accel_increment;   // subtrai do period por passo (accel)
    uint32_t decel_increment;   // soma ao period por passo (decel)
} motion_block_t;
```

### system_state_t (estado global protegido por mutex)
```c
typedef enum {
    STATE_IDLE,
    STATE_RUN,
    STATE_HOMING,
    STATE_ALARM
} machine_state_t;

typedef struct {
    machine_state_t status;
    float           mpos_x;   // posição em mm
    float           mpos_y;
    float           feedrate;
    bool            extruder_on;
    bool            position_absolute; // true=G90, false=G91
} system_state_t;
```

## 3. Seleção de Driver por Configuração

A HAL usa compilação condicional para suportar A4988 e DRV8825:

```c
// Em config.h:
// #define STEPPER_DRIVER  DRIVER_A4988
// #define STEPPER_DRIVER  DRIVER_DRV8825

// Em hal_stepper.c:
#if STEPPER_DRIVER == DRIVER_A4988
    // A4988: MS1, MS2, MS3 para microstepping
    // RESET e SLEEP ativos-baixo
    // Step pulse: mín 1µs HIGH
    #define STEP_PULSE_US   2
    #define DIR_SETUP_US    1

#elif STEPPER_DRIVER == DRIVER_DRV8825
    // DRV8825: MODE0, MODE1, MODE2 para microstepping
    // RESET ativo-baixo, SLEEP ativo-alto
    // Step pulse: mín 1.9µs HIGH
    #define STEP_PULSE_US   3
    #define DIR_SETUP_US    1
#endif
```
