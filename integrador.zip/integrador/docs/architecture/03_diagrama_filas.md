# Diagrama de Filas e Primitivas FreeRTOS

## 1. Mapa Completo de IPC

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                    PRIMITIVAS FREERTOS — FLUXO COMPLETO                     │
│                                                                             │
│                                                                             │
│  ╔══════════╗    cmd_queue (10 items)     ╔═══════════════╗                │
│  ║ UARTTask ╠────────────────────────────►║GCodeParser    ║                │
│  ╚══════════╝    char[128]                ╚═══════╤═══════╝                │
│                                                   │                        │
│                         ┌─────────────────────────┤                        │
│                         │                         │                        │
│               motion_queue (5 items)    extruder_queue (5 items)           │
│               motion_cmd_t              extruder_cmd_t                     │
│                         │                         │                        │
│                         ▼                         ▼                        │
│  ╔═══════════════╗              ╔═══════════════════════╗                  │
│  ║MotionPlanner  ║              ║   ExtruderTask        ║                  │
│  ╚═══════╤═══════╝              ╚═══════════════════════╝                  │
│          │                              ▲                                  │
│    block_queue (3 items)                │ extruder_queue                   │
│    motion_block_t                       │                                  │
│          │                        ┌────┘                                   │
│          ▼                        │                                        │
│  ╔═══════════════╗    xTaskNotify ║     ╔═══════════════╗                  │
│  ║MotionExecutor ╠───────────────►║     ║  MonitorTask  ║                  │
│  ╚═══════╤═══════╝  (block done)  ║     ╚═══════════════╝                  │
│          │                        ║           ▲                            │
│    [GPTimer ISR]                  ║           │ status_semaphore           │
│          │                        ║           │ (binário)                  │
│          │ xTaskNotifyFromISR     ║           │                            │
│          └────────────────────────┘    ╔══════╧════════╗                  │
│                                        ║ GCodeParser   ║                  │
│                                        ║ (sinaliza '?')║                  │
│                                        ╚═══════════════╝                  │
│                                                                             │
│  ─────────────────────────────────────────────────────────────────────     │
│  MUTEX                                                                      │
│                                                                             │
│  state_mutex ──► protege system_state_t (lida por Monitor, escrita         │
│                  por MotionExecutor e GCodeParser)                          │
│                                                                             │
│  ─────────────────────────────────────────────────────────────────────     │
│  EVENT GROUP: motion_event_group                                            │
│                                                                             │
│  Bit 0: EVENT_HOMING_DONE   ← sinalizado por MotionExecutor após G28       │
│  Bit 1: EVENT_BLOCK_DONE    ← sinalizado pela ISR ao fim de bloco          │
│  Bit 2: EVENT_ALARM         ← sinalizado por qualquer tarefa em erro       │
│  Bit 3: EVENT_STATUS_REQ    ← sinalizado por GCodeParser ao receber '?'    │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

## 2. Especificação das Filas

### cmd_queue
| Atributo | Valor |
|----------|-------|
| Tipo de item | `char[128]` (string terminada em `\0`) |
| Capacidade | 10 itens |
| Produtor | UARTTask |
| Consumidor | GCodeParserTask |
| Comportamento produtor | `xQueueSend` com timeout 0 (descarta se cheia — não bloqueia UART) |
| Comportamento consumidor | `xQueueReceive` com `portMAX_DELAY` |

### motion_queue
| Atributo | Valor |
|----------|-------|
| Tipo de item | `motion_cmd_t` (struct ~32 bytes) |
| Capacidade | 5 itens |
| Produtor | GCodeParserTask |
| Consumidor | MotionPlannerTask |
| Comportamento produtor | `xQueueSend` com timeout 100ms |
| Comportamento consumidor | `xQueueReceive` com `portMAX_DELAY` |

### extruder_queue
| Atributo | Valor |
|----------|-------|
| Tipo de item | `extruder_cmd_t` (enum: ON/OFF) |
| Capacidade | 5 itens |
| Produtor | GCodeParserTask |
| Consumidor | ExtruderTask |
| Comportamento produtor | `xQueueSend` com timeout 0 |
| Comportamento consumidor | `xQueueReceive` com `portMAX_DELAY` |

### block_queue
| Atributo | Valor |
|----------|-------|
| Tipo de item | `motion_block_t` (struct ~64 bytes) |
| Capacidade | 3 itens |
| Produtor | MotionPlannerTask |
| Consumidor | MotionExecutorTask |
| Comportamento produtor | `xQueueSend` com `portMAX_DELAY` (bloqueia — back-pressure natural) |
| Comportamento consumidor | `xQueueReceive` com `portMAX_DELAY` |

## 3. Especificação dos Semáforos e Mutex

### state_mutex
- Tipo: `SemaphoreHandle_t` (mutex)
- Protege: `system_state_t g_state` (posição, status, feedrate)
- Escritores: MotionExecutorTask, GCodeParserTask (modo abs/rel)
- Leitores: MonitorTask
- Timeout máximo: 10ms (nunca bloquear indefinidamente)

### status_semaphore
- Tipo: semáforo binário
- Sinalizado por: GCodeParserTask ao receber comando `?`
- Aguardado por: MonitorTask (acorda, lê estado, responde, dorme novamente)

## 4. Especificação do Event Group

### motion_event_group
```c
#define EVENT_HOMING_DONE   BIT0   // G28 concluído
#define EVENT_BLOCK_DONE    BIT1   // ISR completou bloco de movimento
#define EVENT_ALARM         BIT2   // Erro de endstop ou overflow
#define EVENT_STATUS_REQ    BIT3   // Comando '?' recebido
```

Uso pelo MotionExecutorTask:
```c
// Aguarda bloco concluir OU alarme disparar
xEventGroupWaitBits(motion_event_group,
    EVENT_BLOCK_DONE | EVENT_ALARM,
    pdTRUE,   // limpa bits ao retornar
    pdFALSE,  // OR (qualquer um dos bits)
    portMAX_DELAY);
```

## 5. Fluxo de Back-Pressure

O `block_queue` com capacidade 3 e `xQueueSend(..., portMAX_DELAY)` no Planner
implementa back-pressure natural:

```
Se MotionExecutor está lento consumindo blocos:
    → block_queue enche
    → MotionPlannerTask bloqueia em xQueueSend
    → motion_queue começa a encher
    → GCodeParserTask desacelera (timeout de 100ms)
    → cmd_queue pode encher
    → UARTTask descarta com timeout 0 (comportamento intencional — host deve respeitar ok/error)
```

Este comportamento é consistente com o protocolo GRBL: o host não deve enviar
mais comandos do que o firmware confirma com `ok`.
