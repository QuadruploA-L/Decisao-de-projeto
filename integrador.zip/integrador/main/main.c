/**
 * @file main.c
 * @brief Ponto de entrada do firmware XY G-Code para ESP32.
 *
 * # Sequência de inicialização
 *
 * 1. Inicializa hardware (HAL): extrusor, endstops, motores de passo, UART.
 * 2. Inicializa primitivas FreeRTOS (filas, mutexes, event group) via
 *    system_state_init().
 * 3. Cria as 5 tarefas FreeRTOS:
 *    - MonitorTask      (Core 0, Prio 1)
 *    - UARTTask         (Core 0, Prio 2)
 *    - GCodeParserTask  (Core 0, Prio 3)
 *    - MotionPlannerTask(Core 0, Prio 3)
 *    - MotionExecutorTask (Core 1, Prio 4) — fixada no Core 1
 * 4. Deleta a si mesmo (app_main encerra; o scheduler FreeRTOS assume o controle).
 *
 * # Por que a ordem importa?
 *
 * As filas e mutexes DEVEM existir antes das tarefas iniciarem.
 * Se uma tarefa tentar usar g_cmd_queue antes de ele ser criado, o
 * comportamento é indefinido. A ordem acima garante isso.
 *
 * # Núcleo de execução
 *
 * O app_main() roda no Core 0. A MotionExecutorTask é criada com
 * xTaskCreatePinnedToCore(..., core=EXECUTOR_CORE_ID=1), garantindo
 * que o GPTimer ISR rode no Core 1 e nunca compete com as demais tarefas.
 */

#include "config.h"
#include "system_state.h"
#include "hal_stepper.h"
#include "hal_endstop.h"
#include "hal_extruder.h"
#include "task_uart.h"
#include "task_gcode_parser.h"
#include "task_motion_planner.h"
#include "task_motion_executor.h"
#include "task_monitor.h"

#include "driver/uart.h"
#include "esp_log.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"

static const char *TAG = "main";

/* ===========================================================================
 * INICIALIZAÇÃO DA UART
 * ========================================================================= */

/**
 * @brief Configura o driver UART do ESP-IDF.
 *
 * Usa UART_NUM_0 (mapeado para USB CDC na maioria das placas ESP32
 * com chip UART-USB integrado).
 */
static esp_err_t uart_init(void)
{
    const uart_config_t uart_config = {
        .baud_rate  = UART_BAUD_RATE,
        .data_bits  = UART_DATA_8_BITS,
        .parity     = UART_PARITY_DISABLE,
        .stop_bits  = UART_STOP_BITS_1,
        .flow_ctrl  = UART_HW_FLOWCTRL_DISABLE,
        .source_clk = UART_SCLK_DEFAULT,
    };

    esp_err_t ret;

    ret = uart_driver_install(UART_PORT_NUM,
                              UART_RX_BUF_SZ,
                              UART_TX_BUF_SZ,
                              0, NULL, 0);
    if (ret != ESP_OK) return ret;

    ret = uart_param_config(UART_PORT_NUM, &uart_config);
    if (ret != ESP_OK) return ret;

    /* Pinos padrão do UART0 (TXD=1, RXD=3) — adequado para USB-Serial */
    ret = uart_set_pin(UART_PORT_NUM,
                       UART_PIN_NO_CHANGE, UART_PIN_NO_CHANGE,
                       UART_PIN_NO_CHANGE, UART_PIN_NO_CHANGE);
    return ret;
}

/* ===========================================================================
 * PONTO DE ENTRADA
 * ========================================================================= */

void app_main(void)
{
    ESP_LOGI(TAG, "=== Firmware XY G-Code iniciando ===");
    ESP_LOGI(TAG, "Driver: %s | STEPS/MM: X=%.0f Y=%.0f",
#ifdef STEPPER_DRIVER_A4988
             "A4988",
#else
             "DRV8825",
#endif
             (double)STEPS_PER_MM_X, (double)STEPS_PER_MM_Y);

    /* ------------------------------------------------------------------
     * ETAPA 1: Inicialização do hardware (HAL)
     * Ordem: extrusor primeiro (estado seguro OFF), depois endstops, depois motores.
     * ---------------------------------------------------------------- */
    ESP_ERROR_CHECK(hal_extruder_init());
    ESP_ERROR_CHECK(hal_endstop_init());
    ESP_ERROR_CHECK(hal_stepper_init());
    ESP_ERROR_CHECK(uart_init());

    ESP_LOGI(TAG, "HAL inicializada");

    /* ------------------------------------------------------------------
     * ETAPA 2: Primitivas FreeRTOS
     * Todas as filas, mutexes e event group criados ANTES das tasks.
     * ---------------------------------------------------------------- */
    if (!system_state_init()) {
        ESP_LOGE(TAG, "FALHA CRITICA: system_state_init() falhou. Sistema parado.");
        /* Sem recuperação possível — loop infinito */
        for (;;) { vTaskDelay(portMAX_DELAY); }
    }

    ESP_LOGI(TAG, "Primitivas FreeRTOS criadas");

    /* ------------------------------------------------------------------
     * ETAPA 3: Criação das tarefas FreeRTOS
     *
     * Nota sobre xTaskCreate vs xTaskCreatePinnedToCore:
     * - xTaskCreate (NULL affinity): scheduler SMP decide o core.
     * - xTaskCreatePinnedToCore(..., EXECUTOR_CORE_ID): fixa no Core 1.
     *   Necessário para garantir que a ISR do GPTimer rode no Core 1.
     * ---------------------------------------------------------------- */

    xTaskCreate(task_monitor,
                "monitor",
                TASK_STACK_MONITOR,
                NULL,
                TASK_PRIO_MONITOR,
                NULL);

    xTaskCreate(task_uart,
                "uart",
                TASK_STACK_UART,
                NULL,
                TASK_PRIO_UART,
                NULL);

    xTaskCreate(task_gcode_parser,
                "parser",
                TASK_STACK_PARSER,
                NULL,
                TASK_PRIO_PARSER,
                NULL);

    xTaskCreate(task_motion_planner,
                "planner",
                TASK_STACK_PLANNER,
                NULL,
                TASK_PRIO_PLANNER,
                NULL);

    /* MotionExecutorTask: fixada no Core 1 para isolar a ISR do GPTimer */
    xTaskCreatePinnedToCore(task_motion_executor,
                            "executor",
                            TASK_STACK_EXECUTOR,
                            NULL,
                            TASK_PRIO_EXECUTOR,
                            NULL,
                            EXECUTOR_CORE_ID);

    ESP_LOGI(TAG, "5 tarefas FreeRTOS criadas. app_main encerrando.");
    ESP_LOGI(TAG, "Aguardando comandos G-Code na UART%d @ %d bps",
             UART_PORT_NUM, UART_BAUD_RATE);

    /* app_main encerra — o scheduler FreeRTOS assume o controle */
    vTaskDelete(NULL);
}
