/**
 * @file config.h
 * @brief Parâmetros de configuração central do firmware.
 *
 * Todos os pinos, velocidades, acelerações e tamanhos de fila são definidos
 * aqui. Alterar este arquivo é suficiente para adaptar o firmware a um
 * hardware diferente sem modificar nenhuma lógica de negócio.
 */

#ifndef CONFIG_H
#define CONFIG_H

/* ===========================================================================
 * SELEÇÃO DE DRIVER DE MOTOR DE PASSO
 * Descomente APENAS um dos dois abaixo.
 * ========================================================================= */
#define STEPPER_DRIVER_A4988
/* #define STEPPER_DRIVER_DRV8825 */

/* ===========================================================================
 * PINOS GPIO — EIXO X
 * ========================================================================= */
#define GPIO_STEP_X     18  /**< Pino STEP do driver X */
#define GPIO_DIR_X      19  /**< Pino DIR do driver X  */
#define GPIO_EN_X       21  /**< Pino ENABLE do driver X (ativo em LOW) */

/* ===========================================================================
 * PINOS GPIO — EIXO Y
 * ========================================================================= */
#define GPIO_STEP_Y     22  /**< Pino STEP do driver Y */
#define GPIO_DIR_Y      23  /**< Pino DIR do driver Y  */
#define GPIO_EN_Y       25  /**< Pino ENABLE do driver Y (ativo em LOW) */

/* ===========================================================================
 * PINOS GPIO — FIM DE CURSO
 * Pull-up interno habilitado; acionado = nível LOW.
 * ========================================================================= */
#define GPIO_ENDSTOP_X  34  /**< Pino do fim de curso X (input only) */
#define GPIO_ENDSTOP_Y  35  /**< Pino do fim de curso Y (input only) */

/* ===========================================================================
 * PINOS GPIO — EXTRUSOR
 * ========================================================================= */
#define GPIO_EXTRUDER   26  /**< Pino de controle do extrusor (HIGH = ligado) */

/* ===========================================================================
 * UART
 * ========================================================================= */
#define UART_PORT_NUM   UART_NUM_0  /**< Porta UART usada para comunicação USB */
#define UART_BAUD_RATE  115200      /**< Baud rate serial */
#define UART_RX_BUF_SZ  512        /**< Tamanho do buffer de RX do driver UART */
#define UART_TX_BUF_SZ  256        /**< Tamanho do buffer de TX do driver UART */

/* ===========================================================================
 * PARÂMETROS MECÂNICOS
 * Ajustar conforme o mecanismo real (fuso, correia, microstepping).
 * ========================================================================= */
#define STEPS_PER_MM_X  80.0f  /**< Passos por milímetro no eixo X */
#define STEPS_PER_MM_Y  80.0f  /**< Passos por milímetro no eixo Y */

/* ===========================================================================
 * PARÂMETROS DE MOVIMENTO
 * ========================================================================= */
#define DEFAULT_FEEDRATE_MM_MIN  600.0f   /**< Feedrate inicial (mm/min) */
#define MAX_FEEDRATE_MM_MIN      3000.0f  /**< Feedrate máximo permitido por software */
#define HOMING_FEEDRATE_MM_MIN   300.0f   /**< Velocidade de homing (lenta) */
#define HOMING_PULLOFF_MM        3.0f     /**< Recuo após acionar endstop (mm) */
#define ACCELERATION_MM_S2       500.0f   /**< Aceleração padrão (mm/s²) */
#define MIN_SPEED_MM_S           0.5f     /**< Velocidade mínima para perfil trapezoidal */

/** Número máximo de passos de viagem para segurança no homing.
 *  Evita dano mecânico se o endstop não for acionado. */
#define HOMING_MAX_TRAVEL_STEPS  50000UL

/* ===========================================================================
 * PARÂMETROS DO GPTIMER (GERADOR DE PASSOS)
 * ========================================================================= */
#define GPTIMER_RESOLUTION_HZ   1000000UL  /**< 1 MHz → resolução de 1 µs */
#define STEP_PULSE_WIDTH_US      2U         /**< Largura do pulso STEP em µs (≥2 para A4988/DRV8825) */
#define MIN_STEP_PERIOD_US       10U        /**< Período mínimo seguro (100 kHz máx) */
#define MAX_STEP_PERIOD_US       100000U    /**< Período máximo (10 steps/s mínimo) */

/* ===========================================================================
 * DIMENSIONAMENTO DAS FILAS FREERTOS
 * ========================================================================= */
#define CMD_QUEUE_LEN         10   /**< Número de linhas de comando na fila UART→Parser */
#define CMD_QUEUE_ITEM_SIZE   96   /**< Bytes por item (cobre qualquer linha G-Code válida) */
#define MOTION_QUEUE_LEN      8    /**< Número de motion_cmd_t na fila Parser→Planner */
#define PLANNER_QUEUE_LEN     16   /**< Número de motion_block_t na fila Planner→Executor */

/* ===========================================================================
 * CONFIGURAÇÃO DE TAREFAS FREERTOS
 * ========================================================================= */
#define TASK_PRIO_MONITOR    1   /**< Prioridade da MonitorTask (background) */
#define TASK_PRIO_UART       2   /**< Prioridade da UARTTask */
#define TASK_PRIO_PARSER     3   /**< Prioridade da GCodeParserTask */
#define TASK_PRIO_PLANNER    3   /**< Prioridade da MotionPlannerTask */
#define TASK_PRIO_EXECUTOR   4   /**< Prioridade da MotionExecutorTask (tempo real) */

#define TASK_STACK_MONITOR   2048  /**< Stack da MonitorTask (words) */
#define TASK_STACK_UART      2048  /**< Stack da UARTTask (words) */
#define TASK_STACK_PARSER    4096  /**< Stack da GCodeParserTask (words) */
#define TASK_STACK_PLANNER   4096  /**< Stack da MotionPlannerTask (words) */
#define TASK_STACK_EXECUTOR  4096  /**< Stack da MotionExecutorTask (words) */

/** Core onde a MotionExecutorTask é fixada (garante ISR do GPTimer no Core 1). */
#define EXECUTOR_CORE_ID     1

/* ===========================================================================
 * TIMEOUT DE MUTEX (ms)
 * Nunca bloquear indefinidamente em mutex — evita travamento silencioso.
 * ========================================================================= */
#define MUTEX_TIMEOUT_MS     5   /**< Timeout máximo para aquisição de mutex */

/* ===========================================================================
 * PARÂMETROS DO DRIVER DE PASSO (dependem da seleção acima)
 * ========================================================================= */
#ifdef STEPPER_DRIVER_A4988
    /** Nível lógico para habilitar o driver (EN ativo em LOW no A4988). */
    #define DRIVER_ENABLE_LEVEL   0
    /** Nível lógico para desabilitar o driver. */
    #define DRIVER_DISABLE_LEVEL  1
#elif defined(STEPPER_DRIVER_DRV8825)
    #define DRIVER_ENABLE_LEVEL   0
    #define DRIVER_DISABLE_LEVEL  1
#else
    #error "Selecione STEPPER_DRIVER_A4988 ou STEPPER_DRIVER_DRV8825 em config.h"
#endif

#endif /* CONFIG_H */
