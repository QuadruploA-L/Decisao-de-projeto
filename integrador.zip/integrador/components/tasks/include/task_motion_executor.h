/**
 * @file task_motion_executor.h
 * @brief Interface da MotionExecutorTask.
 *
 * Pinada no Core 1. Consome motion_block_t de g_planner_queue, configura
 * o GPTimer e a ISR, e aguarda a conclusão do bloco via xTaskNotifyWait.
 */

#ifndef TASK_MOTION_EXECUTOR_H
#define TASK_MOTION_EXECUTOR_H

/**
 * @brief Ponto de entrada da MotionExecutorTask.
 *
 * @param pvParameters Não utilizado (NULL).
 */
void task_motion_executor(void *pvParameters);

#endif /* TASK_MOTION_EXECUTOR_H */
