/**
 * @file task_gcode_parser.h
 * @brief Interface da GCodeParserTask.
 *
 * Interpreta linhas G-Code recebidas de g_cmd_queue e as converte em
 * comandos estruturados (motion_cmd_t) enviados para g_motion_queue.
 */

#ifndef TASK_GCODE_PARSER_H
#define TASK_GCODE_PARSER_H

/**
 * @brief Ponto de entrada da GCodeParserTask.
 *
 * @param pvParameters Não utilizado (NULL).
 */
void task_gcode_parser(void *pvParameters);

#endif /* TASK_GCODE_PARSER_H */
