/**
 * @file task_uart.h
 * @brief Interface da UARTTask.
 *
 * A UARTTask tem duas responsabilidades:
 *  1. Acumular bytes da UART até '\n' e enfileirar a linha em g_cmd_queue.
 *  2. Detectar o caractere '?' e responder IMEDIATAMENTE com o status da
 *     máquina, sem passar pela fila de comandos (comando de tempo real).
 */

#ifndef TASK_UART_H
#define TASK_UART_H

/**
 * @brief Ponto de entrada da UARTTask.
 *
 * @param pvParameters Não utilizado (NULL).
 */
void task_uart(void *pvParameters);

#endif /* TASK_UART_H */
