/**
 * @file task_motion_planner.h
 * @brief Interface da MotionPlannerTask.
 *
 * Recebe motion_cmd_t de g_motion_queue, calcula os parâmetros de Bresenham
 * e o perfil trapezoidal, e enfileira motion_block_t em g_planner_queue.
 */

#ifndef TASK_MOTION_PLANNER_H
#define TASK_MOTION_PLANNER_H

/**
 * @brief Ponto de entrada da MotionPlannerTask.
 *
 * @param pvParameters Não utilizado (NULL).
 */
void task_motion_planner(void *pvParameters);

#endif /* TASK_MOTION_PLANNER_H */
