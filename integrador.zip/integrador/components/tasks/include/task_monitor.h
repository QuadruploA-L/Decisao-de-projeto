/**
 * @file task_monitor.h
 * @brief Interface da MonitorTask.
 *
 * Tarefa de background (prioridade mínima) que verifica periodicamente
 * a saúde do sistema: overflow de filas e starvation do executor.
 * Sinaliza EVENT_ALARM caso detecte anomalias.
 */

#ifndef TASK_MONITOR_H
#define TASK_MONITOR_H

/**
 * @brief Ponto de entrada da MonitorTask.
 *
 * @param pvParameters Não utilizado (NULL).
 */
void task_monitor(void *pvParameters);

#endif /* TASK_MONITOR_H */
