/**
 * @file task_gcode_parser.c
 * @brief Implementação da GCodeParserTask.
 *
 * # Responsabilidades
 *
 * Consome linhas de g_cmd_queue, interpreta os comandos G-Code e os
 * converte em estruturas internas enviadas para g_motion_queue.
 *
 * # Comandos suportados
 *
 * | Comando | Ação                                                    |
 * |---------|---------------------------------------------------------|
 * | G0 Xn Yn | Movimento rápido (usa MAX_FEEDRATE)                   |
 * | G1 Xn Yn Fn | Movimento linear com feedrate                      |
 * | G28     | Homing dos dois eixos                                   |
 * | G90     | Modo de posicionamento absoluto                         |
 * | G91     | Modo de posicionamento relativo                         |
 * | M3      | Liga extrusor                                           |
 * | M5      | Desliga extrusor                                        |
 * | M114    | Reporta posição atual                                   |
 * | F n     | Define feedrate (persistente)                           |
 *
 * # Protocolo ok/error
 *
 * - 'ok' é enviado APÓS xQueueSend retornar (portMAX_DELAY garante aceite).
 * - 'error' é enviado para linhas inválidas ou comandos desconhecidos.
 * - Linhas vazias e comentários (;) são ignoradas silenciosamente.
 *
 * # Resolução G91 (relativo → absoluto)
 *
 * O Parser mantém a posição de planejamento (plan_x, plan_y) separada
 * de g_state.mpos. Coordenadas relativas são somadas a plan_x/y antes
 * de criar o motion_cmd_t.
 *
 * @note Lógica de parsing implementada em Etapa 3 (gcode_parser.c).
 *       Esta task contém o loop FreeRTOS e o despacho.
 */

#include "task_gcode_parser.h"
#include "gcode_parser.h"
#include "system_state.h"
#include "grbl_protocol.h"
#include "config.h"

#include "freertos/FreeRTOS.h"
#include "freertos/queue.h"
#include "freertos/semphr.h"
#include "freertos/event_groups.h"
#include "esp_log.h"
#include <string.h>

static const char *TAG = "task_parser";

void task_gcode_parser(void *pvParameters)
{
    (void)pvParameters;

    char line[CMD_QUEUE_ITEM_SIZE];

    ESP_LOGI(TAG, "GCodeParserTask iniciada");

    for (;;) {
        /* Bloqueia até receber uma linha da UARTTask */
        if (xQueueReceive(g_cmd_queue, line, portMAX_DELAY) != pdTRUE) {
            continue;
        }

        /* Delega a interpretação ao módulo gcode_parser (Etapa 3) */
        gcode_parse_line(line);
    }
}
