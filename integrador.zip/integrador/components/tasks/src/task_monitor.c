/**
 * @file task_monitor.c
 * @brief Implementação da MonitorTask (watchdog de sistema).
 *
 * # Responsabilidades (v2)
 *
 * - Verificar periodicamente o espaço livre nas filas.
 * - Detectar condições de overflow iminente.
 * - Sinalizar EVENT_ALARM em caso de anomalia detectada.
 *
 * # O que a MonitorTask NÃO faz na v2
 *
 * - NÃO responde ao comando '?'. (Movido para UARTTask — resposta de tempo real.)
 * - NÃO interfere no fluxo de dados do pipeline.
 *
 * # Prioridade mínima (1)
 *
 * A MonitorTask só roda quando todas as outras estão bloqueadas.
 * Isso garante que ela nunca roube CPU de tarefas críticas.
 */

#include "task_monitor.h"
#include "system_state.h"
#include "config.h"

#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/queue.h"
#include "freertos/event_groups.h"
#include "esp_log.h"

static const char *TAG = "task_monitor";

/** Limiar de alerta: log de aviso quando fila está X% cheia. */
#define QUEUE_WARN_THRESHOLD_PCT  80

/** Verifica uma fila e loga aviso se estiver quase cheia. */
static void check_queue(QueueHandle_t q, uint32_t capacity, const char *name)
{
    if (q == NULL) return;
    UBaseType_t used = uxQueueMessagesWaiting(q);
    uint32_t pct = (used * 100) / capacity;
    if (pct >= QUEUE_WARN_THRESHOLD_PCT) {
        ESP_LOGW(TAG, "Fila %s: %u/%lu itens (%lu%%)",
                 name, (unsigned)used, (unsigned long)capacity, (unsigned long)pct);
    }
}

void task_monitor(void *pvParameters)
{
    (void)pvParameters;

    ESP_LOGI(TAG, "MonitorTask iniciada");

    for (;;) {
        /* Verifica saúde das filas a cada 1 segundo */
        vTaskDelay(pdMS_TO_TICKS(1000));

        check_queue(g_cmd_queue,      CMD_QUEUE_LEN,     "cmd");
        check_queue(g_motion_queue,   MOTION_QUEUE_LEN,  "motion");
        check_queue(g_planner_queue,  PLANNER_QUEUE_LEN, "planner");

        /* Loga estado geral da máquina */
        machine_state_t status;
        if (xSemaphoreTake(g_state_mutex, pdMS_TO_TICKS(MUTEX_TIMEOUT_MS)) == pdTRUE) {
            status = g_state.status;
            xSemaphoreGive(g_state_mutex);
        } else {
            continue;
        }

        /* Verifica bits de alarme */
        EventBits_t bits = xEventGroupGetBits(g_motion_event_group);
        if (bits & EVENT_ALARM) {
            ESP_LOGE(TAG, "EVENT_ALARM ativo! Estado: %d", (int)status);
        }

        ESP_LOGD(TAG, "Saude OK | Estado: %d | RAM livre: %lu bytes",
                 (int)status, (unsigned long)esp_get_free_heap_size());
    }
}
