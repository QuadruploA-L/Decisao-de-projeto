/**
 * @file task_motion_planner.c
 * @brief Implementação da MotionPlannerTask.
 *
 * # Responsabilidades
 *
 * Recebe motion_cmd_t de g_motion_queue, calcula os parâmetros completos
 * do bloco de movimento (Bresenham + trapezoidal) e enfileira motion_block_t
 * em g_planner_queue para o Executor consumir.
 *
 * # Por que Planner e Executor são tarefas separadas?
 *
 * O planejamento envolve operações com ponto flutuante (sqrt, divisão),
 * que são relativamente lentas. Se o Planner rodasse na mesma tarefa que
 * o Executor, haveria risco de atrasar o disparo do GPTimer.
 *
 * Com a separação:
 * - Planner: Core 0, calcula blocos com antecedência, enche planner_queue.
 * - Executor: Core 1, consome blocos já calculados, nunca espera pelo Planner.
 *
 * # Estado de planejamento
 *
 * O Planner mantém a posição de planejamento (plan_x, plan_y) internamente,
 * necessária para calcular deltas de blocos consecutivos com coordenadas G91.
 * Esta posição é gerenciada pelo gcode_parser.c para M3/M5/G0/G1, e atualizada
 * aqui após calcular cada bloco.
 *
 * @note Lógica matemática em motion_planner.c (Etapa 4).
 */

#include "task_motion_planner.h"
#include "motion_planner.h"
#include "system_state.h"
#include "config.h"

#include "freertos/FreeRTOS.h"
#include "freertos/queue.h"
#include "esp_log.h"

static const char *TAG = "task_planner";

void task_motion_planner(void *pvParameters)
{
    (void)pvParameters;

    motion_cmd_t  cmd;
    motion_block_t block;

    ESP_LOGI(TAG, "MotionPlannerTask iniciada");

    for (;;) {
        /* Bloqueia até receber comando do Parser */
        if (xQueueReceive(g_motion_queue, &cmd, portMAX_DELAY) != pdTRUE) {
            continue;
        }

        /* Delega o cálculo do bloco ao módulo motion_planner (Etapa 4) */
        if (motion_planner_compute(&cmd, &block)) {
            /* Bloco válido — enfileira para o Executor.
             * portMAX_DELAY: back-pressure correto — o Planner bloqueia
             * se a planner_queue estiver cheia (Executor ainda ocupado). */
            xQueueSend(g_planner_queue, &block, portMAX_DELAY);
        }
        /* Se retornou false (ex: movimento de distância zero), ignora */
    }
}
