/**
 * @file task_uart.c
 * @brief Implementação da UARTTask.
 *
 * # Responsabilidades
 *
 * 1. Ler bytes da UART de forma bloqueante.
 * 2. Para cada byte, verificar se é '?' ANTES de acumular no buffer:
 *    - Se sim: ler g_state (mutex), enviar status imediatamente, continuar.
 *    - Se não: acumular no buffer de linha.
 * 3. Ao detectar '\n': enviar a linha completa para g_cmd_queue.
 *
 * # Por que '?' é tratado aqui e não no Parser?
 *
 * O '?' é um "comando de tempo real" no protocolo GRBL — deve ser respondido
 * imediatamente, mesmo que a cmd_queue esteja cheia ou o Parser esteja ocupado.
 * Se o '?' fosse pela fila normal, a latência seria 2–5ms e poderia ser
 * bloqueada por outros comandos. Aqui a latência é ~200–500µs.
 */

#include "task_uart.h"
#include "system_state.h"
#include "grbl_protocol.h"
#include "config.h"

#include "freertos/FreeRTOS.h"
#include "freertos/queue.h"
#include "freertos/semphr.h"
#include "driver/uart.h"
#include "esp_log.h"

static const char *TAG = "task_uart";

void task_uart(void *pvParameters)
{
    (void)pvParameters;

    char     line_buf[CMD_QUEUE_ITEM_SIZE];
    uint16_t buf_idx = 0;
    uint8_t  rx_byte;

    ESP_LOGI(TAG, "UARTTask iniciada");

    for (;;) {
        /* Bloqueia até receber pelo menos 1 byte (timeout = portMAX_DELAY) */
        int len = uart_read_bytes(UART_PORT_NUM, &rx_byte, 1,
                                  portMAX_DELAY);
        if (len <= 0) {
            continue;
        }

        /* ------------------------------------------------------------------
         * DETECÇÃO DE COMANDO DE TEMPO REAL: '?'
         * Responde imediatamente sem tocar na fila de comandos.
         * ---------------------------------------------------------------- */
        if (rx_byte == '?') {
            system_state_t snap;

            /* Leitura do estado com timeout curto — não pode bloquear muito */
            if (xSemaphoreTake(g_state_mutex,
                               pdMS_TO_TICKS(MUTEX_TIMEOUT_MS)) == pdTRUE) {
                snap = g_state;  /* Cópia atômica do estado */
                xSemaphoreGive(g_state_mutex);
                grbl_send_status(&snap);
            }
            /* Descarta o '?' — não vai para o buffer de linha */
            continue;
        }

        /* ------------------------------------------------------------------
         * ACUMULAÇÃO DE LINHA
         * Ignora '\r' (compatibilidade com terminais Windows).
         * ---------------------------------------------------------------- */
        if (rx_byte == '\r') {
            continue;
        }

        /* Guarda byte no buffer com proteção contra overflow */
        if (buf_idx < (CMD_QUEUE_ITEM_SIZE - 1)) {
            line_buf[buf_idx++] = (char)rx_byte;
        } else {
            /* Buffer cheio sem '\n' — linha muito longa, descarta e reseta */
            ESP_LOGW(TAG, "Linha muito longa, descartada");
            buf_idx = 0;
        }

        /* ------------------------------------------------------------------
         * FIM DE LINHA: enfileira e reseta buffer
         * ---------------------------------------------------------------- */
        if (rx_byte == '\n') {
            line_buf[buf_idx] = '\0';  /* Garante terminação */

            /* timeout=0: se a fila estiver cheia, descarta esta linha.
             * O host não deveria ter enviado sem receber 'ok' primeiro. */
            if (xQueueSend(g_cmd_queue, line_buf, 0) != pdTRUE) {
                ESP_LOGW(TAG, "cmd_queue cheia, linha descartada: %.20s", line_buf);
            }

            buf_idx = 0;
        }
    }
}
