/**
 * @file hal_extruder.c
 * @brief Implementação da HAL do extrusor.
 */

#include "hal_extruder.h"
#include "config.h"
#include "driver/gpio.h"
#include "esp_log.h"

static const char *TAG = "hal_extruder";

/** Estado interno do extrusor (evita leitura de GPIO para hal_extruder_is_on). */
static bool s_extruder_on = false;

esp_err_t hal_extruder_init(void)
{
    gpio_config_t io_conf = {
        .pin_bit_mask = (1ULL << GPIO_EXTRUDER),
        .mode         = GPIO_MODE_OUTPUT,
        .pull_up_en   = GPIO_PULLUP_DISABLE,
        .pull_down_en = GPIO_PULLDOWN_DISABLE,
        .intr_type    = GPIO_INTR_DISABLE,
    };

    esp_err_t ret = gpio_config(&io_conf);
    if (ret != ESP_OK) {
        ESP_LOGE(TAG, "Erro ao configurar GPIO do extrusor: %s", esp_err_to_name(ret));
        return ret;
    }

    /* Estado inicial: extrusor desligado */
    gpio_set_level(GPIO_EXTRUDER, 0);
    s_extruder_on = false;

    ESP_LOGI(TAG, "Extrusor inicializado (GPIO%d, desligado)", GPIO_EXTRUDER);
    return ESP_OK;
}

void hal_extruder_on(void)
{
    gpio_set_level(GPIO_EXTRUDER, 1);
    s_extruder_on = true;
}

void hal_extruder_off(void)
{
    gpio_set_level(GPIO_EXTRUDER, 0);
    s_extruder_on = false;
}

bool hal_extruder_is_on(void)
{
    return s_extruder_on;
}
