/**
 * @file hal_stepper.c
 * @brief Implementação da HAL de motores de passo.
 *
 * A função hal_stepper_step() é marcada IRAM_ATTR e usa esp_rom_delay_us()
 * (também em IRAM) para gerar o pulso de largura mínima exigida pelo driver.
 * Não usa vTaskDelay() nem nenhuma primitiva FreeRTOS.
 */

#include "hal_stepper.h"
#include "config.h"
#include "driver/gpio.h"
#include "esp_rom_sys.h"
#include "esp_log.h"

static const char *TAG = "hal_stepper";

/* ===========================================================================
 * INICIALIZAÇÃO
 * ========================================================================= */

esp_err_t hal_stepper_init(void)
{
    /* Configura todos os pinos de STEP, DIR e EN como saídas */
    gpio_config_t io_conf = {
        .pin_bit_mask = (1ULL << GPIO_STEP_X) |
                        (1ULL << GPIO_DIR_X)  |
                        (1ULL << GPIO_EN_X)   |
                        (1ULL << GPIO_STEP_Y) |
                        (1ULL << GPIO_DIR_Y)  |
                        (1ULL << GPIO_EN_Y),
        .mode         = GPIO_MODE_OUTPUT,
        .pull_up_en   = GPIO_PULLUP_DISABLE,
        .pull_down_en = GPIO_PULLDOWN_DISABLE,
        .intr_type    = GPIO_INTR_DISABLE,
    };

    esp_err_t ret = gpio_config(&io_conf);
    if (ret != ESP_OK) {
        ESP_LOGE(TAG, "Erro ao configurar GPIOs do stepper: %s", esp_err_to_name(ret));
        return ret;
    }

    /* Estado inicial: drivers desabilitados, DIR em baixo */
    gpio_set_level(GPIO_EN_X,   DRIVER_DISABLE_LEVEL);
    gpio_set_level(GPIO_EN_Y,   DRIVER_DISABLE_LEVEL);
    gpio_set_level(GPIO_STEP_X, 0);
    gpio_set_level(GPIO_STEP_Y, 0);
    gpio_set_level(GPIO_DIR_X,  0);
    gpio_set_level(GPIO_DIR_Y,  0);

    ESP_LOGI(TAG, "Motores de passo inicializados (driver: %s)",
#ifdef STEPPER_DRIVER_A4988
             "A4988"
#else
             "DRV8825"
#endif
    );

    return ESP_OK;
}

/* ===========================================================================
 * CONTROLE DE DIREÇÃO
 * ========================================================================= */

void hal_stepper_set_dir(stepper_axis_t axis, int8_t dir)
{
    /* dir > 0 → pino em HIGH; dir <= 0 → pino em LOW */
    int level = (dir > 0) ? 1 : 0;

    if (axis == AXIS_X) {
        gpio_set_level(GPIO_DIR_X, level);
    } else {
        gpio_set_level(GPIO_DIR_Y, level);
    }
}

/* ===========================================================================
 * GERAÇÃO DE PULSO STEP (IRAM — chamada pela ISR)
 * ========================================================================= */

/**
 * O pulso respeita o setup time do DIR (mín 1µs — garantido pelo Executor
 * que configura DIR antes de armar o GPTimer) e a largura mínima de HIGH
 * definida em STEP_PULSE_WIDTH_US.
 *
 * esp_rom_delay_us() reside em ROM/IRAM e é segura para uso em ISR.
 */
void IRAM_ATTR hal_stepper_step(stepper_axis_t axis)
{
    if (axis == AXIS_X) {
        gpio_set_level(GPIO_STEP_X, 1);
        esp_rom_delay_us(STEP_PULSE_WIDTH_US);
        gpio_set_level(GPIO_STEP_X, 0);
    } else {
        gpio_set_level(GPIO_STEP_Y, 1);
        esp_rom_delay_us(STEP_PULSE_WIDTH_US);
        gpio_set_level(GPIO_STEP_Y, 0);
    }
}

/* ===========================================================================
 * HABILITAÇÃO / DESABILITAÇÃO
 * ========================================================================= */

void hal_stepper_enable(void)
{
    gpio_set_level(GPIO_EN_X, DRIVER_ENABLE_LEVEL);
    gpio_set_level(GPIO_EN_Y, DRIVER_ENABLE_LEVEL);
}

void hal_stepper_disable(void)
{
    gpio_set_level(GPIO_EN_X, DRIVER_DISABLE_LEVEL);
    gpio_set_level(GPIO_EN_Y, DRIVER_DISABLE_LEVEL);
}
