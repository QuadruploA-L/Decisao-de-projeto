/**
 * @file hal_endstop.c
 * @brief Implementação da HAL de fins de curso.
 *
 * Pinos configurados como entrada com pull-up interno.
 * Sensor acionado = GPIO em LOW (lógica invertida).
 */

#include "hal_endstop.h"
#include "config.h"
#include "driver/gpio.h"
#include "esp_log.h"

static const char *TAG = "hal_endstop";

esp_err_t hal_endstop_init(void)
{
    gpio_config_t io_conf = {
        .pin_bit_mask = (1ULL << GPIO_ENDSTOP_X) |
                        (1ULL << GPIO_ENDSTOP_Y),
        .mode         = GPIO_MODE_INPUT,
        .pull_up_en   = GPIO_PULLUP_ENABLE,   /* Pull-up interno */
        .pull_down_en = GPIO_PULLDOWN_DISABLE,
        .intr_type    = GPIO_INTR_DISABLE,
    };

    esp_err_t ret = gpio_config(&io_conf);
    if (ret != ESP_OK) {
        ESP_LOGE(TAG, "Erro ao configurar GPIOs de endstop: %s", esp_err_to_name(ret));
        return ret;
    }

    ESP_LOGI(TAG, "Fins de curso inicializados (X=GPIO%d, Y=GPIO%d)",
             GPIO_ENDSTOP_X, GPIO_ENDSTOP_Y);
    return ESP_OK;
}

bool hal_endstop_read_x(void)
{
    /* Lógica invertida: LOW = acionado */
    return (gpio_get_level(GPIO_ENDSTOP_X) == 0);
}

bool hal_endstop_read_y(void)
{
    return (gpio_get_level(GPIO_ENDSTOP_Y) == 0);
}
