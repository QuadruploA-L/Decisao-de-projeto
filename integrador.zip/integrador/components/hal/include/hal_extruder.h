/**
 * @file hal_extruder.h
 * @brief Interface da HAL para controle do extrusor (ON/OFF).
 *
 * O extrusor é controlado por uma saída digital simples.
 * HIGH = ligado (M3), LOW = desligado (M5).
 */

#ifndef HAL_EXTRUDER_H
#define HAL_EXTRUDER_H

#include <stdbool.h>
#include "esp_err.h"

/**
 * @brief Inicializa o pino do extrusor como saída e desliga.
 *
 * @return ESP_OK em sucesso.
 */
esp_err_t hal_extruder_init(void);

/**
 * @brief Liga o extrusor (equivalente ao comando M3).
 */
void hal_extruder_on(void);

/**
 * @brief Desliga o extrusor (equivalente ao comando M5).
 */
void hal_extruder_off(void);

/**
 * @brief Retorna o estado atual do extrusor.
 *
 * @return true se o extrusor está ligado.
 * @return false se está desligado.
 */
bool hal_extruder_is_on(void);

#endif /* HAL_EXTRUDER_H */
