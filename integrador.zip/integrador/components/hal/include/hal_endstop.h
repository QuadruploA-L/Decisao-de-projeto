/**
 * @file hal_endstop.h
 * @brief Interface da HAL para sensores de fim de curso.
 *
 * Os fins de curso são configurados como entradas com pull-up interno.
 * Estado acionado = nível LOW (normalmente fechado com GND).
 */

#ifndef HAL_ENDSTOP_H
#define HAL_ENDSTOP_H

#include <stdbool.h>
#include "esp_err.h"

/**
 * @brief Inicializa os pinos de fim de curso como entradas com pull-up.
 *
 * @return ESP_OK em sucesso.
 */
esp_err_t hal_endstop_init(void);

/**
 * @brief Lê o estado do fim de curso do eixo X.
 *
 * @return true se o endstop está acionado (pino em LOW).
 * @return false se está livre.
 */
bool hal_endstop_read_x(void);

/**
 * @brief Lê o estado do fim de curso do eixo Y.
 *
 * @return true se o endstop está acionado.
 * @return false se está livre.
 */
bool hal_endstop_read_y(void);

#endif /* HAL_ENDSTOP_H */
