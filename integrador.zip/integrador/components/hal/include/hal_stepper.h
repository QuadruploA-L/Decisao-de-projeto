/**
 * @file hal_stepper.h
 * @brief Interface da HAL para motores de passo (A4988 / DRV8825).
 *
 * Abstrai o hardware do driver de passo. A seleção entre A4988 e DRV8825
 * é feita em config.h por definição de macro, sem impacto nesta interface.
 *
 * @note hal_stepper_step() é marcada IRAM_ATTR pois é chamada pela ISR
 *       do GPTimer. CONFIG_GPIO_CTRL_FUNC_IN_IRAM=y deve estar ativo.
 */

#ifndef HAL_STEPPER_H
#define HAL_STEPPER_H

#include <stdbool.h>
#include "esp_err.h"

/**
 * @brief Identificador de eixo.
 */
typedef enum {
    AXIS_X = 0,  /**< Eixo X */
    AXIS_Y = 1,  /**< Eixo Y */
} stepper_axis_t;

/**
 * @brief Inicializa os GPIOs dos dois motores de passo.
 *
 * Configura STEP, DIR e EN como saídas. Desabilita os drivers (EN=HIGH)
 * e coloca DIR em nível baixo como estado inicial seguro.
 *
 * @return ESP_OK em sucesso, ESP_FAIL em caso de erro de GPIO.
 */
esp_err_t hal_stepper_init(void);

/**
 * @brief Define a direção de rotação de um eixo.
 *
 * @param axis  Eixo alvo (AXIS_X ou AXIS_Y).
 * @param dir   +1 para direção positiva, -1 para negativa.
 */
void hal_stepper_set_dir(stepper_axis_t axis, int8_t dir);

/**
 * @brief Gera um pulso STEP em um eixo.
 *
 * Eleva o pino STEP, aguarda STEP_PULSE_WIDTH_US e desce.
 * Esta função é chamada pela ISR do GPTimer e deve residir em IRAM.
 *
 * @param axis  Eixo a avançar (AXIS_X ou AXIS_Y).
 */
void IRAM_ATTR hal_stepper_step(stepper_axis_t axis);

/**
 * @brief Habilita os drivers de ambos os eixos (EN = LOW).
 */
void hal_stepper_enable(void);

/**
 * @brief Desabilita os drivers de ambos os eixos (EN = HIGH).
 *
 * Desabilitar os drivers reduz o aquecimento quando parado.
 * O motor perde torque de retenção ao ser desabilitado.
 */
void hal_stepper_disable(void);

#endif /* HAL_STEPPER_H */
