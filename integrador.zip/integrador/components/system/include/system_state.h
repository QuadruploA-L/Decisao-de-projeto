/**
 * @file system_state.h
 * @brief Estado global do sistema e handles de primitivas FreeRTOS.
 *
 * Centraliza todos os objetos de IPC (inter-process communication) do FreeRTOS
 * que são compartilhados entre tarefas. Todas as tarefas importam este header
 * para acessar filas, mutexes e o event group.
 *
 * @note Regras de uso:
 *  - g_state deve ser acessado APENAS via state_mutex.
 *  - UART TX deve ser acessado APENAS via uart_tx_mutex (através de grbl_protocol.h).
 *  - Nunca adquirir mutex dentro de ISR — usar apenas versões FromISR.
 */

#ifndef SYSTEM_STATE_H
#define SYSTEM_STATE_H

#include "gcode_types.h"
#include "freertos/FreeRTOS.h"
#include "freertos/queue.h"
#include "freertos/semphr.h"
#include "freertos/event_groups.h"
#include "freertos/task.h"

/* ===========================================================================
 * BITS DO EVENT GROUP
 * ========================================================================= */

/** @defgroup EventGroupBits Bits do motion_event_group
 * @{
 */
#define EVENT_HOMING_DONE  BIT0  /**< Sinalizado pelo Executor ao concluir G28 */
#define EVENT_BLOCK_DONE   BIT1  /**< Sinalizado pela ISR ao concluir um bloco */
#define EVENT_ALARM        BIT2  /**< Sinalizado em caso de erro (endstop, overflow) */
/** @} */

/* ===========================================================================
 * HANDLES DAS FILAS
 * ========================================================================= */

/** @brief Fila de comandos brutos: UARTTask → GCodeParserTask.
 *  Item: char[CMD_QUEUE_ITEM_SIZE] */
extern QueueHandle_t g_cmd_queue;

/** @brief Fila de comandos de movimento: GCodeParserTask → MotionPlannerTask.
 *  Item: motion_cmd_t */
extern QueueHandle_t g_motion_queue;

/** @brief Buffer de planejamento: MotionPlannerTask → MotionExecutorTask.
 *  Item: motion_block_t. Capacidade: PLANNER_QUEUE_LEN blocos. */
extern QueueHandle_t g_planner_queue;

/* ===========================================================================
 * HANDLES DOS MUTEXES
 * ========================================================================= */

/** @brief Mutex que protege g_state. Todos acessos a system_state_t passam por ele. */
extern SemaphoreHandle_t g_state_mutex;

/** @brief Mutex que protege uart_write_bytes(). Encapsulado em grbl_protocol.c. */
extern SemaphoreHandle_t g_uart_tx_mutex;

/* ===========================================================================
 * HANDLE DO EVENT GROUP
 * ========================================================================= */

/** @brief Event group para sinalização entre Executor, ISR e outras tarefas. */
extern EventGroupHandle_t g_motion_event_group;

/* ===========================================================================
 * HANDLE DA TAREFA EXECUTORA
 * A ISR precisa deste handle para xTaskNotifyFromISR.
 * ========================================================================= */

/** @brief Handle da MotionExecutorTask, usado pela ISR para notificação. */
extern TaskHandle_t g_executor_task_handle;

/* ===========================================================================
 * ESTADO GLOBAL DA MÁQUINA
 * ========================================================================= */

/** @brief Estado global da máquina. Acesso somente via g_state_mutex. */
extern system_state_t g_state;

/* ===========================================================================
 * FUNÇÕES DE INICIALIZAÇÃO
 * ========================================================================= */

/**
 * @brief Inicializa todas as primitivas FreeRTOS e o estado da máquina.
 *
 * Deve ser chamado pelo app_main() ANTES de criar qualquer tarefa.
 * Cria cmd_queue, motion_queue, planner_queue, state_mutex, uart_tx_mutex
 * e motion_event_group. Inicializa g_state com valores padrão (IDLE).
 *
 * @return true se todas as primitivas foram criadas com sucesso.
 * @return false se alguma alocação de memória falhou (heap insuficiente).
 */
bool system_state_init(void);

#endif /* SYSTEM_STATE_H */
