/**
 * @file system_state.c
 * @brief Definição e inicialização do estado global e primitivas FreeRTOS.
 *
 * Este arquivo contém as definições (não apenas declarações) de todas as
 * variáveis globais do sistema. A separação entre .h (extern) e .c (definição)
 * segue o padrão C para variáveis globais compartilhadas entre módulos.
 */

#include "system_state.h"
#include "config.h"
#include "esp_log.h"

static const char *TAG = "system_state";

/* ===========================================================================
 * DEFINIÇÕES DAS VARIÁVEIS GLOBAIS
 * ========================================================================= */

QueueHandle_t     g_cmd_queue           = NULL;
QueueHandle_t     g_motion_queue        = NULL;
QueueHandle_t     g_planner_queue       = NULL;
SemaphoreHandle_t g_state_mutex         = NULL;
SemaphoreHandle_t g_uart_tx_mutex       = NULL;
EventGroupHandle_t g_motion_event_group = NULL;
TaskHandle_t      g_executor_task_handle = NULL;

system_state_t g_state = {
    .status            = STATE_IDLE,
    .mpos_x            = 0.0f,
    .mpos_y            = 0.0f,
    .feedrate          = DEFAULT_FEEDRATE_MM_MIN,
    .extruder_on       = false,
    .position_absolute = true,  /* G90 é o padrão */
};

/* ===========================================================================
 * INICIALIZAÇÃO
 * ========================================================================= */

bool system_state_init(void)
{
    /* --- Filas --- */
    g_cmd_queue = xQueueCreate(CMD_QUEUE_LEN, CMD_QUEUE_ITEM_SIZE);
    if (g_cmd_queue == NULL) {
        ESP_LOGE(TAG, "Falha ao criar g_cmd_queue");
        return false;
    }

    g_motion_queue = xQueueCreate(MOTION_QUEUE_LEN, sizeof(motion_cmd_t));
    if (g_motion_queue == NULL) {
        ESP_LOGE(TAG, "Falha ao criar g_motion_queue");
        return false;
    }

    g_planner_queue = xQueueCreate(PLANNER_QUEUE_LEN, sizeof(motion_block_t));
    if (g_planner_queue == NULL) {
        ESP_LOGE(TAG, "Falha ao criar g_planner_queue");
        return false;
    }

    /* --- Mutexes (com priority inheritance automática no FreeRTOS) --- */
    g_state_mutex = xSemaphoreCreateMutex();
    if (g_state_mutex == NULL) {
        ESP_LOGE(TAG, "Falha ao criar g_state_mutex");
        return false;
    }

    g_uart_tx_mutex = xSemaphoreCreateMutex();
    if (g_uart_tx_mutex == NULL) {
        ESP_LOGE(TAG, "Falha ao criar g_uart_tx_mutex");
        return false;
    }

    /* --- Event Group --- */
    g_motion_event_group = xEventGroupCreate();
    if (g_motion_event_group == NULL) {
        ESP_LOGE(TAG, "Falha ao criar g_motion_event_group");
        return false;
    }

    ESP_LOGI(TAG, "Sistema inicializado. RAM livre: %lu bytes",
             (unsigned long)esp_get_free_heap_size());

    return true;
}
