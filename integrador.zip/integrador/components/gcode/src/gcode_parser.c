/**
 * @file gcode_parser.c
 * @brief Implementação do interpretador G-Code.
 *
 * @note Implementação completa na Etapa 3.
 *       Esta versão contém a estrutura, os stubs e os estados internos.
 */

#include "gcode_parser.h"
#include "gcode_types.h"
#include "system_state.h"
#include "grbl_protocol.h"
#include "config.h"

#include "freertos/FreeRTOS.h"
#include "freertos/queue.h"
#include "freertos/semphr.h"
#include "freertos/event_groups.h"
#include "esp_log.h"
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include <math.h>

static const char *TAG = "gcode_parser";

/* ===========================================================================
 * ESTADO INTERNO DO PARSER (persistente entre chamadas)
 * ========================================================================= */

/** Posição de planejamento — separada de g_state.mpos (posição de execução).
 *  Necessária para resolver coordenadas G91 (relativas) de blocos futuros
 *  que ainda estão na planner_queue. */
static float s_plan_x    = 0.0f;
static float s_plan_y    = 0.0f;
static float s_feedrate  = DEFAULT_FEEDRATE_MM_MIN;
static bool  s_absolute  = true;  /* G90 por padrão */

/* ===========================================================================
 * UTILITÁRIOS INTERNOS
 * ========================================================================= */

/** Verifica se a linha é vazia ou comentário. */
static bool is_empty_or_comment(const char *line)
{
    while (*line) {
        if (*line == ';') return true;  /* Comentário */
        if (*line != ' ' && *line != '\t' && *line != '\r' && *line != '\n') {
            return false;
        }
        line++;
    }
    return true;
}

/** Converte string para uppercase em buffer local. */
static void to_upper(const char *src, char *dst, size_t max)
{
    size_t i;
    for (i = 0; i < max - 1 && src[i]; i++) {
        dst[i] = (char)toupper((unsigned char)src[i]);
    }
    dst[i] = '\0';
}

/**
 * @brief Encontra o valor numérico de uma palavra G-Code na linha.
 *
 * Exemplo: linha = "G1 X50.5 Y-10 F600", letra = 'X' → retorna 50.5, found=true.
 *
 * @param line  Linha em uppercase.
 * @param letter Letra da palavra (ex: 'X', 'Y', 'F', 'G', 'M').
 * @param value  Ponteiro para receber o valor encontrado.
 * @return true se a palavra foi encontrada.
 */
static bool find_word(const char *line, char letter, float *value)
{
    const char *p = line;
    while (*p) {
        if (*p == letter) {
            p++;
            /* Pula espaços após a letra */
            while (*p == ' ') p++;
            /* Verifica se há número (incluindo sinal) */
            if (*p == '-' || *p == '+' || isdigit((unsigned char)*p) || *p == '.') {
                *value = strtof(p, NULL);
                return true;
            }
        }
        p++;
    }
    return false;
}

/* ===========================================================================
 * IMPLEMENTAÇÃO PRINCIPAL
 * ========================================================================= */

void gcode_parse_line(const char *line)
{
    /* Ignora linhas vazias e comentários */
    if (is_empty_or_comment(line)) {
        return;
    }

    /* Converte para uppercase para parsing case-insensitive */
    char upper[CMD_QUEUE_ITEM_SIZE];
    to_upper(line, upper, sizeof(upper));

    float val;
    motion_cmd_t cmd = {0};
    cmd.extruder_action = -1;  /* Sem mudança por padrão */

    /* ------------------------------------------------------------------
     * G90 / G91 — Modo de posicionamento (atualização imediata de estado)
     * ---------------------------------------------------------------- */
    if (find_word(upper, 'G', &val)) {
        int g_code = (int)val;

        if (g_code == 90) {
            s_absolute = true;
            if (xSemaphoreTake(g_state_mutex, pdMS_TO_TICKS(MUTEX_TIMEOUT_MS)) == pdTRUE) {
                g_state.position_absolute = true;
                xSemaphoreGive(g_state_mutex);
            }
            grbl_send_ok();
            return;
        }

        if (g_code == 91) {
            s_absolute = false;
            if (xSemaphoreTake(g_state_mutex, pdMS_TO_TICKS(MUTEX_TIMEOUT_MS)) == pdTRUE) {
                g_state.position_absolute = false;
                xSemaphoreGive(g_state_mutex);
            }
            grbl_send_ok();
            return;
        }

        /* G28 — Homing */
        if (g_code == 28) {
            cmd.type = CMD_HOMING;
            cmd.feedrate = HOMING_FEEDRATE_MM_MIN;
            xQueueSend(g_motion_queue, &cmd, portMAX_DELAY);

            /* Aguarda o Executor concluir o homing antes de responder ok */
            xEventGroupWaitBits(g_motion_event_group,
                                EVENT_HOMING_DONE,
                                pdTRUE,   /* Limpa o bit */
                                pdFALSE,
                                portMAX_DELAY);

            /* Reseta posição de planejamento após homing */
            s_plan_x = 0.0f;
            s_plan_y = 0.0f;

            grbl_send_ok();
            return;
        }

        /* G0 ou G1 — Movimento */
        if (g_code == 0 || g_code == 1) {
            cmd.type = (g_code == 0) ? CMD_MOVE_G0 : CMD_MOVE_G1;

            /* Atualiza feedrate se 'F' presente na mesma linha */
            if (find_word(upper, 'F', &val) && val > 0.0f) {
                s_feedrate = (val > MAX_FEEDRATE_MM_MIN) ? MAX_FEEDRATE_MM_MIN : val;
            }
            cmd.feedrate = (g_code == 0) ? MAX_FEEDRATE_MM_MIN : s_feedrate;

            /* Resolve coordenadas X e Y */
            float target_x = s_plan_x;
            float target_y = s_plan_y;

            bool has_x = find_word(upper, 'X', &val);
            bool has_y = find_word(upper, 'Y', &val);

            if (has_x) {
                /* Re-busca X (find_word modifica val) */
                find_word(upper, 'X', &val);
                target_x = s_absolute ? val : (s_plan_x + val);
            }
            if (has_y) {
                find_word(upper, 'Y', &val);
                target_y = s_absolute ? val : (s_plan_y + val);
            }

            cmd.target_x = target_x;
            cmd.target_y = target_y;

            /* Atualiza posição de planejamento */
            s_plan_x = target_x;
            s_plan_y = target_y;

            xQueueSend(g_motion_queue, &cmd, portMAX_DELAY);
            grbl_send_ok();
            return;
        }
    }

    /* ------------------------------------------------------------------
     * M-Codes
     * ---------------------------------------------------------------- */
    if (find_word(upper, 'M', &val)) {
        int m_code = (int)val;

        /* M3 — Liga extrusor */
        if (m_code == 3) {
            cmd.type            = CMD_EXTRUDER_ONLY;
            cmd.target_x        = s_plan_x;
            cmd.target_y        = s_plan_y;
            cmd.extruder_action = 1;
            xQueueSend(g_motion_queue, &cmd, portMAX_DELAY);
            grbl_send_ok();
            return;
        }

        /* M5 — Desliga extrusor */
        if (m_code == 5) {
            cmd.type            = CMD_EXTRUDER_ONLY;
            cmd.target_x        = s_plan_x;
            cmd.target_y        = s_plan_y;
            cmd.extruder_action = 0;
            xQueueSend(g_motion_queue, &cmd, portMAX_DELAY);
            grbl_send_ok();
            return;
        }

        /* M114 — Reporta posição de execução atual */
        if (m_code == 114) {
            float px, py;
            if (xSemaphoreTake(g_state_mutex, pdMS_TO_TICKS(MUTEX_TIMEOUT_MS)) == pdTRUE) {
                px = g_state.mpos_x;
                py = g_state.mpos_y;
                xSemaphoreGive(g_state_mutex);
            } else {
                px = s_plan_x;
                py = s_plan_y;
            }
            grbl_send_position(px, py);
            grbl_send_ok();
            return;
        }
    }

    /* ------------------------------------------------------------------
     * F — Feedrate standalone (ex: "F1200")
     * ---------------------------------------------------------------- */
    if (find_word(upper, 'F', &val) && val > 0.0f) {
        s_feedrate = (val > MAX_FEEDRATE_MM_MIN) ? MAX_FEEDRATE_MM_MIN : val;
        if (xSemaphoreTake(g_state_mutex, pdMS_TO_TICKS(MUTEX_TIMEOUT_MS)) == pdTRUE) {
            g_state.feedrate = s_feedrate;
            xSemaphoreGive(g_state_mutex);
        }
        grbl_send_ok();
        return;
    }

    /* Comando não reconhecido */
    ESP_LOGW(TAG, "Comando desconhecido: %.40s", line);
    grbl_send_error();
}
