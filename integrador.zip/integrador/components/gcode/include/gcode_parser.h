/**
 * @file gcode_parser.h
 * @brief Interface do módulo de interpretação G-Code.
 *
 * O parser é stateful: mantém plan_x, plan_y e o feedrate ativo
 * entre chamadas. É chamado sequencialmente pela GCodeParserTask —
 * não é reentrante.
 *
 * @note Implementação completa na Etapa 3.
 */

#ifndef GCODE_PARSER_H
#define GCODE_PARSER_H

/**
 * @brief Interpreta uma linha G-Code e enfileira os comandos resultantes.
 *
 * Tokeniza a linha, identifica palavras G-Code (letra + número),
 * resolve coordenadas (G90/G91), cria motion_cmd_t e envia para
 * g_motion_queue. Envia 'ok' ou 'error' ao host via grbl_protocol.
 *
 * Linhas vazias e comentários são ignorados silenciosamente.
 *
 * @param line String de linha G-Code terminada em '\0'.
 */
void gcode_parse_line(const char *line);

#endif /* GCODE_PARSER_H */
