/**
 * @file gcode_types.h
 * @brief Definição de todos os tipos de dados compartilhados entre módulos.
 *
 * Este arquivo centraliza as estruturas que trafegam pelas filas FreeRTOS,
 * evitando dependências circulares entre componentes. Qualquer módulo que
 * precise de um tipo de dado importa apenas este header.
 */

#ifndef GCODE_TYPES_H
#define GCODE_TYPES_H

#include <stdint.h>
#include <stdbool.h>

/* ===========================================================================
 * TIPOS DE COMANDO DE MOVIMENTO
 * ========================================================================= */

/**
 * @brief Tipo de comando gerado pelo GCodeParser e consumido pelo Planner.
 */
typedef enum {
    CMD_MOVE_G0,        /**< Movimento rápido (G0) — usa MAX_FEEDRATE */
    CMD_MOVE_G1,        /**< Movimento linear controlado (G1) */
    CMD_HOMING,         /**< Sequência de homing (G28) */
    CMD_EXTRUDER_ONLY,  /**< Somente mudança de estado do extrusor (M3/M5 sem XY) */
} motion_cmd_type_t;

/**
 * @brief Comando de movimento gerado pelo GCodeParser.
 *
 * Trafega pela motion_queue do Parser para o Planner.
 * As coordenadas target_x/y já estão em coordenadas absolutas (G91 resolvido pelo Parser).
 */
typedef struct {
    motion_cmd_type_t type;    /**< Tipo do comando */
    float target_x;            /**< Posição alvo X em mm (absoluta) */
    float target_y;            /**< Posição alvo Y em mm (absoluta) */
    float feedrate;            /**< Feedrate em mm/min */
    int8_t extruder_action;    /**< -1=sem mudança, 0=desligar (M5), 1=ligar (M3) */
} motion_cmd_t;

/* ===========================================================================
 * BLOCO DE MOVIMENTO
 * ========================================================================= */

/**
 * @brief Bloco de movimento calculado pelo Planner e executado pelo Executor.
 *
 * Contém todos os parâmetros necessários para a ISR do GPTimer executar
 * o movimento: parâmetros Bresenham para interpolação linear e parâmetros
 * do perfil trapezoidal para controle de velocidade.
 *
 * Trafega pela planner_queue do Planner para o Executor.
 */
typedef struct {
    /* --- Identificação do tipo de bloco --- */
    bool is_homing;         /**< true = bloco especial de homing (G28) */

    /* --- Parâmetros de direção e passos totais --- */
    int32_t steps_x;        /**< Passos totais no eixo X (com sinal = direção) */
    int32_t steps_y;        /**< Passos totais no eixo Y (com sinal = direção) */
    int8_t  dir_x;          /**< Direção X: +1 ou -1 */
    int8_t  dir_y;          /**< Direção Y: +1 ou -1 */

    /* --- Parâmetros do algoritmo de Bresenham --- */
    int32_t dominant;       /**< max(|steps_x|, |steps_y|) — eixo com mais passos */
    int32_t subordinate;    /**< min(|steps_x|, |steps_y|) — eixo com menos passos */
    int32_t bresenham_error;/**< Acumulador de erro inicial = dominant / 2 */
    bool    dominant_is_x;  /**< true se o eixo X é o dominante */

    /* --- Parâmetros do perfil trapezoidal --- */
    uint32_t total_steps;       /**< Total de passos do eixo dominante (= dominant) */
    uint32_t accel_steps;       /**< Passos na fase de aceleração */
    uint32_t decel_step_start;  /**< Índice do primeiro passo na fase de desaceleração */
    uint32_t initial_period_us; /**< Período do 1º passo (maior = mais lento) */
    uint32_t min_period_us;     /**< Período mínimo (velocidade de cruzeiro) */
    uint32_t accel_increment;   /**< Redução de period por passo na aceleração */
    uint32_t decel_increment;   /**< Aumento de period por passo na desaceleração */

    /* --- Estado do extrusor a aplicar antes de executar este bloco --- */
    int8_t extruder_action;     /**< -1=sem mudança, 0=desligar, 1=ligar */
} motion_block_t;

/* ===========================================================================
 * ESTADO DA MÁQUINA
 * ========================================================================= */

/**
 * @brief Estados possíveis da máquina CNC.
 */
typedef enum {
    STATE_IDLE,    /**< Parada, aguardando comandos */
    STATE_RUN,     /**< Executando movimento */
    STATE_HOMING,  /**< Executando sequência de homing (G28) */
    STATE_ALARM,   /**< Erro — requer reset para continuar */
} machine_state_t;

/**
 * @brief Estado global do sistema, protegido por state_mutex.
 *
 * Representa o estado atual da máquina do ponto de vista do host:
 * posição física da ferramenta, estado dos atuadores e modo de operação.
 *
 * @note mpos_x/y reflete a posição após a execução dos blocos.
 *       Pode divergir temporariamente de plan_x/y (posição de planejamento)
 *       quando há blocos na planner_queue ainda não executados.
 */
typedef struct {
    machine_state_t status;       /**< Estado atual da máquina */
    float           mpos_x;       /**< Posição física atual X em mm */
    float           mpos_y;       /**< Posição física atual Y em mm */
    float           feedrate;     /**< Feedrate ativo em mm/min */
    bool            extruder_on;  /**< Estado atual do extrusor */
    bool            position_absolute; /**< true=G90 (absoluto), false=G91 (relativo) */
} system_state_t;

#endif /* GCODE_TYPES_H */
