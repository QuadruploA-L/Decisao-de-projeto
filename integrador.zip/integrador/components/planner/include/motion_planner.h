/**
 * @file motion_planner.h
 * @brief Interface do planejador de movimento (Bresenham + perfil trapezoidal).
 *
 * O planejador é stateful: mantém a posição de planejamento interna
 * (em passos inteiros) entre chamadas consecutivas, necessária para
 * calcular os deltas de blocos futuros ainda na planner_queue.
 *
 * @note Não é reentrante — deve ser chamado apenas pela MotionPlannerTask.
 */

#ifndef MOTION_PLANNER_H
#define MOTION_PLANNER_H

#include "gcode_types.h"
#include <stdbool.h>

/**
 * @brief Calcula um motion_block_t completo a partir de um motion_cmd_t.
 *
 * Para comandos de movimento (G0/G1):
 *  1. Converte coordenadas-alvo de mm para passos inteiros.
 *  2. Calcula parâmetros do algoritmo de Bresenham.
 *  3. Calcula perfil de velocidade trapezoidal (ou triangular para
 *     movimentos curtos que não atingem a velocidade de cruzeiro).
 *  4. Atualiza a posição de planejamento interna.
 *
 * Para CMD_HOMING: retorna bloco marcador com is_homing=true e reseta
 *  a posição de planejamento para (0,0).
 *
 * Para CMD_EXTRUDER_ONLY: retorna bloco com total_steps=0.
 *
 * @param cmd   Ponteiro para o comando de entrada.
 * @param block Ponteiro para o bloco de saída (preenchido por esta função).
 * @return true  Bloco calculado com sucesso — deve ser enfileirado.
 * @return false Movimento de distância zero — descartar silenciosamente.
 */
bool motion_planner_compute(const motion_cmd_t *cmd, motion_block_t *block);

#endif /* MOTION_PLANNER_H */
