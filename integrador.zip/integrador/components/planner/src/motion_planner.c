/**
 * @file motion_planner.c
 * @brief Planejador de movimento — Bresenham + perfil trapezoidal.
 *
 * =========================================================================
 * FUNDAMENTAÇÃO MATEMÁTICA
 * =========================================================================
 *
 * ## 1. Algoritmo de Bresenham (interpolação linear em passos inteiros)
 *
 * Dado um movimento de (x₀,y₀) até (x₁,y₁) em passos inteiros:
 *
 *   dx = |x₁ - x₀|  (passos totais em X)
 *   dy = |y₁ - y₀|  (passos totais em Y)
 *
 * Define-se o EIXO DOMINANTE como aquele com maior delta:
 *   dominant    = max(dx, dy)   → avança a cada ciclo da ISR (sempre)
 *   subordinate = min(dx, dy)   → avança apenas quando erro acumulado
 *                                  ultrapassa o limiar
 *
 * O acumulador de erro é inicializado como dominant/2 (centro de
 * Bresenham) para minimizar o erro máximo de aproximação:
 *   error_init = dominant / 2
 *
 * A cada ciclo da ISR:
 *   1. Avança eixo dominante (sempre).
 *   2. error += subordinate
 *   3. Se error >= dominant: avança eixo subordinado; error -= dominant
 *
 * Prova de correção: o eixo subordinado avança a cada dominant/subordinate
 * passos do dominante, aproximando a reta real. O erro máximo é sempre
 * menor que 1 passo, que é a resolução máxima do sistema.
 *
 * Exemplo: mover de (0,0) a (5,3):
 *   dx=5, dy=3 → dominante=X, subordinado=Y, error_init=2
 *
 *   Ciclo | Passo X | error+=3 | error≥5? | Passo Y | error final
 *     1   |   ✓     |   2+3=5  |   ✓      |   ✓     |   5-5=0
 *     2   |   ✓     |   0+3=3  |   ✗      |         |   3
 *     3   |   ✓     |   3+3=6  |   ✓      |   ✓     |   6-5=1
 *     4   |   ✓     |   1+3=4  |   ✗      |         |   4
 *     5   |   ✓     |   4+3=7  |   ✓      |   ✓     |   7-5=2
 *
 * Resultado: 5 passos X, 3 passos Y → linha (0,0)→(5,3) interpolada. ✓
 *
 * -------------------------------------------------------------------------
 *
 * ## 2. Perfil de velocidade trapezoidal
 *
 * O perfil divide o movimento em 3 fases:
 *
 *   Velocidade
 *   (steps/s)
 *       │
 *  step │           ╱─────────────╲
 *  rate │          ╱               ╲
 *  max  │         ╱                 ╲
 *       │────────╱                   ╲────────
 *       └──────────────────────────────────── Passos
 *             accel    cruise    decel
 *
 * A variável de controle é o PERÍODO entre pulsos STEP (em µs).
 * Velocidade maior → período menor → timer dispara mais rápido.
 *
 * ### 2.1 Conversão feedrate → step rate
 *
 * Para um movimento diagonal de distância euclideana `d` [mm]:
 *   d = sqrt((dx/STEPS_MM_X)² + (dy/STEPS_MM_Y)²)
 *
 * A taxa de steps do eixo dominante na velocidade de cruzeiro:
 *   step_rate [steps/s] = v_max [mm/s] × (total_steps / d)
 *
 * O período mínimo (cruzeiro):
 *   min_period_us = 1e6 / step_rate
 *
 * ### 2.2 Aceleração em passos/s²
 *
 * A aceleração configurada em mm/s² é convertida para o espaço de passos:
 *   a_steps [steps/s²] = ACCELERATION_MM_S2 × (total_steps / d)
 *
 * ### 2.3 Número de passos nas fases de aceleração e desaceleração
 *
 * Partindo do repouso (v_entry = 0) e parando no final (v_exit = 0):
 *   accel_steps = step_rate² / (2 × a_steps)
 *
 * Se accel_steps × 2 ≥ total_steps: PERFIL TRIANGULAR (não há cruzeiro).
 * Neste caso, a velocidade de pico é recalculada:
 *   accel_steps = total_steps / 2
 *   v_peak_steps = sqrt(2 × a_steps × accel_steps)
 *
 * ### 2.4 Período do primeiro passo (partindo do repouso)
 *
 * Usando cinemática (s = ½at²):
 * O tempo para completar 1 passo a partir do repouso com aceleração a_steps:
 *   t₁ = sqrt(2 × 1_passo / a_steps) = sqrt(2 / a_steps) [s]
 *   initial_period_us = sqrt(2 / a_steps) × 1e6
 *
 * ### 2.5 Incremento de período por passo (rampa linear)
 *
 * Escolha educacional: ramp LINEAR no período (não fisicamente exata,
 * mas sem sqrt() na ISR e com erro < 5% para fins práticos).
 *   accel_increment = (initial_period_us - min_period_us) / accel_steps
 *   decel_increment = accel_increment  (perfil simétrico)
 *
 * Para a ramp exata de GRBL (Approximation of Olds), a equação é:
 *   t_n = t_{n-1} × (2N-1)/(2N+1), onde N = número do passo
 * Isso é equivalente a √n - √(n-1), mas requer multiplicação por passo.
 * A implementação aqui usa a linear por ser mais didática.
 *
 * =========================================================================
 */

#include "motion_planner.h"
#include "config.h"
#include "esp_log.h"

#include <math.h>
#include <stdlib.h>
#include <string.h>

static const char *TAG = "planner";

/* =========================================================================
 * ESTADO INTERNO
 * =========================================================================
 * Posição de planejamento em passos inteiros.
 *
 * DIFERENÇA de g_state.mpos_x/y (posição de EXECUÇÃO):
 *  - s_pos_steps é atualizado quando o Planner PLANEJA o bloco.
 *  - g_state.mpos é atualizado quando o Executor CONCLUI o bloco.
 *  - Entre os dois pode haver vários blocos na planner_queue ainda
 *    não executados.
 *
 * Por que manter aqui e não usar g_state.mpos?
 *  - Se usássemos g_state.mpos como referência, blocos consecutivos
 *    teriam deltas calculados a partir da posição física atual —
 *    ignorando que blocos anteriores já estão na fila. O resultado seria
 *    movimentos incorretos (o Planner "esqueceria" os blocos já planejados).
 * ========================================================================= */
static int32_t s_pos_steps_x = 0;
static int32_t s_pos_steps_y = 0;

/* =========================================================================
 * UTILITÁRIOS INTERNOS
 * ========================================================================= */

/**
 * @brief Retorna o maior inteiro de 32 bits entre dois valores.
 */
static inline int32_t i32_max(int32_t a, int32_t b) { return (a >= b) ? a : b; }

/**
 * @brief Retorna o menor inteiro de 32 bits entre dois valores.
 */
static inline int32_t i32_min(int32_t a, int32_t b) { return (a <= b) ? a : b; }

/* =========================================================================
 * FUNÇÃO PRINCIPAL
 * ========================================================================= */

bool motion_planner_compute(const motion_cmd_t *cmd, motion_block_t *block)
{
    if (cmd == NULL || block == NULL) return false;

    memset(block, 0, sizeof(motion_block_t));
    block->extruder_action = cmd->extruder_action;

    /* ------------------------------------------------------------------
     * CASO 1: Homing (G28)
     * Cria bloco marcador sem passos. O Executor executa a sequência
     * de homing autônoma e depois sinaliza EVENT_HOMING_DONE.
     *
     * A posição de planejamento é resetada para (0,0) imediatamente —
     * o Planner "planeja à frente" sabendo que o resultado do homing
     * será posição zero em ambos os eixos.
     * ---------------------------------------------------------------- */
    if (cmd->type == CMD_HOMING) {
        block->is_homing   = true;
        block->total_steps = 0;
        s_pos_steps_x      = 0;
        s_pos_steps_y      = 0;
        ESP_LOGI(TAG, "Bloco HOMING enfileirado. Posição de planejamento resetada.");
        return true;
    }

    /* ------------------------------------------------------------------
     * CASO 2: Somente extrusor (M3/M5 sem movimento)
     * Bloco com zero passos — o Executor aplica o GPIO e segue.
     * ---------------------------------------------------------------- */
    if (cmd->type == CMD_EXTRUDER_ONLY) {
        block->is_homing   = false;
        block->total_steps = 0;
        ESP_LOGD(TAG, "Bloco extrusor: acao=%d", (int)cmd->extruder_action);
        return true;
    }

    /* ------------------------------------------------------------------
     * CASO 3: Movimento (G0 / G1)
     * ---------------------------------------------------------------- */

    /* === PASSO 1: Converter coordenadas alvo de mm para passos inteiros === */
    int32_t target_x = lroundf(cmd->target_x * STEPS_PER_MM_X);
    int32_t target_y = lroundf(cmd->target_y * STEPS_PER_MM_Y);

    int32_t delta_x = target_x - s_pos_steps_x;
    int32_t delta_y = target_y - s_pos_steps_y;

    int32_t dx = abs(delta_x);
    int32_t dy = abs(delta_y);

    /* Movimento de distância zero — sem bloco a gerar */
    if (dx == 0 && dy == 0) {
        ESP_LOGD(TAG, "Movimento de distancia zero ignorado.");
        return false;
    }

    /* Preenche campos de direção e delta */
    block->steps_x = delta_x;
    block->steps_y = delta_y;
    block->dir_x   = (delta_x >= 0) ? +1 : -1;
    block->dir_y   = (delta_y >= 0) ? +1 : -1;

    /* === PASSO 2: Parâmetros do algoritmo de Bresenham === */

    block->dominant_is_x   = (dx >= dy);
    block->dominant        = i32_max(dx, dy);
    block->subordinate     = i32_min(dx, dy);
    block->bresenham_error = block->dominant / 2;  /* erro inicial = dominant/2 */
    block->total_steps     = (uint32_t)block->dominant;

    /* === PASSO 3: Distância euclideana em mm === */

    /*
     * Para movimentos diagonais, a distância real percorrida é maior que
     * a projeção em qualquer eixo. O feedrate deve ser respeitado ao longo
     * do vetor de movimento, não ao longo de um único eixo.
     *
     * d = sqrt( (dx/SPM_X)² + (dy/SPM_Y)² )  [mm]
     */
    float dx_mm = (float)dx / STEPS_PER_MM_X;
    float dy_mm = (float)dy / STEPS_PER_MM_Y;
    float distance_mm = sqrtf(dx_mm * dx_mm + dy_mm * dy_mm);

    /* Guard: nunca dividir por zero (pode ocorrer em eixo único com float) */
    if (distance_mm < 1e-6f) {
        distance_mm = (float)block->dominant /
                      (block->dominant_is_x ? STEPS_PER_MM_X : STEPS_PER_MM_Y);
    }

    /* === PASSO 4: Step rate na velocidade de cruzeiro === */

    float feedrate_mm_min = (cmd->type == CMD_MOVE_G0)
                            ? MAX_FEEDRATE_MM_MIN
                            : cmd->feedrate;

    /* Clamp: respeita o limite máximo configurado */
    if (feedrate_mm_min > MAX_FEEDRATE_MM_MIN) feedrate_mm_min = MAX_FEEDRATE_MM_MIN;
    if (feedrate_mm_min < 1.0f)               feedrate_mm_min = 1.0f;

    float v_max_mm_s = feedrate_mm_min / 60.0f;

    /*
     * step_rate = v_max × (total_steps / distance_mm)
     *
     * Intuição: total_steps passos cobrem distance_mm mm. Para percorrer
     * distance_mm a v_max mm/s, precisamos disparar (total_steps/distance_mm)
     * passos por segundo no eixo dominante.
     */
    float step_rate = v_max_mm_s * (float)block->total_steps / distance_mm;

    /* Clamp por limites do hardware (GPTimer) */
    const float hw_max_rate = 1e6f / (float)MIN_STEP_PERIOD_US;
    const float hw_min_rate = 1e6f / (float)MAX_STEP_PERIOD_US;
    if (step_rate > hw_max_rate) step_rate = hw_max_rate;
    if (step_rate < hw_min_rate) step_rate = hw_min_rate;

    block->min_period_us = (uint32_t)(1e6f / step_rate);
    /* Segurança extra: período nunca abaixo do mínimo do hardware */
    if (block->min_period_us < MIN_STEP_PERIOD_US) {
        block->min_period_us = MIN_STEP_PERIOD_US;
    }

    /* === PASSO 5: Aceleração projetada em steps/s² === */

    /*
     * a_steps = ACCEL_MM_S2 × (total_steps / distance_mm)
     *
     * A mesma projeção aplicada ao feedrate: converte mm/s² para steps/s²
     * ao longo do vetor de movimento.
     */
    float a_steps = ACCELERATION_MM_S2 * (float)block->total_steps / distance_mm;

    /* === PASSO 6: Número de passos na aceleração === */

    /*
     * Usando v² = 2 × a × s (cinemática, partindo do repouso):
     *   s = v² / (2 × a)
     *   accel_steps = step_rate² / (2 × a_steps)
     */
    uint32_t accel_steps = (uint32_t)(step_rate * step_rate / (2.0f * a_steps));

    /* === PASSO 7: Verificação de perfil triangular === */

    /*
     * Se a distância total não é suficiente para acelerar E desacelerar,
     * o movimento não atinge v_max. O perfil vira um triângulo.
     *
     * Condição: accel_steps × 2 ≥ total_steps
     *
     * Recálculo da velocidade de pico (v_peak):
     *   accel_steps = total_steps / 2   (metade accel, metade decel)
     *   v_peak_steps = sqrt(2 × a_steps × accel_steps)
     */
    if (accel_steps * 2 >= block->total_steps) {
        accel_steps = block->total_steps / 2;

        if (accel_steps == 0) {
            /* Movimento de 1 ou 2 passos: sem aceleração, usa cruzeiro direto */
            block->accel_steps      = 0;
            block->decel_step_start = block->total_steps;
            block->initial_period_us = block->min_period_us;
            block->accel_increment  = 0;
            block->decel_increment  = 0;

            s_pos_steps_x = target_x;
            s_pos_steps_y = target_y;

            ESP_LOGD(TAG, "Bloco micro (%lu passos): cruzeiro puro",
                     (unsigned long)block->total_steps);
            return true;
        }

        /* Recalcula v_peak para o perfil triangular */
        float v_peak = sqrtf(2.0f * a_steps * (float)accel_steps);

        /* Atualiza min_period para a velocidade de pico (não v_max) */
        block->min_period_us = (uint32_t)(1e6f / v_peak);
        if (block->min_period_us < MIN_STEP_PERIOD_US) {
            block->min_period_us = MIN_STEP_PERIOD_US;
        }

        ESP_LOGD(TAG, "Perfil triangular: %lu passos, v_peak=%.1f steps/s",
                 (unsigned long)block->total_steps, (double)v_peak);
    } else {
        ESP_LOGD(TAG, "Perfil trapezoidal: %lu passos, accel=%lu, cruise=%lu, decel=%lu",
                 (unsigned long)block->total_steps,
                 (unsigned long)accel_steps,
                 (unsigned long)(block->total_steps - 2 * accel_steps),
                 (unsigned long)accel_steps);
    }

    block->accel_steps      = accel_steps;
    block->decel_step_start = block->total_steps - accel_steps;

    /* === PASSO 8: Período do primeiro passo (partindo do repouso) === */

    /*
     * Cinemática: s = ½at² → t = sqrt(2s/a)
     * Para s = 1 passo: t₁ = sqrt(2 / a_steps) [s]
     *
     * Este é o INTERVALO entre o momento zero e o primeiro disparo do timer.
     * É o período mais longo (velocidade mais baixa).
     */
    float t1_s = sqrtf(2.0f / a_steps);
    block->initial_period_us = (uint32_t)(t1_s * 1e6f);

    /* Clamp: nunca maior que o período máximo do hardware */
    if (block->initial_period_us > MAX_STEP_PERIOD_US) {
        block->initial_period_us = MAX_STEP_PERIOD_US;
    }
    /* Não pode ser menor que o período de cruzeiro */
    if (block->initial_period_us < block->min_period_us) {
        block->initial_period_us = block->min_period_us;
    }

    /* === PASSO 9: Incremento de período (rampa linear no período) === */

    /*
     * A ramp LINEAR no período não produz aceleração constante em mm/s²
     * (isso exigiria uma ramp √n no período), mas é:
     *  - Suficiente para fins práticos com motores de passo.
     *  - Fácil de calcular (apenas adição inteira na ISR — sem sqrt).
     *  - Mais didática para demonstração dos conceitos.
     *
     * accel_increment = (initial_period - min_period) / accel_steps
     */
    if (accel_steps > 0 && block->initial_period_us > block->min_period_us) {
        uint32_t period_range = block->initial_period_us - block->min_period_us;
        block->accel_increment = period_range / accel_steps;
        block->decel_increment = block->accel_increment;

        /* Garante ao menos 1µs de variação por passo (evita divisão truncada para 0) */
        if (block->accel_increment == 0) {
            block->accel_increment = 1;
            block->decel_increment = 1;
        }
    } else {
        /* Aceleração tão alta que o primeiro passo já é na velocidade de cruzeiro */
        block->accel_steps       = 0;
        block->decel_step_start  = block->total_steps;
        block->initial_period_us = block->min_period_us;
        block->accel_increment   = 0;
        block->decel_increment   = 0;
    }

    /* === PASSO 10: Atualiza posição de planejamento === */
    s_pos_steps_x = target_x;
    s_pos_steps_y = target_y;

    ESP_LOGD(TAG, "Bloco: dx=%ld dy=%ld | dom=%s | t=%lu passos | "
             "T0=%luus Tmin=%luus | a_inc=%lu d_inc=%lu",
             (long)delta_x, (long)delta_y,
             block->dominant_is_x ? "X" : "Y",
             (unsigned long)block->total_steps,
             (unsigned long)block->initial_period_us,
             (unsigned long)block->min_period_us,
             (unsigned long)block->accel_increment,
             (unsigned long)block->decel_increment);

    return true;
}
