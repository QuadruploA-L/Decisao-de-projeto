/**
 * @file grbl_protocol.h
 * @brief Interface do protocolo serial compatível com GRBL.
 *
 * Todas as funções desta interface adquirem g_uart_tx_mutex internamente.
 * Nenhum módulo externo deve chamar uart_write_bytes() diretamente —
 * toda saída serial passa por estas funções para garantir atomicidade.
 */

#ifndef GRBL_PROTOCOL_H
#define GRBL_PROTOCOL_H

#include "gcode_types.h"

/**
 * @brief Envia a string "ok\n" ao host.
 *
 * Deve ser chamado após cada comando G-Code aceito com sucesso.
 */
void grbl_send_ok(void);

/**
 * @brief Envia a string "error\n" ao host.
 *
 * Deve ser chamado quando um comando não pode ser interpretado ou aceito.
 */
void grbl_send_error(void);

/**
 * @brief Envia o relatório de status no formato GRBL.
 *
 * Formato: <Estado|MPos:X.XXX,Y.YYY>\n
 * Exemplo: <Idle|MPos:100.000,50.000>
 *
 * @param state Ponteiro para o estado atual da máquina (snapshot).
 */
void grbl_send_status(const system_state_t *state);

/**
 * @brief Envia a posição atual no formato M114.
 *
 * Formato: X:X.XXX Y:Y.YYY\n
 * Exemplo: X:120.000 Y:80.000
 *
 * @param x Posição X em mm.
 * @param y Posição Y em mm.
 */
void grbl_send_position(float x, float y);

#endif /* GRBL_PROTOCOL_H */
