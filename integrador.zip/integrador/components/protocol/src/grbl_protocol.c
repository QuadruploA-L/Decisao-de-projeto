/**
 * @file grbl_protocol.c
 * @brief Implementação do protocolo serial compatível com GRBL.
 *
 * Todas as funções adquirem g_uart_tx_mutex antes de escrever na UART.
 * Isso garante que mensagens de tarefas diferentes não se intercalem.
 *
 * Mapeamento de estados para strings GRBL:
 *  STATE_IDLE   → "Idle"
 *  STATE_RUN    → "Run"
 *  STATE_HOMING → "Home"
 *  STATE_ALARM  → "Alarm"
 */

#include "grbl_protocol.h"
#include "system_state.h"
#include "config.h"
#include "driver/uart.h"
#include "freertos/FreeRTOS.h"
#include "freertos/semphr.h"
#include <stdio.h>
#include <string.h>

/* Tamanho máximo do buffer de formatação de status */
#define STATUS_BUF_SZ  64

/* ===========================================================================
 * UTILITÁRIO INTERNO
 * ========================================================================= */

/**
 * @brief Envia uma string pela UART protegida por mutex.
 *
 * @param str String terminada em '\0'.
 */
static void send_protected(const char *str)
{
    if (xSemaphoreTake(g_uart_tx_mutex, pdMS_TO_TICKS(MUTEX_TIMEOUT_MS * 10))
        == pdTRUE) {
        uart_write_bytes(UART_PORT_NUM, str, strlen(str));
        xSemaphoreGive(g_uart_tx_mutex);
    }
    /* Se não conseguiu o mutex, descarta — melhor perder um ok/error
     * do que bloquear indefinidamente numa resposta de protocolo. */
}

/* ===========================================================================
 * API PÚBLICA
 * ========================================================================= */

void grbl_send_ok(void)
{
    send_protected("ok\n");
}

void grbl_send_error(void)
{
    send_protected("error\n");
}

void grbl_send_status(const system_state_t *state)
{
    if (state == NULL) return;

    const char *state_str;
    switch (state->status) {
        case STATE_IDLE:   state_str = "Idle";  break;
        case STATE_RUN:    state_str = "Run";   break;
        case STATE_HOMING: state_str = "Home";  break;
        case STATE_ALARM:  state_str = "Alarm"; break;
        default:           state_str = "Unknown"; break;
    }

    char buf[STATUS_BUF_SZ];
    snprintf(buf, sizeof(buf), "<%s|MPos:%.3f,%.3f>\n",
             state_str, state->mpos_x, state->mpos_y);

    send_protected(buf);
}

void grbl_send_position(float x, float y)
{
    char buf[STATUS_BUF_SZ];
    snprintf(buf, sizeof(buf), "X:%.3f Y:%.3f\n", x, y);
    send_protected(buf);
}
