/**
 * @file step_generator.c
 * @brief Gerador de passos via GPTimer ISR — núcleo de tempo real do firmware.
 *
 * # Responsabilidade
 * Gerar pulsos STEP precisos nos eixos X e Y, implementando simultaneamente:
 *  - Interpolação linear via algoritmo de Bresenham (aritmética inteira).
 *  - Controle de velocidade via perfil trapezoidal (rampa linear de período).
 *
 * # Execução por ciclo da ISR
 * 1. Pulso STEP no eixo dominante (sempre).
 * 2. Bresenham: acumula erro; pulso no eixo subordinado se necessário.
 * 3. Incrementa step_count.
 * 4. Atualiza current_period pelo perfil trapezoidal (ACCEL/CRUISE/DECEL).
 * 5. Se step_count == total_steps: notifica Executor via xTaskNotifyFromISR.
 *    Não re-arma → timer para naturalmente (sem novo alarme).
 * 6. Senão: re-arma o alarme com alarme relativo ao contador atual.
 *
 * # Proteção de g_isr_ctx (SMP dual-core)
 * O Executor escreve g_isr_ctx SOMENTE após gptimer_stop() + portENTER_CRITICAL.
 * A ISR lê/escreve g_isr_ctx SOMENTE enquanto o timer está rodando.
 * Os dois domínios são mutuamente exclusivos — sem condição de corrida.
 *
 * # Por que não chamar gptimer_stop() dentro da ISR?
 * gptimer_stop() adquire um spinlock interno já segurado pelo handler.
 * O padrão correto é não re-armar. O Executor para o timer antes do
 * próximo bloco.
 *
 * # Por que GPTimer e não RMT?
 * RMT exige reconstrução de buffer a cada mudança de período — O(n)/bloco.
 * GPTimer re-arma com um write de registrador — O(1)/passo.
 */

#include "motion_executor.h"
#include "hal_stepper.h"
#include "system_state.h"
#include "config.h"

#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "esp_log.h"
#include "esp_attr.h"

static const char *TAG = "step_gen";

/* ===========================================================================
 * VARIÁVEIS GLOBAIS
 * ========================================================================= */

volatile isr_context_t g_isr_ctx = {0};
gptimer_handle_t       g_gptimer  = NULL;

/**
 * Spinlock SMP para proteger escrita em g_isr_ctx pelo Executor.
 * A ISR não adquire este lock — ela só executa quando o timer está rodando
 * e o Executor está bloqueado em xTaskNotifyWait.
 */
static portMUX_TYPE s_isr_mux = portMUX_INITIALIZER_UNLOCKED;

/* ===========================================================================
 * ISR DO GPTIMER
 * ========================================================================= */

/**
 * @brief Callback do GPTimer — gerador de passos em tempo real.
 *
 * Toda lógica aqui é IRAM_ATTR. Restrições absolutas:
 *  - Sem malloc, sem heap.
 *  - Sem printf ou ESP_LOG*.
 *  - Sem xQueueSend/Receive.
 *  - Sem mutex ou semáforo bloqueante.
 *  - Sem float, sem divisão.
 *  - Apenas xTaskNotifyFromISR para comunicação com o Executor.
 *  - Apenas gptimer_set_alarm_action para re-arme do timer.
 *
 * @param timer    Handle do GPTimer.
 * @param edata    Dados do evento: edata->count_value = valor do contador.
 * @param user_ctx Não utilizado.
 * @return true se deve ceder CPU a tarefa de maior prioridade ao retornar.
 */
static bool IRAM_ATTR gptimer_isr_callback(gptimer_handle_t timer,
                                           const gptimer_alarm_event_data_t *edata,
                                           void *user_ctx)
{
    (void)user_ctx;

    BaseType_t higher_prio_woken = pdFALSE;

    /* ------------------------------------------------------------------
     * PASSO 1: Pulso STEP no eixo dominante (sempre ocorre neste ciclo).
     *
     * O eixo dominante avança a cada disparo da ISR, sem condição.
     * ---------------------------------------------------------------- */
    hal_stepper_step(g_isr_ctx.block.dominant_is_x ? AXIS_X : AXIS_Y);

    /* ------------------------------------------------------------------
     * PASSO 2: Algoritmo de Bresenham — eixo subordinado.
     *
     * Acumula o erro. Quando o acumulador ultrapassa o limiar (dominant),
     * o eixo subordinado também avança e o erro é reduzido.
     *
     * Invariante: 0 ≤ bresenham_error < dominant em todo ciclo.
     * Para subordinate == 0 (movimento de eixo único): erro nunca atinge
     * o limiar e o eixo subordinado nunca avança. ✓
     * ---------------------------------------------------------------- */
    g_isr_ctx.bresenham_error += g_isr_ctx.block.subordinate;
    if (g_isr_ctx.bresenham_error >= g_isr_ctx.block.dominant) {
        hal_stepper_step(g_isr_ctx.block.dominant_is_x ? AXIS_Y : AXIS_X);
        g_isr_ctx.bresenham_error -= g_isr_ctx.block.dominant;
    }

    /* ------------------------------------------------------------------
     * PASSO 3: Conta o passo que acabou de ser executado.
     * ---------------------------------------------------------------- */
    g_isr_ctx.step_count++;

    /* ------------------------------------------------------------------
     * PASSO 4: Perfil trapezoidal — atualiza período para o PRÓXIMO passo.
     *
     * A atualização é feita APÓS incrementar step_count para que a fase
     * seja decidida com base no passo que acabou de executar, não no
     * passo que está sendo preparado.
     *
     * ACCEL: step_count <= accel_steps
     *   Período diminui → velocidade aumenta.
     *   Clamp em min_period_us: nunca abaixo da velocidade de cruzeiro.
     *
     * DECEL: step_count >= decel_step_start
     *   Período aumenta → velocidade diminui.
     *   Clamp em MAX_STEP_PERIOD_US: nunca acima da velocidade mínima.
     *
     * CRUISE: nenhuma das condições → período permanece constante.
     * ---------------------------------------------------------------- */
    if (g_isr_ctx.step_count <= g_isr_ctx.block.accel_steps) {

        /* Fase ACCEL: subtrai o incremento; clamp no mínimo */
        if (g_isr_ctx.current_period >
            g_isr_ctx.block.min_period_us + g_isr_ctx.block.accel_increment) {
            g_isr_ctx.current_period -= g_isr_ctx.block.accel_increment;
        } else {
            g_isr_ctx.current_period  = g_isr_ctx.block.min_period_us;
        }

    } else if (g_isr_ctx.step_count >= g_isr_ctx.block.decel_step_start) {

        /* Fase DECEL: soma o incremento; clamp no máximo */
        g_isr_ctx.current_period += g_isr_ctx.block.decel_increment;
        if (g_isr_ctx.current_period > MAX_STEP_PERIOD_US) {
            g_isr_ctx.current_period  = MAX_STEP_PERIOD_US;
        }
    }
    /* Fase CRUISE: current_period não muda */

    /* ------------------------------------------------------------------
     * PASSO 5: Verificação de fim de bloco ou re-arme.
     *
     * FIM DE BLOCO:
     *   Não re-armamos o timer. O contador continuará incrementando mas
     *   sem alarme pendente, nenhuma callback é invocada.
     *   O Executor chamará gptimer_stop() antes do próximo bloco.
     *
     * RE-ARME:
     *   O próximo alarme é relativo ao valor atual do contador.
     *   edata->count_value é o valor do contador no momento deste disparo.
     *   Adicionamos current_period para obter o próximo alarme absoluto.
     *   Isso é O(1) — um único write de registrador.
     * ---------------------------------------------------------------- */
    if (g_isr_ctx.step_count >= g_isr_ctx.block.total_steps) {

        /* Fim de bloco: notifica o Executor */
        xTaskNotifyFromISR(g_executor_task_handle,
                           EVENT_BLOCK_DONE,
                           eSetBits,
                           &higher_prio_woken);
        /* Não re-arma — fim de bloco */

    } else {

        /* Próximo ciclo: alarme relativo ao contador atual */
        gptimer_alarm_config_t next_alarm = {
            .alarm_count              = edata->count_value + g_isr_ctx.current_period,
            .flags.auto_reload_on_alarm = false,
        };
        gptimer_set_alarm_action(timer, &next_alarm);
    }

    /* Cede CPU ao Executor se ele tiver prioridade maior que a task interrompida */
    return (higher_prio_woken == pdTRUE);
}

/* ===========================================================================
 * INICIALIZAÇÃO DO GPTIMER
 * ========================================================================= */

esp_err_t step_generator_init(void)
{
    gptimer_config_t timer_config = {
        .clk_src       = GPTIMER_CLK_SRC_DEFAULT,
        .direction     = GPTIMER_COUNT_UP,
        .resolution_hz = GPTIMER_RESOLUTION_HZ,  /* 1MHz → resolução 1µs */
    };

    esp_err_t ret = gptimer_new_timer(&timer_config, &g_gptimer);
    if (ret != ESP_OK) {
        ESP_LOGE(TAG, "Falha ao criar GPTimer: %s", esp_err_to_name(ret));
        return ret;
    }

    gptimer_event_callbacks_t cbs = {
        .on_alarm = gptimer_isr_callback,
    };

    ret = gptimer_register_event_callbacks(g_gptimer, &cbs, NULL);
    if (ret != ESP_OK) {
        ESP_LOGE(TAG, "Falha ao registrar callback: %s", esp_err_to_name(ret));
        return ret;
    }

    /* Habilita o timer sem iniciá-lo — aguarda step_generator_start_block() */
    ret = gptimer_enable(g_gptimer);
    if (ret != ESP_OK) {
        ESP_LOGE(TAG, "Falha ao habilitar GPTimer: %s", esp_err_to_name(ret));
        return ret;
    }

    ESP_LOGI(TAG, "GPTimer inicializado (resolucao %lu Hz, ISR no Core %d)",
             (unsigned long)GPTIMER_RESOLUTION_HZ, xPortGetCoreID());
    return ESP_OK;
}

/* ===========================================================================
 * CONTROLE DO GERADOR DE PASSOS
 * ========================================================================= */

void step_generator_start_block(const motion_block_t *block)
{
    /* 1. Para o timer — seguro chamar mesmo se já estava parado */
    gptimer_stop(g_gptimer);

    /* 2. Reseta o contador para 0.
     *    OBRIGATÓRIO: gptimer_start() NÃO reseta o contador no ESP-IDF v5.
     *    Sem este reset, alarm_count=initial_period_us seria um valor absoluto
     *    no passado se o contador parou em valor alto, causando disparo imediato
     *    do alarme e arrancada sem aceleração — perda de passos garantida. */
    gptimer_set_raw_count(g_gptimer, 0);

    /* 3. Escreve o contexto da ISR com spinlock.
     *    Necessário em SMP: garante que os writes são visíveis para o Core 1
     *    antes do gptimer_start() que vem a seguir. */
    portENTER_CRITICAL(&s_isr_mux);
    g_isr_ctx.block           = *block;                  /* cópia completa */
    g_isr_ctx.step_count      = 0;
    g_isr_ctx.current_period  = block->initial_period_us;
    g_isr_ctx.phase           = TRAP_PHASE_ACCEL;
    g_isr_ctx.bresenham_error = block->bresenham_error;  /* cópia mutável */
    portEXIT_CRITICAL(&s_isr_mux);

    /* 4. Primeiro alarme: dispara após initial_period_us a partir do zero do contador.
     *    Como o contador foi resetado para 0, alarm_count é relativo ao start. */
    gptimer_alarm_config_t alarm = {
        .alarm_count              = block->initial_period_us,
        .reload_count             = 0,
        .flags.auto_reload_on_alarm = false,
    };
    gptimer_set_alarm_action(g_gptimer, &alarm);

    /* 5. Inicia — a partir daqui a ISR assume o controle do hardware */
    gptimer_start(g_gptimer);
}

void step_generator_stop(void)
{
    gptimer_stop(g_gptimer);
}
