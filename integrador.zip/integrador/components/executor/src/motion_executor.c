/**
 * @file motion_executor.c
 * @brief MotionExecutorTask — consumidor da planner_queue e orquestrador da ISR.
 *
 * # Responsabilidades
 *
 * 1. Inicializar o GPTimer dentro desta task (Core 1), garantindo que a ISR
 *    seja registrada no mesmo core.
 * 2. Consumir motion_block_t da planner_queue sequencialmente.
 * 3. Para cada bloco de movimento:
 *    a. Aplicar extruder_action (antes de qualquer pulso de motor).
 *    b. Configurar DIR dos motores e habilitar drivers.
 *    c. Limpar notificação residual (xTaskNotifyStateClear).
 *    d. Armar o GPTimer via step_generator_start_block().
 *    e. Bloquear em xTaskNotifyWait — ISR executa em tempo real.
 *    f. Ao acordar: atualizar g_state.mpos e status.
 * 4. Executar homing completo (G28) para bloco com is_homing=true.
 *
 * # Padrão de notificação ISR → Task
 *
 * xTaskNotifyStateClear() antes de gptimer_start() garante que nenhuma
 * notificação residual de bloco anterior seja confundida com o novo bloco.
 * xTaskNotifyFromISR() no fim do bloco é persistente — não se perde mesmo
 * que o Executor ainda não tenha chamado xTaskNotifyWait().
 *
 * # Homing
 *
 * O homing roda inteiramente no Executor (busy-loop com esp_rom_delay_us),
 * sem GPTimer. Isso é correto: homing é raro, roda lentamente e exige
 * polling dos endstops após cada passo.
 */

#include "motion_executor.h"
#include "task_motion_executor.h"
#include "system_state.h"
#include "hal_stepper.h"
#include "hal_endstop.h"
#include "hal_extruder.h"
#include "config.h"

#include "freertos/FreeRTOS.h"
#include "freertos/queue.h"
#include "freertos/semphr.h"
#include "freertos/task.h"
#include "freertos/event_groups.h"
#include "esp_log.h"
#include "esp_rom_sys.h"

static const char *TAG = "executor";

/* ===========================================================================
 * UTILITÁRIOS INTERNOS
 * ========================================================================= */

/**
 * @brief Aplica ação do extrusor antes de executar o bloco.
 *
 * @param action -1=sem mudança, 0=desligar, 1=ligar.
 */
static void apply_extruder_action(int8_t action)
{
    if (action == 1) {
        hal_extruder_on();
    } else if (action == 0) {
        hal_extruder_off();
    } else {
        return;
    }

    if (xSemaphoreTake(g_state_mutex, pdMS_TO_TICKS(MUTEX_TIMEOUT_MS)) == pdTRUE) {
        g_state.extruder_on = (action == 1);
        xSemaphoreGive(g_state_mutex);
    }
}

/**
 * @brief Move um único eixo até o endstop ou até atingir o limite de segurança.
 *
 * @param axis       Eixo a mover (AXIS_X ou AXIS_Y).
 * @param period_us  Período entre passos em µs (velocidade de homing).
 * @return true  Se o endstop foi acionado.
 * @return false Se atingiu o limite de segurança sem acionar o endstop (ALARM).
 */
static bool homing_seek_endstop(stepper_axis_t axis, uint32_t period_us)
{
    /* Move em direção negativa (-1) até acionar o endstop */
    hal_stepper_set_dir(axis, -1);

    for (uint32_t steps = 0; steps < HOMING_MAX_TRAVEL_STEPS; steps++) {
        hal_stepper_step(axis);
        esp_rom_delay_us(period_us);

        bool triggered = (axis == AXIS_X) ? hal_endstop_read_x()
                                           : hal_endstop_read_y();
        if (triggered) {
            return true;
        }
    }
    return false;  /* Endstop não encontrado — ALARM */
}

/**
 * @brief Recua o eixo após acionar o endstop (clearance mecânico).
 *
 * @param axis         Eixo a recuar.
 * @param pulloff_steps Número de passos de recuo.
 * @param period_us    Período entre passos em µs.
 */
static void homing_pulloff(stepper_axis_t axis,
                           uint32_t pulloff_steps,
                           uint32_t period_us)
{
    hal_stepper_set_dir(axis, +1);  /* direção positiva */
    for (uint32_t i = 0; i < pulloff_steps; i++) {
        hal_stepper_step(axis);
        esp_rom_delay_us(period_us);
    }
}

/**
 * @brief Executa a sequência completa de homing (G28): X depois Y.
 *
 * Sequência por eixo:
 *  1. Move em direção negativa até o endstop acionar.
 *  2. Recua HOMING_PULLOFF_MM (clearance mecânico).
 *
 * Ao final: g_state.mpos = {0, 0}, EVENT_HOMING_DONE sinalizado.
 * Em caso de falha: STATE_ALARM + EVENT_ALARM.
 */
static void execute_homing_sequence(void)
{
    /* Calcula período (µs por passo) para a velocidade de homing */
    const uint32_t period_x = (uint32_t)(1e6f /
                               (HOMING_FEEDRATE_MM_MIN / 60.0f * STEPS_PER_MM_X));
    const uint32_t period_y = (uint32_t)(1e6f /
                               (HOMING_FEEDRATE_MM_MIN / 60.0f * STEPS_PER_MM_Y));
    const uint32_t pulloff_x = (uint32_t)(HOMING_PULLOFF_MM * STEPS_PER_MM_X);
    const uint32_t pulloff_y = (uint32_t)(HOMING_PULLOFF_MM * STEPS_PER_MM_Y);

    hal_stepper_enable();

    /* ── HOMING EIXO X ──────────────────────────────────────────────────── */
    ESP_LOGI(TAG, "Homing X... (periodo=%lu us, pulloff=%lu passos)",
             (unsigned long)period_x, (unsigned long)pulloff_x);

    if (!homing_seek_endstop(AXIS_X, period_x)) {
        ESP_LOGE(TAG, "Homing X FALHOU: endstop nao acionado em %lu passos",
                 (unsigned long)HOMING_MAX_TRAVEL_STEPS);
        goto alarm;
    }

    homing_pulloff(AXIS_X, pulloff_x, period_x);
    ESP_LOGI(TAG, "Homing X concluido.");

    /* ── HOMING EIXO Y ──────────────────────────────────────────────────── */
    ESP_LOGI(TAG, "Homing Y... (periodo=%lu us, pulloff=%lu passos)",
             (unsigned long)period_y, (unsigned long)pulloff_y);

    if (!homing_seek_endstop(AXIS_Y, period_y)) {
        ESP_LOGE(TAG, "Homing Y FALHOU: endstop nao acionado em %lu passos",
                 (unsigned long)HOMING_MAX_TRAVEL_STEPS);
        goto alarm;
    }

    homing_pulloff(AXIS_Y, pulloff_y, period_y);
    ESP_LOGI(TAG, "Homing Y concluido.");

    /* ── SUCESSO: atualiza posição e sinaliza conclusão ──────────────────── */
    if (xSemaphoreTake(g_state_mutex, pdMS_TO_TICKS(MUTEX_TIMEOUT_MS)) == pdTRUE) {
        g_state.mpos_x = 0.0f;
        g_state.mpos_y = 0.0f;
        g_state.status = STATE_IDLE;
        xSemaphoreGive(g_state_mutex);
    }

    xEventGroupSetBits(g_motion_event_group, EVENT_HOMING_DONE);
    ESP_LOGI(TAG, "Homing completo. Posicao: X=0, Y=0");
    return;

alarm:
    /* ── FALHA: entra em ALARM ───────────────────────────────────────────── */
    if (xSemaphoreTake(g_state_mutex, pdMS_TO_TICKS(MUTEX_TIMEOUT_MS)) == pdTRUE) {
        g_state.status = STATE_ALARM;
        xSemaphoreGive(g_state_mutex);
    }
    xEventGroupSetBits(g_motion_event_group, EVENT_ALARM);
}

/* ===========================================================================
 * TASK ENTRY POINT
 * ========================================================================= */

void task_motion_executor(void *pvParameters)
{
    (void)pvParameters;

    ESP_LOGI(TAG, "MotionExecutorTask iniciada no Core %d", xPortGetCoreID());

    /* GPTimer deve ser criado DENTRO desta task (Core 1).
     * A ISR do GPTimer é registrada no core que chamou gptimer_enable(). */
    if (step_generator_init() != ESP_OK) {
        ESP_LOGE(TAG, "Falha critica ao inicializar GPTimer. Task encerrada.");
        vTaskDelete(NULL);
        return;
    }

    /* Handle desta task é usado pela ISR para xTaskNotifyFromISR */
    g_executor_task_handle = xTaskGetCurrentTaskHandle();

    motion_block_t block;

    for (;;) {
        /* ── AGUARDA PRÓXIMO BLOCO DA PLANNER_QUEUE ──────────────────────── */
        if (xQueueReceive(g_planner_queue, &block, portMAX_DELAY) != pdTRUE) {
            continue;
        }

        /* ── EXTRUSOR: aplica antes de qualquer pulso de motor ───────────── */
        apply_extruder_action(block.extruder_action);

        /* ── HOMING: tratamento especial ─────────────────────────────────── */
        if (block.is_homing) {
            if (xSemaphoreTake(g_state_mutex, pdMS_TO_TICKS(MUTEX_TIMEOUT_MS)) == pdTRUE) {
                g_state.status = STATE_HOMING;
                xSemaphoreGive(g_state_mutex);
            }
            execute_homing_sequence();
            continue;
        }

        /* ── BLOCOS COM ZERO PASSOS (ex: CMD_EXTRUDER_ONLY) ─────────────── */
        if (block.total_steps == 0) {
            continue;
        }

        /* ── CONFIGURAÇÃO DOS MOTORES ────────────────────────────────────── */
        /*
         * DIR é configurado ANTES de habilitar o driver e de armar o timer.
         * O A4988/DRV8825 exige mínimo 1µs de setup do DIR antes do STEP
         * (spec: tSU=200ns A4988, 650ns DRV8825). A latência de configuração
         * da task + gptimer_start() garante margem mais que suficiente.
         */
        hal_stepper_set_dir(AXIS_X, block.dir_x);
        hal_stepper_set_dir(AXIS_Y, block.dir_y);
        hal_stepper_enable();

        /* ── ATUALIZA ESTADO ──────────────────────────────────────────────── */
        if (xSemaphoreTake(g_state_mutex, pdMS_TO_TICKS(MUTEX_TIMEOUT_MS)) == pdTRUE) {
            g_state.status = STATE_RUN;
            xSemaphoreGive(g_state_mutex);
        }

        /* ── LIMPA NOTIFICAÇÃO RESIDUAL ──────────────────────────────────── */
        /*
         * Garantia: nenhuma notificação stale de bloco anterior será recebida
         * no xTaskNotifyWait abaixo. Chamado ANTES de gptimer_start() para
         * evitar a janela onde a notificação nova seria apagada por esta chamada.
         *
         * Segurança: o GPTimer está parado neste ponto (step_generator_start_block
         * ainda não foi chamado), então nenhuma ISR pode produzir notificação aqui.
         */
        xTaskNotifyStateClear(NULL);

        /* ── INICIA EXECUÇÃO VIA ISR ─────────────────────────────────────── */
        ESP_LOGD(TAG, "Bloco: %lu passos, dom=%s, T0=%lu us, Tmin=%lu us",
                 (unsigned long)block.total_steps,
                 block.dominant_is_x ? "X" : "Y",
                 (unsigned long)block.initial_period_us,
                 (unsigned long)block.min_period_us);

        step_generator_start_block(&block);
        /* A partir daqui: ISR controla os GPIOs de STEP em tempo real */

        /* ── AGUARDA CONCLUSÃO ────────────────────────────────────────────── */
        /*
         * ulBitsToClearOnEntry = 0: não limpa notificação existente ao entrar.
         *   Correto: xTaskNotifyStateClear() já limpou qualquer stale antes.
         *   Seguro: se ISR disparou entre start_block e este Wait, a notificação
         *   já está setada e Wait retorna imediatamente sem perdê-la.
         *
         * ulBitsToClearOnExit = ULONG_MAX: limpa todos os bits ao sair.
         *   Garante que o próximo ciclo começa com notificação zerada.
         */
        uint32_t notify_val = 0;
        xTaskNotifyWait(0, ULONG_MAX, &notify_val, portMAX_DELAY);

        /* ── TRATAMENTO DE ALARME ─────────────────────────────────────────── */
        if (notify_val & EVENT_ALARM) {
            ESP_LOGE(TAG, "ALARM recebido durante execucao de bloco!");
            step_generator_stop();
            hal_stepper_disable();

            if (xSemaphoreTake(g_state_mutex, pdMS_TO_TICKS(MUTEX_TIMEOUT_MS)) == pdTRUE) {
                g_state.status = STATE_ALARM;
                xSemaphoreGive(g_state_mutex);
            }
            xEventGroupSetBits(g_motion_event_group, EVENT_ALARM);

            /* Em ALARM: congela o executor. O host deve emitir um reset.
             * Drena a planner_queue para evitar que o Planner fique bloqueado. */
            motion_block_t discard;
            while (xQueueReceive(g_planner_queue, &discard, 0) == pdTRUE) { }

            for (;;) {
                vTaskDelay(pdMS_TO_TICKS(500));
                ESP_LOGE(TAG, "Sistema em ALARM. Reinicialize para continuar.");
            }
        }

        /* ── ATUALIZA POSIÇÃO DE EXECUÇÃO ────────────────────────────────── */
        /*
         * steps_x e steps_y já têm sinal (positivo/negativo = direção).
         * mpos acumula corretamente para movimentos em qualquer direção.
         *
         * Status: IDLE se a planner_queue está vazia (último bloco da sequência),
         *         RUN  se ainda há blocos pendentes.
         */
        if (xSemaphoreTake(g_state_mutex, pdMS_TO_TICKS(MUTEX_TIMEOUT_MS)) == pdTRUE) {
            g_state.mpos_x += (float)block.steps_x / STEPS_PER_MM_X;
            g_state.mpos_y += (float)block.steps_y / STEPS_PER_MM_Y;
            g_state.status  = (uxQueueMessagesWaiting(g_planner_queue) == 0)
                              ? STATE_IDLE : STATE_RUN;
            xSemaphoreGive(g_state_mutex);
        }

        ESP_LOGD(TAG, "Bloco concluido. mpos=(%.3f, %.3f)",
                 (double)g_state.mpos_x, (double)g_state.mpos_y);
    }
}
