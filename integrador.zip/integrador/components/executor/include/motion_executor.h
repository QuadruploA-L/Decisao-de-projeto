/**
 * @file motion_executor.h
 * @brief Interface do executor de movimento e contexto da ISR.
 *
 * O contexto da ISR (isr_context_t) é preenchido pelo MotionExecutorTask
 * antes de armar o GPTimer. A ISR lê este contexto para cada passo.
 *
 * @warning Nunca escrever em isr_ctx enquanto o GPTimer estiver rodando.
 *          Sequência obrigatória: gptimer_stop → seção crítica → escreve → gptimer_start.
 */

#ifndef MOTION_EXECUTOR_H
#define MOTION_EXECUTOR_H

#include <stdint.h>
#include <stdbool.h>
#include "gcode_types.h"
#include "driver/gptimer.h"

/**
 * @brief Fases do perfil trapezoidal de velocidade.
 */
typedef enum {
    TRAP_PHASE_ACCEL,   /**< Aceleração: period diminui a cada passo */
    TRAP_PHASE_CRUISE,  /**< Cruzeiro: period constante */
    TRAP_PHASE_DECEL,   /**< Desaceleração: period aumenta a cada passo */
} trap_phase_t;

/**
 * @brief Contexto compartilhado entre MotionExecutorTask e GPTimer ISR.
 *
 * Escrito pelo Executor (com seção crítica) antes de armar o timer.
 * Lido e modificado pela ISR a cada callback.
 *
 * @note Declarado volatile para que o compilador não faça cache de leituras.
 */
typedef struct {
    /* Parâmetros do bloco corrente (cópia, não ponteiro) */
    motion_block_t block;

    /* Contadores de execução */
    volatile uint32_t step_count;      /**< Passos executados no bloco atual */
    volatile uint32_t current_period;  /**< Período atual em µs (muda por fase) */
    volatile trap_phase_t phase;       /**< Fase trapezoidal atual */

    /* Acumulador Bresenham */
    volatile int32_t bresenham_error;  /**< Cópia mutável do erro de Bresenham */
} isr_context_t;

/** @brief Contexto global da ISR. Definido em step_generator.c. */
extern volatile isr_context_t g_isr_ctx;

/** @brief Handle do GPTimer. Definido em step_generator.c. */
extern gptimer_handle_t g_gptimer;

/**
 * @brief Inicializa o GPTimer e registra a ISR de geração de passos.
 *
 * Deve ser chamado DENTRO da MotionExecutorTask (Core 1) para garantir
 * que a ISR seja registrada no Core 1.
 *
 * @return ESP_OK em sucesso.
 */
esp_err_t step_generator_init(void);

/**
 * @brief Carrega um bloco de movimento no contexto da ISR e inicia o GPTimer.
 *
 * Executa a sequência segura: stop → seção crítica → escreve contexto → start.
 *
 * @param block Ponteiro para o bloco a ser executado.
 */
void step_generator_start_block(const motion_block_t *block);

/**
 * @brief Para o GPTimer imediatamente.
 *
 * Usado no tratamento de alarme (ALARM) ou ao final do homing.
 */
void step_generator_stop(void);

#endif /* MOTION_EXECUTOR_H */
